﻿
namespace WIMI.Quotes.Tests.Common
{
    public struct Constants
    {
        public struct Timeouts
        {
            public const int ImplicitWaitTimeout = 4;
            public const int ScriptTimeout = 10;
        }

        public struct Urls
        {
            public const string BaseUrl = "http://localhost/WIMI.Quotes.UI/";
            public const string BaseLoggedInUrl = "http://localhost/WIMI.Quotes.UI/QuoteForm";
        }

        public struct Users
        {
            public struct Admin
            {
                public const string UserName = "00012345";
                public const string Password = "A";
            }

            public struct Advisor
            {
                public const string UserName = "00012346";
                public const string Password = "A";
            }
        }

        public struct WebDriver
        {
            public struct AngularModelFields
            {
                public const string SelectedAdvisor = "application.selectedAdvisor";
                public const string SelectedClient = "application.selectedClient";
                public const string SelectedClientNumber = "application.selectedClient.ClientNumber";
            }

            public enum ProductOptionIndices
            {
                InvestmentAccount = 1,
                RetirementAnnuity = 2, 
                LivingAnnuity = 3,
                GuaranteedSeries = 4
            }
        }
    }
}
