﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WIMI.Quotes.Repositories;

namespace WIMI.Quotes.Tests.IntegrationTests
{
    [TestClass]
    public class TestFunds
    {
        [TestMethod]
        public void TestFundsNotNull()
        {
            var repo = new WIMQuotesDataRepository();

            var funds = repo.GetFundsList("INVACC", "I", "0012345");
            
            Assert.IsFalse(funds.Equals(null));
        }
    }
}
