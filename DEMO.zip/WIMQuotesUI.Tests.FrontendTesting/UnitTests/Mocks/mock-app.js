﻿/// Mock Angular app.js that excludes authInterceptorService - used for ani-forgery token 
/// embedding in headers but not applicable to unit testing

(function ()
{
    'use strict';

    var quotesApp = angular.module('quotesApp', [
        'quotesApp.services',
        'quotesApp.controllers',
        'common.directives'
    ]);

    angular.module('quotesApp.controllers', []);
    angular.module('quotesApp.services', []);


    // Global Configuration

    quotesApp.constant('numberFormat', {
        fraction: 2,
        thousandSeparator: ',',
        separatorRegex: /\B(?=(\d{3})+(?!\d))/g
    });

})();
