﻿/// <reference path="../../../wimi.quotes.ui/scripts/jasmine/jasmine.js" />
/// <reference path="../../../wimi.quotes.ui/scripts/common/jquery-1.10.2.js" />
/// <reference path="../../../wimi.quotes.ui/scripts/common/angular.js" />
/// <reference path="../../../wimi.quotes.ui/scripts/common/angular-mocks.js" />
/// <reference path="../../helpers/viewtesterhelper.js" />
/// <reference path="../../helpers/testDataHelper.js" />


/// Test Contoller and View
/// <reference path="../../../wimi.quotes.ui/scripts/app/controllers/clientsController.js" />
/// <reference path="../../../wimi.quotes.ui/views/partials/QuoteSelection/ClientSelection.html" />
/// <reference path="../../../wimi.quotes.ui/scripts/app/controllers/quoteHistoryController.js" />
/// <reference path="../../../wimi.quotes.ui/views/partials/QuoteSelection/QuoteHistory.html" />


describe('Test Suite:Edit Client Test', function () {
    var scope, viewTester, httpBackend;

    // Setup 1 - Initialise Angular Online Transacting Application
    beforeEach(window.module('quotesApp'));

    // Setup 2 - Setup mock ajax requests/responses
    beforeEach(inject(function ($httpBackend) {
        testData.hookupHttpBackend($httpBackend);
        httpBackend = $httpBackend;
    }));

    describe('Edit Client', function () {
        // Setup 3 - Before each spec/'it'/test - Setup Angular Scope, Controller & $compile the View
        beforeEach(inject(function ($controller, $rootScope, $compile, commonUtils, clientService, lookupService, validationsService) {
           
            var clientsController = 'clientsController';
            var quoteHistoryController = 'quoteHistoryController';

            var beneficiaryViewHtml = $('.beneficiary').prop('outerHTML');
            var beneficiaryCompiledView = $compile(angular.element(beneficiaryViewHtml))(scope);
            scope.$digest();

            beneficiaryViewTester = $viewTester(beneficiaryCompiledView, scope);

            // Setup Initial Scope 

            $scope = $rootScope.$new();

            $scope.application = {};
            $scope.application.selectedClient = {};
            

            // Instantiate Controller
            $controller(clientsController, { $scope: $scope, $rootScope: $rootScope, lookupService: lookupService, clientService: clientService, validationsService: validationsService });

            // Instantiate Controller
            $controller(quoteHistoryController, { $scope: $scope, lookupService: lookupService, commonUtils: commonUtils, clientService: clientService });


            // Send response to any "ajax" calls
            httpBackend.flush();

            // Compile View and trigger any watches for scope/controller/view
           
        }));


        // ************ BDD - Acceptance Tests *****************

        //Non-Individual Temp Client with No Entity Type
        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Non-Individual temp Client with no Entity Type', function ()
            {
                then('The Edit Client Button should be enabled', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587' , IsTempClient:true , ClientType:'O' , ClientSubType:''};

                    scope.$digest();

                    var editClientButton = viewTester.byClass('Edit-client');

                    expect(editClientButton.is(':disabled')).toBe(false);

                });
            });
        });

        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Non-Individual temp Client with no Entity Type', function ()
            {
                then('The Create Client Button should be disabled', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: true, ClientType: 'O', ClientSubType: '' };

                    scope.$digest();

                    var createClientButton = viewTester.byClass('Create-client');

                    expect(createClientButton.is(':disabled')).toBe(true);

                });
            });
        });

        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Non-Individual temp Client with no Entity Type', function ()
            {
                then('The Create Quote Button should be disabled', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: true, ClientType: 'O', ClientSubType: '' };

                    scope.$digest();

                    var createQuoteButton = viewTester.byClass('Create-quote');

                    expect(createQuoteButton.is(':disabled')).toBe(true);

                });
            });
        });

        //Individual Temp Client
        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Individual temp Client', function ()
            {
                then('The Edit Client Button should be enabled', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: true, ClientType: 'I', ClientSubType: '' };

                    scope.$digest();

                    var editClientButton = viewTester.byClass('Edit-client');

                    expect(editClientButton.is(':disabled')).toBe(false);

                });
            });
        });

        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Individual temp Client with no Entity Type', function ()
            {
                then('The Create Client Button should be enabled', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: true, ClientType: 'I', ClientSubType: '' };

                    scope.$digest();

                    var createClientButton = viewTester.byClass('Create-client');

                    expect(createClientButton.is(':disabled')).toBe(true);

                });
            });
        });

        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Individual temp Client with no Entity Type', function ()
            {
                then('The Create Quote Button should be enabled', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: true, ClientType: 'I', ClientSubType: '' };

                    scope.$digest();

                    var createQuoteButton = viewTester.byClass('Create-quote');

                    expect(createQuoteButton.is(':disabled')).toBe(true);

                });
            });
        });

        //Non-Individual Temp Client with Valid Entity Type
        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Non-Individual temp Client with a valid Entity Type', function ()
            {
                then('The Edit Client Button should be enabled', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: true, ClientType: 'O', ClientSubType: 'CloseCorporation' };

                    scope.$digest();

                    var editClientButton = viewTester.byClass('Edit-client');

                    expect(editClientButton.is(':disabled')).toBe(false);
                });
            });
        });

        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Non-Individual temp Client with a valid Entity Type', function ()
            {
                then('The Create Client Button should be enabled', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: true, ClientType: 'O', ClientSubType: 'CloseCorporation' };

                    scope.$digest();

                    var createClientButton = viewTester.byClass('Create-client');

                    expect(createClientButton.is(':disabled')).toBe(false);
                });
            });
        });

        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Non-Individual temp Client with a valid Entity Type', function ()
            {
                then('The Create Quote Button should be enabled', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: true, ClientType: 'O', ClientSubType: 'CloseCorporation' };

                    scope.$digest();

                    var createQuoteButton = viewTester.byClass('Create-quote');

                    expect(createQuoteButton.is(':disabled')).toBe(false);

                });
            });
        });

        //Non-Individual Existing Client with Valid Entity Type
        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Existing Non-Individual Client with a valid Entity Type', function ()
            {
                then('The Edit Client Button should be disabled', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: false, ClientType: 'O', ClientSubType: 'CloseCorporation' };

                    scope.$digest();

                    var editClientButton = viewTester.byClass('Create-quote');

                    expect(editClientButton.is(':disabled')).toBe(true);
                });
            });
        });

        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Existing Non-Individual Client with a valid Entity Type', function ()
            {
                then('The Create Client Button should be enabled', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: false, ClientType: 'O', ClientSubType: 'CloseCorporation' };

                    scope.$digest();

                    var createClientButton = viewTester.byClass('Create-client');

                    expect(createClientButton.is(':disabled')).toBe(false);
                });
            });
        });

        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Existing Non-Individual Client with a valid Entity Type', function ()
            {
                then('The Create Quote Button should be enabled', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: false, ClientType: 'O', ClientSubType: 'CloseCorporation' };

                    scope.$digest();

                    var createQuoteButton = viewTester.byClass('Create-quote');

                    expect(createQuoteButton.is(':disabled')).toBe(false);
                });
            });
        });

        //Non-Individual Temp Client with an invalid Entity Type
        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Existing Individual Client with an invalid Entity Type', function ()
            {
                then('"Please Recreate Client : Client has been created incorrectly as an individual and not as an organisation" msg should be displayed', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: false, ClientType: 'I', ClientSubType: 'Trust' };

                    scope.$digest();

                });
            });
        });

       //Temp Clients with no Investor Type
        given('User has logged on to Quotes System and selected the Advisor', function ()
        {
            when('The User selects an Temp Client with an no Investor Type', function ()
            {
                then('"Please Recreate Client : Client type has not been set correctly" msg should be displayed', function ()
                {
                    $scope.application.selectedClient = { ClientNumber: 'AI83587', IsTempClient: true, ClientType: '' };

                    scope.$digest();
                });
            });
        });

    });
});


