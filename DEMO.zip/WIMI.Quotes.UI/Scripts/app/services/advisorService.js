﻿(function ()
{
    'use strict';

    angular
        .module('quotesApp.services')
        .factory('advisorService', ['$http', function ($http)
        {
            var advisorService = {};

            advisorService.getCurrentAdivsor = function ()
            {
                return $http({ url: 'api/Advisor' });
            };

            advisorService.searchAdvisors = function (searchTerm)
            {
                return $http({
                    url: 'api/Advisor/?searchTerm=' + searchTerm
                });
            };

            advisorService.getAdvisorOngoingFee = function (policyNumber,brokerCode) {
                return $http({
                    url: 'api/Advisor/ExistingOngoingFee/?brokerCode=' + brokerCode + '&policyNumber=' + policyNumber
                });
            };

            return advisorService;
        }]);
})(); 
