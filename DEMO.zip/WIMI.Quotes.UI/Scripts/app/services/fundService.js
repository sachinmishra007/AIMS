﻿(function ()
{
    'use strict';

    angular
        .module('quotesApp.services')
        .factory('fundService', ['$http', function ($http)
        {
            var fundService = {};

            fundService.getFundsList = function (productCode, fundRangeCode, brokerCode)
            {
                return $http({
                    url: 'api/Fund/?productCode=' + productCode + '&fundRangeCode=' + fundRangeCode + '&brokerCode=' + brokerCode
                });
            };

            fundService.getFundFactSheetsList = function (quoteNumber)
            {
                return $http({ url: 'api/Fund/FundFactSheetsList/?quoteNumber=' + quoteNumber });
            };

            return fundService;
        }]);
})();
