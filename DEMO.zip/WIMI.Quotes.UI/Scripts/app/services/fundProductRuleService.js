﻿(function () {
    'use strict';

    angular
        .module('quotesApp.services')
        .factory('fundProductRuleService', ['$http', function ($http) {
            var fundProductRuleService = {};

            fundProductRuleService.checkMinimumFundRule = function (fundMinimumDetails) {
                return $http.post('api/Fund', fundMinimumDetails);
            };
            return fundProductRuleService;
        }]);
})();