﻿(function ()
{
    'use strict';

    angular
        .module('quotesApp.services')
        .factory('phaseInService', ['$http', function ($http)
        {
            var phaseInService = {};

            phaseInService.getFirstDate = function ()
            {
                return $http({ url: 'api/PhaseIn/FirstDate' });
            };

           

            return phaseInService;
        }]);
})(); 
