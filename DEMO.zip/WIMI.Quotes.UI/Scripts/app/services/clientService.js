﻿(function ()
{
    'use strict';

    angular
        .module('quotesApp.services')
        .factory('clientService', ['$http', function ($http)
        {
            var clientService = {};

            clientService.searchClients = function (brokerCode, searchTerm)
            {
                return $http({
                    url: 'api/Client/?brokerCode=' + brokerCode + '&searchTerm=' + searchTerm
                });
            };

            clientService.createClient = function (newClient)
            {
                return $http.post('api/Client', newClient);
            };

            clientService.getExistingInvestmentValue = function (clientNumber, brokerCode, productCode)
            {
                return $http({
                    url: 'api/Client/ExistingInvestmentValue/?brokerCode=' + brokerCode + '&clientNumber=' + clientNumber + '&productCode=' + productCode
                });
            };

            clientService.getClientContribution = function (clientNumber, productCode)
            {
                return $http({
                    url: 'api/Client/Contributions/?clientNumber=' + clientNumber + '&productCode=' + productCode
                });
            };

            clientService.getClientPolicies = function (clientNumber, productCode)
            {
                return $http({
                    url: 'api/Client/Policies/?clientNumber=' + clientNumber + '&productCode=' + productCode
                });
            };

            clientService.getClientPolicyFund = function (clientNumber, policyNumber)
            {
                return $http({
                    url: 'api/Policy/Fund/?clientNumber=' + clientNumber + '&policyNumber=' + policyNumber
                });
            };

            clientService.getClientPolicyPhaseInDetails = function (clientNumber, policyNumber)
            {
                return $http({
                    url: 'api/Policy/PhaseIn/?clientNumber=' + clientNumber + '&policyNumber=' + policyNumber
                });
            };
            
            return clientService;
        }]);
})(); 
