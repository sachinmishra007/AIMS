﻿(function () {
    'use strict';

    angular
        .module('quotesApp.services')
        .factory('lookupService', ['$http', 'sectionType', function ($http, sectionType) {
            var lookupService = {};

            lookupService.getSteps = function () {
                return [
                    { index: 1, name: 'Select Investor', includeFile: 'Views/Partials/QuoteSelection/QuoteSelection.html' },
                    { index: 2, name: 'Quote Details', includeFile: 'Views/Partials/QuoteDetails/QuoteDetails.html' },
                    { index: 3, name: 'Reports', includeFile: 'Views/Partials/ReportDetails/ReportSelection.html' }
                ];
            };

            lookupService.getQuoteStatuses = function () {
                return [
                    { Code: 'Incomplete', Name: 'Work in progress' },
                    { Code: 'Complete', Name: 'Completed quotes' },
                    { Code: 'Historical', Name: 'Historical quotes' }
                ];
            };

            lookupService.getFundRanges = function (productCode, subcode) {
                return $http({ url: 'api/Lookup/Items?productCode=' + productCode + '&subcode=' + subcode });
            };

            lookupService.getCurrencies = function () {
                return [
                    { Code: 'ZAR', Name: 'South African Rand', Symbol: 'R' },
                    { Code: 'USD', Name: 'United States Dollar', Symbol: '$' },
                    { Code: 'EUR', Name: 'Euro', Symbol: '€' },
                    { Code: 'GBP', Name: 'British Pound', Symbol: '£' },
                    { Code: 'JPY', Name: 'Japanese Yen', Symbol: '¥' }
                ];
            };

            lookupService.getFrequencies = function () {
                return [
                    { Code: 'Monthly', Name: 'Monthly', Weighting: 12 },
                    { Code: 'Quarterly', Name: 'Quarterly', Weighting: 4 },
                    { Code: 'HalfYearly', Name: 'Half Yearly', Weighting: 2 },
                    { Code: 'Yearly', Name: 'Yearly', Weighting: 1 }
                ];
            };

            lookupService.getClientTypes = function () {
                return [
                    { Code: 'I', Name: 'Individual' },
                    { Code: 'O', Name: 'Organisation' }
                ];
            };

            lookupService.getIDTypes = function () {
                return [
                    { Code: 'ID', Name: 'SA ID' },
                    { Code: 'Pass', Name: 'Passport' }
                ];
            };

            lookupService.getGenders = function () {
                return [
                    { Code: 'M', Name: 'Male' },
                    { Code: 'F', Name: 'Female' }
                ];
            };

            lookupService.getStaffTypes = function () {
                return [
                    { Code: 'ABSA', Name: 'Absa Staff' },
                    { Code: 'AIMS', Name: 'AIMS Staff' },
                    { Code: 'NonStaff', Name: 'Non-Staff' }
                ];
            };

            lookupService.getLanguages = function () {
                return [
                    { Code: 'English', Name: 'English' },
                    { Code: 'Afrikaans', Name: 'Afrikaans' }
                ];
            };

            lookupService.getLookupData = function (code) {
                return $http({ url: 'api/Lookup/' + code });
            };

            lookupService.getTaxYear = function () {

                return $http({ url: 'api/TaxYear' });
            };

            lookupService.getPSPProduct = function () {
                return [
                    { Code: 'PENPRES', Name: 'Absa Pension Preservation' },
                    { Code: 'PROVPRES', Name: 'Absa Provident Preservation' },
                    { Code: 'LIVANN', Name: 'Absa Living Annuity' },
                    { Code: 'RA', Name: 'Absa Retirement Annuity' }
                 //   { Code: 'INVACC', Name: 'Absa Retirement Annuity'}

                ];
            };

            lookupService.getFrequenciesPSP = function () {
                return [
                           { Code: 'Monthly', Name: 'Monthly', Weighting: 12 },
                           { Code: 'Quarterly', Name: 'Quarterly', Weighting: 4 }

                ];
            };

            //DEV-19457
            lookupService.getDisplayLabels = function (productCode, sectionName) {
                if (sectionName == sectionType.sectionNames.FEE) {
                    if (productCode == "ISINVACC" || productCode == "INVACC" || productCode == "TAXFREESAV" || productCode == "ENDOW"
                        || productCode == "PENPRES" || productCode == "PROVPRES" || productCode == "RA" || productCode == "LIVANN"
                        || productCode == "OFFSHORE" || productCode == "OPENENDOW") {
                        return {
                            IsVisibleSpecialFeeRefNo: false,
                            LumpSum: 'Lump Sum Initial Advice Fee',
                            DebitOrder: 'Recurring Initial Advice Fee',
                            OngoingFee: 'Annual Advice Fee'
                        }
                    }
                    else {
                        return {
                            IsSpecialFeeRefNo: true,
                            LumpSum: 'Lump Sum Initial Fee',
                            DebitOrder: 'Debit Order Recurring Fee',
                            OngoingFee: 'Lump Sum Ongoing Fee'
                        }
                    }
                }
                else if (sectionName == sectionType.sectionNames.INCOME) {
                    if (productCode == "LIVANN") {
                        return {
                            IsVisibleEscalationPercentage: false
                        }
                    }
                    else {
                        return {
                            IsVisibleEscalationPercentage: true
                        }
                    }
                }
            }

            lookupService.getExistingOngoingFeeLabels = function (productCode) {       
                    if (productCode == "ISINVACC" || productCode == "INVACC" || productCode == "TAXFREESAV" || productCode == "ENDOW"
                        || productCode == "PENPRES" || productCode == "PROVPRES" || productCode == "RA"
                        || productCode == "OFFSHORE" || productCode == "OPENENDOW") {
                        return {

                            ExistingOngoingFee: 'Existing Annual Advice Fee excl.VAT(%)'
                        }
                    }
                    else {
                        return {
                            ExistingOngoingFee: 'Existing Annual Commission excl.VAT (%)'
                        }
                    }
                

            }

            return lookupService;
        }]);
})();
