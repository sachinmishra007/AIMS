﻿(function ()
{
    'use strict';

    angular
        .module('quotesApp.services')
        .factory('validationsService', ['$http', function ($http)
        {
            var validationsService = {};

            validationsService.getValidations = function (productCode, brokerCode, stepId)
            {
                return $http({
                    url: 'api/Validation/?productCode=' + productCode + '&brokerCode=' + brokerCode + '&stepId=' + stepId
                });
            };

            return validationsService;
      }]);
})(); 
