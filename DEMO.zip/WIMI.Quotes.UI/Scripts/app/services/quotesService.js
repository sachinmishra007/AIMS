﻿(function ()
{
    'use strict';

    angular
        .module('quotesApp.services')
        .factory('quotesService', ['$http', function ($http)
        {
            var quotesService = {};

            quotesService.getProductsList = function (brokerCode, clientType, clientSubType)
            {
                return $http({ url: 'api/Product/?brokerCode=' + brokerCode + '&clientType=' + clientType + '&clientSubType=' + clientSubType });
            };

            quotesService.getQuoteHistoryItems = function (brokerCode, clientNumber, status)
            {
                return $http({
                    url: 'api/QuoteHistory/?brokerCode=' + brokerCode + '&clientNumber=' + clientNumber + '&status=' + status
                });
            };

            quotesService.getQuoteItem = function (quoteItemId)
            {
                return $http({
                    url: 'api/QuoteItem/?quoteItemId=' + quoteItemId
                });
            };

            quotesService.getQuoteItemByQuoteNumber = function (quoteNumber)
            {
                return $http({
                    url: 'api/QuoteItem/QuoteNumber/?quoteNumber=' + quoteNumber
                });
            };

            quotesService.getQuoteItems = function (quoteGroupId)
            {
                return $http({
                    url: 'api/QuoteItem/Group/?quoteGroupId=' + quoteGroupId
                });
            };

            quotesService.saveQuoteItem = function (quoteItem)
            {
                return $http.post('api/QuoteItem', quoteItem);
            };

            quotesService.generateQuote = function (reportOptions)
            {
                return $http.post('api/Report', reportOptions);
            };

            quotesService.createNewApplicationForm = function (quoteNumber)
            {
                return $http({
                    url: 'api/Integration/CreateNewApplicationForm/' + quoteNumber
                });
            };

            return quotesService;
        }]);
})();
