﻿(function ()
{
    'use strict';

    angular
        .module('quotesApp.services')
        .factory('regulation28Service', ['$http', function ($http)
        {
            var regulation28Service = {};

            regulation28Service.checkCompliant = function (complianceDetails)
            {
                return $http.post('api/Regulation28', complianceDetails);
            };

            return regulation28Service;
        }]);
})(); 
