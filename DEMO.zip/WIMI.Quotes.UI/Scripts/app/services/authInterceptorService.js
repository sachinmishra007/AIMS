﻿(function ()
{
    'use strict';

    angular
        .module('quotesApp')
        .factory('authInterceptorService', ['$q', function ($q)
        {
            var factory = {};

            var tokenField = document.getElementsByName("__RequestVerificationToken");
            var token = (angular.isDefined(tokenField) && tokenField.length > 0) ? tokenField[0].value : undefined;

            factory.request = function (config)
            {
                config.headers = config.headers || {};

                if (angular.isDefined(token))
                    config.headers["X-RequestVerification-Token"] = token;

                return config;
            }

            factory.responseError = function (rejection)
            {
                if (rejection.status === 401 || rejection.status === 403)
                {
                    location.href = "Error";
                }

                return $q.reject(rejection);
            }

            return factory;
        }]);
})();