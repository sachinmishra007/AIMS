﻿(function ()
{
    'use strict';

    angular
        .module('quotesApp.services')
        .factory('commonUtils', function ()
        {
            var commonUtils = {};

            commonUtils.isUndefinedOrEmpty = function (value)
            {
                return typeof value === "undefined" || value === null || value === "";
            };

            commonUtils.addToDate = function (date, dateType, increaseValue)
            {
                var maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                var offsetMs = 1000 * 60 * 60 * 24;
                var adjustedDate = new Date(date);

                var isAddition = increaseValue >= 0;
                increaseValue = Math.abs(increaseValue);

                switch (dateType)
                {
                    case 'Year':
                        offsetMs *= 365.25 * increaseValue;
                        break;
                    case 'Month':
                        var currentMonth = adjustedDate.getMonth() + 1;
                        var monthMaxDays;

                        if (currentMonth === 2)
                        {
                            monthMaxDays = commonUtils.isLeapYear(currentMonth) ? 29 : 28;
                        }
                        else
                        {
                            monthMaxDays = maxDays[currentMonth];
                        }

                        offsetMs *= monthMaxDays * increaseValue;
                        break;
                    case 'Day':
                        offsetMs *= increaseValue;
                        break;
                }

                adjustedDate.setTime(isAddition ? adjustedDate.getTime() + offsetMs : adjustedDate.getTime() - offsetMs);

                return adjustedDate;
            };

            commonUtils.convertToDate = function (dateString)
            {
                if (typeof dateString === "undefined" || dateString === null || dateString === "")
                    return null;

                var dateFormatted = dateString;

                if (dateFormatted.charAt(dateFormatted.length - 1) !== 'Z')
                    dateFormatted = dateFormatted + 'Z';

                return new Date(dateFormatted);
            };

            commonUtils.getCurrentDate = function ()
            {
                var currentDate = new Date();
                currentDate.setUTCHours(0, 0, 0, 0);

                return currentDate;
            };

            commonUtils.sumArray = function (array, propertyName)
            {
                var total = 0.00;

                for (var i = 0; i < array.length; i++)
                {
                    var amount = parseFloat(array[i][propertyName]);
                    total += isNaN(amount) ? 0 : amount;
                }

                return total;
            };

            return commonUtils;
        });
})();
