﻿(function ()
{
    'use strict';

    angular.module('common.directives')
        .directive('ngValidatorHandler', ['$rootScope', '$parse', function ($rootScope, $parse)
        {
            var validators = [];

            var validateSections = function ()
            {
                var isAllValid = true;
                var hasWarnings = false;

                for (var i = 0; i < validators.length; i++)
                {
                    var isValid = true;

                    if (typeof validators[i].validations !== "undefined" && validators[i].validations !== null)
                    {
                        var result = validator.validate({
                            container: validators[i].element,
                            validations: validators[i].validations
                        });

                        isValid = result.isAllValid;

                        if (!isValid)
                        {
                            isAllValid = false;
                        }

                        if (result.hasWarnings)
                        {
                            hasWarnings = true;
                        }
                    }

                    if (typeof validators[i].propertyName !== "undefined" && validators[i].propertyName !== null)
                    {
                        $parse(validators[i].propertyName).assign(validators[i].scope, isValid);
                    }
                }

                return {
                    isAllValid: isAllValid,
                    hasWarnings: hasWarnings
                };
            };

            return {
                restrict: 'A',
                scope: {},
                controller: function ()
                {
                    this.addValidator = function (validator)
                    {
                        validators.push(validator);
                    };

                    this.removeValidator = function (validator)
                    {
                        for (var i = 0; i < validators.length; i++)
                        {
                            if (validators[i] === validator)
                            {
                                validators.splice(i, 1);
                            }
                        }
                    };

                    this.validate = function ()
                    {
                        var result = validateSections();
                        return result.isAllValid;
                    };
                },
                link: function (scope)
                {
                    // Events

                    var preNextStep = $rootScope.$on('navigation.preNextStep', function (event)
                    {
                        $rootScope.$emit('validator.validated', validateSections());
                        event.defaultPrevented = true;
                    });


                    // On Unload

                    scope.$on("$destroy", function ()
                    {
                        preNextStep();
                        validators = [];
                    });
                }
            }
        }])
        .directive('ngValidatorSection', function ()
        {
            return {
                restrict: 'A',
                require: '^ngValidatorHandler',
                link: function (scope, element, attr, ngValidatorHandlerCtrl)
                {
                    var validator = { scope: scope, element: element, propertyName: attr["ngValidatorVariable"] };

                    scope.$watch(attr.ngValidatorSection, function (newval)
                    {
                        validator.validations = newval;
                    });

                    ngValidatorHandlerCtrl.addValidator(validator);


                    // On Unload

                    scope.$on("$destroy", function ()
                    {
                        ngValidatorHandlerCtrl.removeValidator(validator);
                    });
                }
            };
        })
        .directive('ngValidatorClick', ['$parse', function ($parse)
        {
            return {
                restrict: 'A',
                require: '^ngValidatorHandler',
                link: function (scope, element, attr, ngValidatorHandlerCtrl)
                {
                    var fn = $parse(attr.ngValidatorClick);

                    element.bind('click', function ()
                    {
                        if (ngValidatorHandlerCtrl.validate())
                        {
                            fn(scope);
                        }
                    });


                    // On Unload

                    scope.$on("$destroy", function ()
                    {
                        element.unbind('click');
                    });
                }
            };
        }]);

    (function (validator)
    {
        var settings = {
            separatorRegex: /\B(?=(\d{3})+(?!\d))/g,
            thousandSeparator: ',',
            classInputField: 'field-invalid',
            classInputFieldWarning: 'field-invalid-warning',
            classValidationMessage: 'field-validation-error',
            container: {},
            validations: []
        }


        // Private Members

        var getFields = function ($container, validation)
        {
            var $elementCont;
            var selectorSymbol = '';
            var fieldName = validation.FieldName;

            if (typeof validation.ContainerClass !== "undefined" && validation.ContainerClass !== null)
                $elementCont = $container.find('.' + validation.ContainerClass);
            else
                $elementCont = $container;

            if (validation.FieldName.substr(fieldName.length - 1) === '%') 
            {
                selectorSymbol = '^';
                fieldName = validation.FieldName.substr(0, fieldName.length - 1);
            }

            return $elementCont.find('[name' + selectorSymbol + '="' + fieldName + '"]:input');
        };

        var clearAllValidations = function ($container)
        {
            $container.find('.' + settings.classInputField).removeClass(settings.classInputField);
            $container.find('.' + settings.classInputFieldWarning).removeClass(settings.classInputFieldWarning);
            $container.find('.' + settings.classValidationMessage).remove();
        };

        var formatMessage = function (validation, $container)
        {
            var message = validation.Message, count = 0;

            while (message.indexOf('{') !== -1 && count < 10)
            {
                var messageProp = message.substr(message.indexOf('{') + 1, message.indexOf('}') - message.indexOf('{') - 1);
                var prop = messageProp;
                var isNumber = prop.substr(0, 2) === 'A:';

                if (isNumber)
                    prop = prop.substr(2, prop.length);

                var value;
                var isField = prop.substr(0, 2) === 'F:';

                if (isField)
                {
                    value = $container.find('[name="' + prop.substr(2, prop.length) + '"]').val();
                }
                else
                {
                    value = validation.Parameters[prop];
                }

                if (isNumber)
                {
                    value = isNaN(parseFloat(value)) ? 0.00 : parseFloat(value);
                    value = value.toFixed(2).replace(settings.separatorRegex, settings.thousandSeparator);
                }    

                message = message.replace("{" + messageProp + "}", value);
                count++;
            }

            return message;
        };

        var showValidation = function ($container, validation)
        {
            var $elementCont;
            var preText = '';

            if (typeof validation.ContainerClass !== "undefined" && validation.ContainerClass !== null)
                $elementCont = $container.find('.' + validation.ContainerClass);
            else
                $elementCont = $container.find('[name="' + validation.FieldName + '"]').closest('.input-field');

            $elementCont.addClass(settings.classInputField);

            if (validation.Type === "Warning")
            {
                $elementCont.addClass(settings.classInputFieldWarning);
                preText = 'Warning:<br/>';
            }                

            $elementCont.append('<div class="' + settings.classValidationMessage + '">' + preText + formatMessage(validation, $container) + '</div>');
        };

        var validateRecursive = function ($container, validations)
        {
            var isAllValid = true;
            var hasWarnings = false;

            for (var i = 0; i < validations.length; i++)
            {
                var $value = getFields($container, validations[i]);
                var isValid = validator.validationMethods[validations[i].MethodName]($value, validations[i], $container);

                if ((typeof validations[i].ChildValidations === "undefined" || validations[i].ChildValidations === null || 
                    validations[i].ChildValidations.length === 0) && !isValid)
                {
                    showValidation($container, validations[i], 0);

                    if (validations[i].Type === "Warning")
                    {
                        hasWarnings = true;
                    }
                    else
                    {
                        isAllValid = false;
                    }

                    continue;
                }

                if (validations[i].ChildValidations !== null &&
                    validations[i].ValidateChildrenOnValid === isValid)
                {
                    var result = validateRecursive($container, validations[i].ChildValidations);

                    if (!result.isAllValid)
                    {
                        isAllValid = false;
                    }

                    if (result.hasWarnings)
                    {
                        hasWarnings = true;
                    }
                }
            }

            return {
                isAllValid: isAllValid,
                hasWarnings: hasWarnings
            };
        };


        // Public Methods

        validator.validate = function (options)
        {
            $.extend(settings, options);

            clearAllValidations(settings.container);
            return validateRecursive(settings.container, settings.validations);
        };

        validator.validationMethods =
        {
            isRequired: function ($value)
            {
                var value = $value.val();
                return typeof value !== "undefined" && value !== null && value !== "";
            },
            isValue: function ($value, validation)
            {
                var value = ($value.val() || '').replace('string:', '');
                return value === validation.Parameters.Value;
            },
            inRange: function ($value, validation)
            {
                var amount = parseFloat($value.val()); amount = isNaN(amount) ? 0.00 : amount;
                return amount >= validation.Parameters.MinValue && amount <= validation.Parameters.MaxValue;
            },
            mustEqual: function ($value, validation)
            {
                var value = ($value.val() || '').replace('string:', '');
                return value === validation.Parameters.Value;
            },
            mustEqualAny: function ($value, validation)
            {
                var isValid = false;

                for (var i = 0; i < validation.Parameters.Values.length; i++)
                {
                    var value = ($value.val() || '').replace('string:', '');
                    if (value === validation.Parameters.Values[i])
                        isValid = true;
                }

                return isValid;
            },
            mustEqualAmount: function ($value, validation)
            {
                var amount = parseFloat($value.val()); amount = isNaN(amount) ? 0.00 : amount;
                return amount === validation.Parameters.Value;
            },
            isChecked: function ($value)
            {
                return $value.is(':checked') || $value.val() === 'true';
            },
            isRadioValue: function ($value, validation)
            {
                var value = $value.filter(':checked').val();
                return value === validation.Parameters.Value;
            },
            greaterThan: function ($value, validation)
            {
                var isValid = true;

                $value.each(function ()
                {
                    var amount = parseFloat($(this).val()); amount = isNaN(amount) ? 0.00 : amount;

                    if (validation.Parameters.MinValue != null && !(amount > validation.Parameters.MinValue))
                        isValid = false;
                });

                return isValid;
            },
            greaterThanOrEqual: function ($value, validation)
            {
                var isValid = true;

                $value.each(function ()
                {
                    var amount = parseFloat($(this).val()); amount = isNaN(amount) ? 0.00 : amount;

                    if (typeof validation.Parameters.FieldName !== "undefined")
                    {
                        var $field = $container.find('[name="' + validation.Parameters.FieldName + '"]');
                        var amountToValidate = parseFloat($field.val()); amount = isNaN(amount) ? 0.00 : amount;

                        if (amount >= amountToValidate)
                            isValid = false;
                    }
                    else if (validation.Parameters.MinValue != null && !(amount >= validation.Parameters.MinValue))
                    {
                        isValid = false;
                    }
                });

                return isValid;
            },
            lessThan: function ($value, validation)
            {
                var isValid = true;

                $value.each(function ()
                {
                    var amount = parseFloat($(this).val()); amount = isNaN(amount) ? 0.00 : amount;

                    if (validation.Parameters.MaxValue != null && !(amount < validation.Parameters.MaxValue))
                        isValid = false;
                });

                return isValid;
            },
            lessThanOrEqual: function ($value, validation, $container)
            {
                var isValid = true;

                $value.each(function ()
                {
                    var amount = parseFloat($(this).val()); amount = isNaN(amount) ? 0.00 : amount;

                    if (typeof validation.Parameters.FieldName !== "undefined")
                    {
                        var $field = $container.find('[name="' + validation.Parameters.FieldName + '"]');
                        var amountToValidate = parseFloat($field.val()); amount = isNaN(amount) ? 0.00 : amount;

                        if (amount <= amountToValidate)
                            isValid = false;
                    }
                    else if (validation.Parameters.MaxValue != null && !(amount <= validation.Parameters.MaxValue))
                    {
                        isValid = false;
                    }    
                });

                return isValid;
            },
            sumLessThanOrEqual: function ($value, validation, $container)
            {
                var totalAmount = 0;

                if (!validation.Parameters.FieldNames)
                    return true;

                for (var i = 0; i < validation.Parameters.FieldNames.length; i++)
                {
                    var $field = $container.find('[name="' + validation.Parameters.FieldNames[i] + '"]');
                    var amount = parseFloat($field.val()); amount = isNaN(amount) ? 0.00 : amount;

                    totalAmount += amount;
                }

                var maxValue = 0;

                if (typeof validation.Parameters.MaxValueField !== "undefined")
                {
                    var maxValueField = $container.find('[name="' + validation.Parameters.MaxValueField + '"]');
                    maxValue = parseFloat(maxValueField.val()); maxValue = isNaN(maxValue) ? 0.00 : maxValue;
                }
                else
                {
                    maxValue = validation.Parameters.MaxValue;
                }

                return totalAmount <= maxValue;
            },
            arrayTotalEquals: function ($value, validation)
            {
                var total = 0.00;

                $value.each(function ()
                {
                    var amount = parseFloat($(this).val()); amount = isNaN(amount) ? 0.00 : amount;
                    total += amount;
                });

                return total.toFixed(2) === parseFloat(validation.Parameters.Value).toFixed(2);
            },
            isAnyChecked: function ($value, validation, $container)
            {
                if (!validation.Parameters.FieldNames)
                    return false;

                for (var i = 0; i < validation.Parameters.FieldNames.length; i++)
                {
                    var $field = $container.find('[name="' + validation.Parameters.FieldNames[i] + '"]');

                    if ($field.length === 0 || $field.is(':checked') || $field.val() === 'true')
                        return true;
                }

                return false;
            },
            isAllChecked: function ($value, validation, $container)
            {
                if (!validation.Parameters.FieldNames)
                    return false;

                var isValid = true;

                for (var i = 0; i < validation.Parameters.FieldNames.length; i++)
                {
                    var $field = $container.find('[name="' + validation.Parameters.FieldNames[i] + '"]');

                    if ($field.length === 0 || (!$field.is(':checked') && $field.val() !== 'true'))
                        isValid = false;
                }

                return isValid;
            },
            notAllChecked: function ($value, validation, $container)
            {
                return !validator.validationMethods.isAllChecked($value, validation, $container);
            },
            isLength: function ($value, validation)
            {
                var value = $value.val() || '';
                return value.length === validation.Parameters.Length;
            },
            isNumeric: function ($value)
            {
                var value = $value.val() || '';
                return value === '' || (!isNaN(parseFloat(value)) && isFinite(value));
            },
            charInStringIsValue: function ($value, validation)
            {
                var isValid = false;
                var value = $value.val() || '';

                if (value.length < validation.Parameters.CharIndex)
                    return false;

                var character = value.substr(validation.Parameters.CharIndex, 1);

                for (var i = 0; i < validation.Parameters.Values.length; i++)
                {
                    if (character === validation.Parameters.Values[i])
                        isValid = true;
                }

                return isValid;
            },
            checkDigitVerification: function ($value)
            {
                var num = $value.val() || '';
                var checkDigit = num.charAt(num.length - 1);
                var numSplit = (num + '').replace(/\D+/g, '').split('');

                var i, oddTotal = 0, evenTotal = 0, evenNumber = new String();

                for (i = 0; i < numSplit.length - 1; i++) // Note: Zero based, so (i % 2 == 0) is actually Odd
                {
                    oddTotal += (i % 2 === 0 ? parseInt(numSplit[i]) : 0); // Sum all Odds
                    evenNumber += (i % 2 !== 0 ? numSplit[i] : ""); // Make Whole Number of Even
                }

                var evenSplit = ((evenNumber * 2) + '').split(''); // Multiply Even Whole Number by 2

                for (i = 0; i < evenSplit.length; i++)
                {
                    evenTotal += parseInt(evenSplit[i]);
                }

                var total = oddTotal + evenTotal;
                var cdvNumber = 10 - total.toString().charAt(total.toString().length - 1);

                cdvNumber = cdvNumber.toString().charAt(cdvNumber.toString().length - 1); //If two digits, use last digit. i.e. 12 use 2

                return checkDigit === cdvNumber;
            }
        };

    }(window.validator = window.validator || {}));

})();
