﻿(function ()
{
    'use strict';

    angular.module('common.directives')
        .directive('ngToggleSwitch', ['$parse', function ($parse)
        {
            var toggle = function (element, toggleOn)
            {
                if (toggleOn)
                {
                    element.stop().animate({ backgroundPosition: 0 }, 120, 'linear').removeClass('toggle-switch-off').addClass('toggle-switch-on');
                }
                else
                {
                    element.stop().animate({ backgroundPosition: -30 }, 120, 'linear').removeClass('toggle-switch-on').addClass('toggle-switch-off');
                }
            }

            return {
                restrict: 'AE',
                scope: {
                    ngToggleSwitch: '=',
                    ngToggleSwitchDisabled: '=',
                    ngToggleSwitchCall: '='
                },
                link: function (scope, element, attrs)
                {
                    var disabled = scope.ngToggleSwitchDisabled || false;

                    scope.$watch('ngToggleSwitch', function (newVal)
                    {
                        toggle(element, newVal || false);
                        element.find('input').val(newVal || false);
                    });

                    scope.$watch('ngToggleSwitchDisabled', function (newVal)
                    {
                        disabled = newVal;

                        if (newVal)
                        {
                            element.addClass('toggle-switch-disabled');
                        }
                        else
                        {
                            element.removeClass('toggle-switch-disabled');
                        }
                    })

                    element.addClass('toggle-switch').append('<input type="hidden" name="' + attrs.ngToggleSwitchName + '" />');

                    element.click(function ()
                    {
                        if (disabled)
                            return;

                        scope.$apply(function ()
                        {
                            scope.ngToggleSwitch = !scope.ngToggleSwitch;

                            if (scope.ngToggleSwitchCall)
                                scope.ngToggleSwitchCall(attrs.ngToggleSwitchName, scope.ngToggleSwitch);
                        });
                    });
                }
            };
        }]);

})();
