﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('clientsController', ['$scope', '$rootScope', 'commonUtils', 'lookupService', 'clientService', 'validationsService',
            function ($scope, $rootScope, commonUtils, lookupService, clientService, validationsService)
            {
                $scope.application.clients = [];
                $scope.clientTypes = lookupService.getClientTypes();
                $scope.genders = lookupService.getGenders();
                $scope.staffTypes = lookupService.getStaffTypes();
                $scope.titles = undefined;
                $scope.validations = undefined;
                $scope.entityEditClient = false;
                $scope.disableEntityType = false;
                $scope.ClientTypeChanged = undefined;


                // On Load

                lookupService.getLookupData('TITLES').success(function (response)
                {
                    $scope.titles = response;
                });

                lookupService.getLookupData('ENTTYPES').success(function (response)
                {
                    $scope.entityTypes = response;
                });

                lookupService.getLookupData('ENTTYPES').success(function (response)
                {
                    $scope.entityTypes = response;
                });


                // Private Methods

                var setAgeFromBirthday = function (birthDay)
                {
                    var today = new Date();
                    var birthDate = new Date(birthDay);
                    var age = today.getFullYear() - birthDate.getFullYear();
                    var m = today.getMonth() - birthDate.getMonth();

                    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate()))
                    {
                        age--;
                    }

                    $scope.application.newClient.Age = age;
                }


                // Behaviours 

                $scope.init = function ()
                {
                    $scope.ClientTypeChanged = undefined;

                    if ($scope.application.newClient)
                    {
                        $scope.ClientTypeChanged = $scope.application.newClient.ClientType;
                    }
                    else
                    {
                        $scope.ClientTypeChanged = undefined;
                    };

                    if (typeof $scope.application.newClient === "undefined" || $scope.application.newClient === null)
                    {
                        $scope.application.selectedClient = undefined;
                        $scope.application.newClient = {
                            IdentificationType: "ID",
                            Language: "English",
                            Gender: "Male",
                            Staff: "NonStaff",
                            Advisor: $scope.application.selectedAdvisor.Code
                        };
                        $scope.disableEntityType = false;
                    }
                    else if ($scope.application.newClient && $scope.ClientTypeChanged === '' && $scope.application.newClient.ClientNumber !== '' && $scope.application.newClient.IsTempClient)
                    {
                        $scope.disableEntityType = false;
                    }
                    else
                    {
                        $scope.disableEntityType = true;
                    };

                    validationsService.getValidations("ALL", $scope.application.selectedAdvisor.Code, 1).success(function (response)
                    {
                        $scope.validations = response;
                    });
                };

                $scope.searchClients = function (searchTerm)
                {
                    return clientService.searchClients($scope.application.selectedAdvisor.Code, searchTerm).success(function (response)
                    {
                        $scope.application.clients = response;
                    });
                };

                $scope.getClient = function (selectedClient)
                {
                    if (typeof selectedClient === "undefined" || selectedClient === null)
                        return;

                    $scope.application.selectedClient = selectedClient;

                    $scope.selectedClientType = $scope.application.selectedClient.ClientType;

                    $rootScope.$emit('Client.Selected', { clientNumber: selectedClient.ClientNumber });

                    if ($scope.application.selectedClient && $scope.application.selectedClient.ClientType === 'I' &&
                        !(commonUtils.isUndefinedOrEmpty($scope.application.selectedClient.ClientSubType)) &&
                        !($scope.application.selectedClient.IsTempClient))
                    {
                        $scope.notification.show('Please recreate client', 'Client has been created incorrectly as an individual and not as an organisation');
                        $scope.application.selectedClient = undefined;
                    };

                };

                $scope.cancelCreateClient = function ()
                {
                    if ($scope.ClientTypeChanged === '')
                    {
                        $scope.application.newClient.ClientType = '';
                    };
                    $scope.application.showNewClient = false;
                    $scope.application.newClient = undefined;
                };

                $scope.clientTypeChanged = function ()
                {
                    if ($scope.application.newClient && $scope.ClientTypeChanged === '' && $scope.application.newClient.ClientNumber !== '' && $scope.application.newClient.IsTempClient)
                    {
                        $scope.application.newClient = $scope.application.selectedClient;
                    }
                    else
                    {
                        $scope.application.newClient.DateOfBirth = undefined;
                        $scope.application.newClient.IDNumber = undefined;
                        $scope.application.newClient.Age = undefined;
                    };
                };

                $scope.calculateBirthdayFromID = function (idNo)
                {
                    if (idNo.length > 5 && $scope.application.newClient.IdentificationType === 'ID')
                    {
                        var currentYear = (new Date().getFullYear()).toString().substring(2, 4);
                        var year = (parseInt(idNo.substring(0, 2)) <= currentYear ? '20' : '19') + idNo.substring(0, 2);
                        var birthDay = year + '/' + idNo.substring(2, 4) + '/' + idNo.substring(4, 6);

                        $scope.application.newClient.DateOfBirth = birthDay;
                        setAgeFromBirthday(birthDay);
                    }
                };

                $scope.calculateBirthdayFromDOB = function ()
                {
                    var dob = $scope.application.newClient.DateOfBirth;
                    setAgeFromBirthday(new Date(dob));
                };

                $scope.createClient = function ()
                {
                    $scope.application.showLoading = true;

                    $scope.application.newClient.FullName = $scope.application.newClient.ClientType === 'I' ?
                        $scope.application.newClient.Surname + ', ' + $scope.application.newClient.Name :
                        $scope.application.newClient.Surname;

                    clientService.createClient($scope.application.newClient).success(function (response)
                    {
                        $scope.application.selectedClient = $scope.application.newClient;
                        $scope.application.selectedClient.ClientNumber = response;
                        $scope.application.selectedClient.IsTempClient = true;
                        $scope.application.newClient = undefined;

                        $scope.application.showNewClient = false;
                        $scope.application.showLoading = false;
                    });

                    $scope.application.clients = [];
                };


                // Events

                var advisorSelected = $rootScope.$on('Advisor.Selected', function ()
                {
                    $scope.application.clients = [];
                });


                // On Unload

                $scope.$on("$destroy", function ()
                {
                    advisorSelected();
                });

            }]);
})();