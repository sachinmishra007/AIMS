﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('quoteApplicationController', ['$scope', '$rootScope', 'quotesService', 'lookupService', function ($scope, $rootScope, quotesService, lookupService)
        {
            $scope.steps = lookupService.getSteps();
            $scope.currentStepIndex = 1;
            $scope.includeFile = $scope.steps[0].includeFile;

            $scope.application = {
                showLoading: false,
                selectedAdvisor: undefined,
                selectedClient: undefined,
                showNewClient: false,
                newClient: undefined,
                quoteItems: []
            };

            $scope.notification = {
                isVisible: false,
                header: undefined,
                message: undefined,
                onContinue: undefined,
                show: function (header, message, onContinue)
                {
                    $scope.notification.isVisible = true,
                    $scope.notification.header = header,
                    $scope.notification.message = message;
                    $scope.notification.onContinue = onContinue;
                }
            };


            // Private Members

            var setQuoteItems = function (quoteGroupId)
            {
                
                quotesService.getQuoteItems(quoteGroupId).success(function (response)
                {
                    $scope.application.isReadOnly = true;
                    $scope.application.selectedAdvisor = response[0].Advisor;
                    $scope.application.selectedClient = response[0].Client;
                    $scope.application.quoteItems = response;

                    $scope.moveToStep(2);
                });
            };


            // Behaviours

            $scope.init = function (options)
            {
                $scope.application.userId = options.userId || '';
                $scope.application.role = options.role || '';

                if (angular.isDefined(options.quoteGroupId) && options.quoteGroupId !== '')
                {
                    setQuoteItems(options.quoteGroupId);
                }
            };

            $scope.moveToStep = function (stepIndex)
            {
                
                $scope.currentStepIndex = stepIndex;
                $scope.includeFile = $scope.steps[stepIndex - 1].includeFile;
            };

            $scope.moveForward = function ()
            {
                
                var event = $rootScope.$emit('navigation.preNextStep', $scope.currentStepIndex);

                if (!event.defaultPrevented)
                    $scope.moveToStep($scope.currentStepIndex + 1);
            };

            $scope.moveBack = function ()
            {
                var event = $rootScope.$emit('navigation.prePreviousStep', $scope.currentStepIndex);

                if (!event.defaultPrevented)
                    $scope.moveToStep($scope.currentStepIndex - 1);
            };

            $scope.moveToFirst = function ()
            {
                $scope.moveToStep(1);
            };

            $scope.application.downloadFile = function (url, forceRefresh)
            {
                forceRefresh = forceRefresh || false;

                var suffix = url.indexOf('?') === -1 ? '?' : '&refresh=';
                $scope.application.downloadUrl = url + (forceRefresh ? suffix + new Date().getTime() : '');
            };


            // Events

            var goToNextStep = $rootScope.$on('navigation.goToNextStep', function ()
            {
                $scope.moveToStep($scope.currentStepIndex + 1);
            });

            var goToPreviousStep = $rootScope.$on('navigation.goToPreviousStep', function ()
            {
                $scope.moveToStep($scope.currentStepIndex - 1);
            });


            // On Unload

            $scope.$on("$destroy", function ()
            {
                goToNextStep();
                goToPreviousStep();
            });
        }]);
})();
