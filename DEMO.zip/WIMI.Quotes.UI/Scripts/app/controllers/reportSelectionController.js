﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('reportSelectionController', ['$scope', '$rootScope', function ($scope, $rootScope)
        {
            $scope.selectedTab = 0;
            


            // On Load

            $scope.application.showLoading = false;
            

            // Behaviours

            $scope.selectTab = function (index)
            {
                $scope.selectedTab = index;
            };


            // Events

            var prePreviousStep = $rootScope.$on('navigation.prePreviousStep', function ()
            {
                for (var i = 0; i < $scope.application.quoteItems.length; i++)
                {
                    if (angular.isNumber($scope.application.quoteItems[i].QuoteNumber))
                    {
                        $scope.application.quoteItems.splice(i, 1);
                    }
                }
            });


            // On Unload

            $scope.$on("$destroy", function ()
            {
                prePreviousStep();
            });

        }]);

})();
