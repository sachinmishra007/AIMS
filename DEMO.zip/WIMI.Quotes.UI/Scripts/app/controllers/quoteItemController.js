﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('quoteItemController', ['$scope', 'lookupService', 'validationsService', 'quotesService',
            function ($scope, lookupService, validationsService, quotesService)
            {
                $scope.quoteItem = {};
                $scope.quoteItem.hasDebitOrder = undefined;
                $scope.quoteItem.clientPolicyFundList = {};
                $scope.clientPolicyList = {};
                $scope.validations = undefined;


                // On Load

                $scope.init = function (newQuoteItem)
                {
                    $scope.quoteItem = newQuoteItem;
                    $scope.quoteItem.$valid = true;
                    $scope.quoteItem.maxPSP = 0;

                    if (!angular.isDefined($scope.quoteItem.Currency))
                        $scope.quoteItem.Currency = lookupService.getCurrencies()[0];

                    validationsService.getValidations($scope.quoteItem.Product.Code, $scope.application.selectedAdvisor.Code, 2).success(function (response)
                    {
                        $scope.validations = response;
                    });

                    $scope.application.showLoading = false;
                };

                $scope.toggleDisable = function (profileName, isEnabled)
                {
                    if (profileName === "profile.Addition")
                    {
                        for (var i = 0; i < $scope.application.quoteItems[0].Profiles.length; i++)
                        {
                            if ($scope.quoteItem.Profiles[i].Type === "Income" || $scope.application.quoteItems[0].Profiles[i].Type === "DebitOrder")
                            {
                                //enable/disabled Income and DebitOrder section
                                if (isEnabled)
                                {
                                    $scope.quoteItem.Profiles[i].IsDisabled = true;
                                    $scope.quoteItem.Profiles[i].$disableMessage = "Option not allowed for Additional Investments. Please choose Other Options";
                                }

                                else
                                {
                                    $scope.quoteItem.Profiles[i].IsDisabled = false;
                                    $scope.quoteItem.Profiles[i].$disableMessage = "";
                                }

                                //hide Income and DebitOrder section if it's active 
                                if ($scope.quoteItem.Profiles[i].IsActive)
                                    $scope.quoteItem.Profiles[i].IsActive = false

                            }
                            //Added For Phase In Section
                            if ($scope.quoteItem.Profiles[i].Type === "PhaseIn")
                            {
                                if (!isEnabled && $scope.quoteItem.Profiles[i].IsDisabled)
                                {
                                    $scope.quoteItem.Profiles[i].IsDisabled = false;
                                    $scope.quoteItem.Profiles[i].$disableMessage = "";

                                }

                            }
                            //Added For Lumpsum,based on Addition on/Off LumpSum Work.
                            if ($scope.quoteItem.Profiles[i].Type === "LumpSum")
                            {
                                if (isEnabled)
                                {
                                    $scope.quoteItem.Profiles[i].IsActive = true;
                                    $scope.quoteItem.Profiles[i].IsDisabled = true;
                                    $scope.quoteItem.Profiles[i].$disableMessage = "";
                                }
                                else
                                {
                                    $scope.quoteItem.Profiles[i].IsDisabled = false;
                                }
                            }
                        }

                        if (!isEnabled)
                        {
                            $scope.quoteItem.clientPolicyFundList = undefined;

                            for (var i = 0; i < $scope.quoteItem.Profiles.length; i++)
                            {
                                if ($scope.quoteItem.Profiles[i].Type === "LumpSum")
                                {
                                    $scope.quoteItem.Profiles[i].Funds = [];
                                }
                            }
                        }
                    }

                    if (profileName === "profile.LumpSum" && !isEnabled)
                    {
                        $scope.quoteItem.lumpSumProfile.Funds = undefined;
                    }

                    if (profileName === "profile.PhaseIn")
                    {
                        addLumpSumFund(isEnabled)
                    }


                };

                // Behaviours

                $scope.setCurrency = function (currency)
                {
                    $scope.quoteItem.Currency = currency;
                    $scope.quoteItem.CurrencyCode = currency.Code;
                };

                $scope.maxPSP = function ()
                {
                    var count = 0;

                    for (var i = 0; i < $scope.quoteItem.Profiles.length; i++)
                    {
                        if (typeof $scope.quoteItem.Profiles[i].Funds === "undefined" || $scope.quoteItem.Profiles[i].Funds === null ||
                            $scope.quoteItem.Profiles[i].Funds === 0)
                            continue;

                        if ($scope.quoteItem.Profiles[i].Type !== "Income" && $scope.quoteItem.Profiles[i].Type !== "Addition")
                        {
                            for (var y = 0; y < $scope.quoteItem.Profiles[i].Funds.length; y++)
                            {

                                if ($scope.quoteItem.Profiles[i].Funds[y].IsSharedPortfolio)
                                    count++;
                            }
                        }
                    }

                    return count;
                };

                $scope.hasPhaseInEnable = function ()
                {
                    for (var i = 0; i < $scope.quoteItem.Profiles.length; i++)
                    {
                        if ($scope.quoteItem.Profiles[i].Type === "LumpSum")
                        {
                            for (var k = 0; k < $scope.quoteItem.Profiles.length; k++)
                            {
                                if ($scope.quoteItem.Profiles[k].Type === "PhaseIn" && $scope.quoteItem.Profiles[k].IsActive)
                                {
                                    for (var j = 0; j < $scope.quoteItem.Profiles[i].Funds.length; j++)
                                    {
                                        if ($scope.quoteItem.Profiles[i].Funds[j].Code === 'ABMM')
                                        {
                                            $scope.quoteItem.Profiles[i].Funds[j].IsPhaseRemove = true;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }


                };

                //Private Method 

                var addLumpSumFund = function (isEnabled)
                {
                    if (isEnabled)
                    {
                        for (var i = 0; i < $scope.quoteItem.Profiles.length; i++)
                        {
                            if (typeof $scope.quoteItem.Profiles[i].Funds === "undefined" || $scope.quoteItem.Profiles[i].Funds === null ||
                                $scope.quoteItem.Profiles[i].Funds === 0)
                                continue;

                            if ($scope.quoteItem.Profiles[i].Type === "LumpSum")
                            {
                                var isUnique = true;

                                for (var j = 0; j < $scope.quoteItem.Profiles[i].Funds.length; j++)
                                {
                                    if ($scope.quoteItem.Profiles[i].Funds[j].Code === 'ABMM')
                                        isUnique = false;
                                }

                                if (isUnique)
                                {
                                    var newFund = ({
                                        Name: 'Absa Money Market',
                                        Code: 'ABMM',
                                        Type: 'I',
                                        IsSharedPortfolio: false,
                                        IsEtf: false,
                                        Amount: 0.00,
                                        Percentage: 0.00,
                                        IsPhaseRemove: true
                                    })

                                    $scope.quoteItem.Profiles[i].Funds.push(newFund);
                                }

                            }
                        }
                    }

                    else
                    {
                        for (var i = 0; i < $scope.quoteItem.Profiles.length; i++)
                        {
                            if ($scope.quoteItem.Profiles[i].Type === "LumpSum")
                            {
                                if (typeof $scope.quoteItem.Profiles[i].Funds !== "undefined" || $scope.quoteItem.Profiles[i].Funds !== null ||
                                                $scope.quoteItem.Profiles[i].Funds > 0)
                                {

                                    for (var j = 0; j < $scope.quoteItem.Profiles[i].Funds.length; j++)
                                    {
                                        if ($scope.quoteItem.Profiles[i].Funds[j].Code === 'ABMM')
                                            $scope.quoteItem.Profiles[i].Funds.splice(j, 1)

                                    }
                                }

                            }
                        }

                    }
                }


                // Events

                var saveQuoteItems = $scope.$on('quoteDetails.Persist', function (event, promises)
                {
                    promises.push(quotesService.saveQuoteItem($scope.quoteItem).success(function (response)
                    {
                        $scope.quoteItem.QuoteItemId = response;
                    }));
                });


                // On Unload

                $scope.$on("$destroy", function ()
                {
                    saveQuoteItems();
                });

            }]);
})();
