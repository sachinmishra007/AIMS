﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('quoteDetailsController', ['$scope', '$rootScope', '$q', '$templateCache', 'quotesService', 'clientService',
            function ($scope, $rootScope, $q, $templateCache, quotesService, clientService)
        {
            $scope.productsList = undefined;
            $scope.selectedProduct = undefined;
            $scope.selectedTab = 0;

            $scope.application.showLoading = true;

            $scope.$disableMessage = undefined;


            // On Load

            quotesService.getProductsList($scope.application.selectedAdvisor.Code, $scope.application.selectedClient.ClientType,
                $scope.application.selectedClient.ClientSubType).success(function (response)
            {
                $scope.productsList = response;
                $scope.application.showLoading = false;
                });


            // Private Methods

            var prePersistData = function (onComplete)
            {
                var promises = [];

                $scope.$broadcast('quoteDetails.onPrePersist', promises);

                $q.all(promises).then(function (results)
                {
                    var isSuccess = true;

                    for (var i = 0; i < results.length; i++)
                    {
                        if (!results[i].data.IsOverallCompliant)
                        {
                            isSuccess = false;
                        }
                    }

                    onComplete(isSuccess);
                });
            }

            var persistData = function ()
            {
                var promises = [];

                $scope.$broadcast('quoteDetails.Persist', promises);

                $q.all(promises).then(function ()
                {
                    $scope.application.showLoading = false;
                    $rootScope.$emit('navigation.goToNextStep', null);
                });
            };

            var validateProductSelection = function (product)
            {
                if (product.Code === "LIVANN" ||product.IsGuaranteedProduct)
                {
                    var dob = $scope.application.selectedClient.DateOfBirth;

                    if (!angular.isDefined(dob) || dob === "1900-01-01")
                    {
                        $scope.notification.show(product.Name + ' Cannot Be Selected', 'Client is either not an Individual or they do not have a Date of birth captured.');
                        return false;
                    }
                }

                return true;
            };


            // Behaviours

            $scope.addQuoteItemByProduct = function (selectedProduct)
            {
                $scope.application.showLoading = true;

                if (typeof selectedProduct === "undefined" || selectedProduct === null)
                    return;

                                if (!validateProductSelection(selectedProduct))
                    return;

                var quoteItem = {
                    Product: selectedProduct,
                    Advisor: $scope.application.selectedAdvisor,
                    Client: $scope.application.selectedClient,
                    Profiles: []
                };

                clientService.getExistingInvestmentValue($scope.application.selectedClient.ClientNumber, $scope.application.selectedAdvisor.Code, quoteItem.Product.Code)
                    .success(function (response)
                    {
                        for (var i = 0; i < selectedProduct.ProfileTypes.length; i++)
                        {
                            var profile = {
                                Type: selectedProduct.ProfileTypes[i],
                                Description: selectedProduct.ProfileTypes[i],
                                IsVisible: true,
                                IsDisabled: false
                            };

                            if (quoteItem.Product.Code !== 'OPENENDOW' && profile.Type === 'Addition')
                                profile.IsVisible = (response > 0);

                            quoteItem.Profiles.push(profile);
                        }

                        $scope.application.quoteItems.push(quoteItem);
                        $scope.selectedTab = $scope.application.quoteItems.length - 1;

                        $scope.application.showLoading = false;
                    });
            };



            $scope.selectTab = function (index)
            {
                $scope.selectedTab = index;
            };

            $scope.removeTab = function (index)
            {
                $scope.application.quoteItems.splice(index, 1);
                $scope.selectedTab = (index === 0 ? 0 : index - 1);
            };

            $scope.warningsContinue = function ()
            {
                $scope.notification.isVisible = false;
                
                prePersistData(function (isSuccess)
                {
                    if (isSuccess)
                    {
                        persistData();
                    }
                    else
                    {
                        $scope.application.showLoading = false;
                    }
                });
            };





            // Events

            var preNextStep = $rootScope.$on('validator.validated', function (event, params)
            {
                if (!params.isAllValid)
                    return;

                if (params.hasWarnings)
                {
                    $scope.notification.show(
                        'Warning - Captured fields incorrect',
                        'There are warnings on certain capture fields. Please close & correct or continue to the next step.',
                        $scope.warningsContinue);
                }
                else
                {
                    $scope.application.showLoading = true;

                    prePersistData(function (isSuccess)
                    {
                        if (isSuccess)
                        {
                            persistData();
                        }
                        else
                        {
                            $scope.application.showLoading = false;
                        }
                    });
                }

                event.defaultPrevented = true;
            });


            // On Unload

            $scope.$on("$destroy", function ()
            {
                preNextStep();
            });

        }]);
})();
