﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('debitOrderController', ['$scope', 'lookupService', 'commonUtils', 'clientService',
            function ($scope, lookupService, commonUtils, clientService)
        {
            $scope.profile = {};
            $scope.frequencies = lookupService.getFrequencies();
            $scope.selectedFrequency = $scope.frequencies[0];
            $scope.quarterlyFrequency = 3;
            $scope.halfYearlyFrequency = 6;
            $scope.maxDay = 15;
            $scope.$debitAmtInvalid = false;


            // Private Methods

            var updateWeighting = function (frequency, monthdiff)
            {
                var divisionWeigh = parseInt(monthdiff / frequency);
                var remainderWeigh = parseInt(monthdiff % frequency);

                if (remainderWeigh > 0)
                {
                    divisionWeigh += 1;
                }

                return divisionWeigh;
            }

            var setWeighting = function (weighting)
            {
                var frequency = $scope.selectedFrequency.Code;

                switch (frequency)
                {
                    case 'Monthly':
                        $scope.selectedFrequency.Weighting = weighting;
                        break;
                    case 'Quarterly':
                        weighting = updateWeighting($scope.quarterlyFrequency, weighting);
                        $scope.selectedFrequency.Weighting = weighting;
                        break;
                    case 'HalfYearly':
                        weighting = updateWeighting($scope.halfYearlyFrequency, weighting);
                        $scope.selectedFrequency.Weighting = weighting;
                        break;
                }
            };

            var calMonthDiff = function (d1, d2)
            {
                var months;
                months = (d2.getFullYear() - d1.getFullYear()) * 12;
                months -= d1.getMonth() + 1;
                months += d2.getMonth() + 1;
                return months <= 0 ? 0 : months;
            }

            var getMonthDifference = function () //clientContributions.RemainingNettTaxYear
            {
                var monthDiff;
                var currentDate = commonUtils.getCurrentDate();
                var currentDay = currentDate.getDate();
                var taxYearEndDate = commonUtils.convertToDate($scope.taxYear[0].EndDate);

                if (currentDay >= $scope.maxDay)
                {
                    monthDiff = calMonthDiff(currentDate, taxYearEndDate);
                }
                else
                {
                    monthDiff = calMonthDiff(currentDate, taxYearEndDate);
                    monthDiff += 1;
                }

                setWeighting(monthDiff);

                return monthDiff;
            };

            var setSelectedFrequency = function (frequencyCode)
            {
                for (var i = 0; i < $scope.frequencies.length; i++)
                {
                    if ($scope.frequencies[i].Code === frequencyCode)
                    {
                        $scope.selectedFrequency = $scope.frequencies[i];
                        break;
                    }
                }
            };

            var returnFrequencyValue = function (frequencyCode)
            {
                var frequenceValue = 0;

                $scope.frequencie = lookupService.getFrequencies();

                for (var i = 0; i < $scope.frequencie.length; i++)
                {
                    if ($scope.frequencie[i].Code === frequencyCode)
                    {
                        frequenceValue = $scope.frequencie[i].Weighting;
                        break;
                    }
                }
                return frequenceValue;
            }

            var calculateAnnualAmount = function ()
            {

                if (!commonUtils.isUndefinedOrEmpty($scope.profile.Amount) &&
                    !commonUtils.isUndefinedOrEmpty($scope.profile.RemainingNettTaxYear))
                {

                    var wighting = returnFrequencyValue($scope.selectedFrequency.Code); //get selected Frequenct Wighting

                    if (($scope.profile.Amount * wighting) <= $scope.profile.RemainingNettTaxYear)
                    {
                        if ($scope.quoteItem.Product.Code === 'TAXFREESAV' && !commonUtils.isUndefinedOrEmpty($scope.taxYear))
                        {
                            getMonthDifference();
                        }

                        $scope.profile.AmountAnnual = $scope.profile.Amount * $scope.selectedFrequency.Weighting;

                        $scope.$debitAmtInvalid = false;
                    }
                    else
                    {
                        $scope.$debitAmtInvalid = true;
                        $scope.$debitAmt = ($scope.profile.RemainingNettTaxYear / wighting);
                    }
                }
            };


            // Behaviours 

            $scope.init = function (profile)
            {
                $scope.profile = profile;
                $scope.profile.ShowUseLumpSumFunds = true;

                if (typeof $scope.profile.Funds === "undefined")
                    $scope.profile.Funds = [];

                if (typeof $scope.profile.Frequency === "undefined")
                {
                    $scope.profile.Frequency = $scope.frequencies[0].Code;
                }
                else
                {
                    setSelectedFrequency($scope.profile.Frequency);
                }

                calculateAnnualAmount();

                $scope.quoteItem.hasDebitOrder = true;
                $scope.quoteItem.debitOrderProfile = $scope.profile;

                lookupService.getTaxYear().success(function (response)
                {
                    $scope.taxYear = response;
                });

                clientService.getClientContribution($scope.application.selectedClient.ClientNumber, $scope.quoteItem.Product.Code)
                    .success(function (response)
                    {
                        $scope.quoteItem.debitOrderProfile.RemainingNettTaxYear = response.RemainingNettTaxYear;
                    });
            };

            $scope.amountChanged = function ()
            {
                $scope.$broadcast('profile.AmountChanged', null);
                calculateAnnualAmount();
            };

            $scope.setFrequency = function (selectedFrequency)
            {
                $scope.profile.Frequency = selectedFrequency.Code;
                calculateAnnualAmount();
            };

        }]);
})();