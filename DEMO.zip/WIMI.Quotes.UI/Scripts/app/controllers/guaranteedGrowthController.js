﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('guaranteedGrowthController', ['$scope', function ($scope)
        {
            $scope.profile = {};

            // Behaviours 

            $scope.init = function (profile)
            {
                $scope.profile = profile;
                $scope.quoteItem.guaranteedGrowth = profile;

                if (typeof $scope.profile.GrowthType === "undefined")
                    $scope.profile.GrowthType = 'Growth';

                if ($scope.application.selectedClient.ClientSubType === "Trust")
                    $scope.disableCapitalOption = true;
            };
        }]);
})();
