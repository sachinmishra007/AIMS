﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('quoteHistoryController', ['$scope', '$rootScope', '$window', 'commonUtils', 'lookupService', 'quotesService', 'clientService',
            function ($scope, $rootScope, $window, commonUtils, lookupService, quotesService, clientService)
        {
            $scope.quoteHistoryItems = [];
            $scope.statuses = lookupService.getQuoteStatuses();
            $scope.selectedStatus = $scope.statuses[0];
            $scope.quotesHistoryFilter = '';
            $scope.currentPage = 0;
            $scope.itemsPerPage = 10;
            $scope.range = [];

            // Private Methods

            var filteredQuotesHistoryCount = function ()
            {
                var count = 0;

                for (var i = 0; i < $scope.quoteHistoryItems.length; i++)
                {
                    if ($scope.filterQuotesHistory($scope.quoteHistoryItems[i]))
                        count++;
                }

                return count;
            };

            var getQuoteHistory = function (brokerCode, clientNumber, status)
            {
                $scope.application.showLoading = true;

                quotesService
                    .getQuoteHistoryItems(brokerCode, clientNumber, status)
                    .success(function (response)
                    {
                        $scope.quoteHistoryItems = response;
                        $scope.application.showLoading = false;
                    });
            };


            // Pagination

            $scope.firstPage = function ()
            {
                $scope.currentPage = 0;
            };

            $scope.prevPage = function ()
            {
                if ($scope.currentPage > 0)
                {
                    $scope.currentPage--;
                }
            };

            $scope.prevPageDisabled = function ()
            {
                return $scope.currentPage === 0 ? "disabled" : "";
            };

            $scope.pageCount = function ()
            {
                return Math.ceil(filteredQuotesHistoryCount() / $scope.itemsPerPage) - 1;
            };

            $scope.nextPage = function ()
            {
                if ($scope.currentPage < $scope.pageCount())
                {
                    $scope.currentPage++;
                }
            };

            $scope.lastPage = function ()
            {
                $scope.currentPage = $scope.pageCount();
            };

            $scope.nextPageDisabled = function ()
            {
                return $scope.currentPage === $scope.pageCount() || $scope.pageCount() < 0 ? "disabled" : "";
            };

            $scope.setPage = function (n)
            {
                $scope.currentPage = n;
            };

            $scope.range = function ()
            {
                var range = [];
                var rangeSize = 5;
                var pageCount = $scope.pageCount();
                var start = $scope.currentPage;

                if ((start + pageCount) - rangeSize < 0)
                {
                    rangeSize = pageCount + 1;
                }

                if (start > pageCount - rangeSize)
                {
                    start = pageCount - rangeSize + 1;
                }

                for (var i = start; i < start + rangeSize; i++)
                {
                    range.push(i);
                }

                return range;
            };


            // Behaviours

            $scope.filterQuotesHistory = function (item)
            {
                return (item.Description.toLowerCase().indexOf($scope.quotesHistoryFilter.toLowerCase()) !== -1 ||
                    (item.QuoteNumber !== null && item.QuoteNumber.toString().indexOf($scope.quotesHistoryFilter) !== -1) ||
                    (item.ClientNumber !== null && item.ClientNumber.toString().toLowerCase().indexOf($scope.quotesHistoryFilter.toLowerCase()) !== -1 &&
                    $scope.selectedStatus.Code !== 'Incomplete'));
            };

            $scope.getHistory = function (status)
            {
                var advisorCode = ($scope.application.selectedAdvisor || {}).Code;
                var clientNumber = ($scope.application.selectedClient || {}).ClientNumber;

                if (angular.isDefined(advisorCode) && (angular.isDefined(clientNumber) || $scope.selectedStatus.Code !== 'Incomplete'))
                {
                    getQuoteHistory($scope.application.selectedAdvisor.Code, clientNumber, status.Code);
                    $scope.quotesHistoryFilter = '';
                }
                else if ($scope.selectedStatus.Code === 'Incomplete')
                {
                    $scope.quotesHistoryFilter = '';
                    $scope.quoteHistoryItems = [];
                }
            };

            $scope.newQuote = function ()
            {
                $scope.application.showLoading = true;
                $scope.application.quoteItems = [];

                $rootScope.$emit('navigation.goToNextStep', null);
            };

            $scope.openQuoteItem = function (quoteItemId)
            {
                $scope.application.showLoading = true;

                quotesService.getQuoteItem(quoteItemId).success(function (response)
                {
                    $scope.application.quoteItems = [];
                    $scope.application.quoteItems.push(response);

                    $rootScope.$emit('navigation.goToNextStep', null);
                });
            };

            $scope.downloadQuoteReport = function (quoteNumber)
            {
                quotesService.getQuoteItemByQuoteNumber(quoteNumber).success(function (response)
                {
                    $scope.application.quoteItems = [];
                    $scope.application.quoteItems.push(response);
                    $scope.application.selectedClient = response.Client;

                    $scope.moveToStep(3);
                });
            };

            $scope.openUrl = function (reportUrl)
            {
                $window.open(reportUrl);
            };

            $scope.createClient = function ()
            {
                $scope.application.newClient = undefined;
                $scope.application.showNewClient = true;
            };

            $scope.isCreateNewQuoteDisabled = function ()
            {
                if (!$scope.application.selectedAdvisor || !$scope.application.selectedAdvisor.Code)
                    return true;

                if (!$scope.application.selectedClient || !$scope.application.selectedClient.ClientNumber)
                    return true;
                    
                if ($scope.application.selectedClient && $scope.application.selectedClient.IsTempClient &&
                    $scope.application.selectedClient.ClientType === 'O' && $scope.application.selectedClient.ClientSubType === '')
                    return true;

                if ($scope.application.selectedClient && !($scope.application.selectedClient.IsTempClient) &&
                    $scope.application.selectedClient.ClientType === 'I' &&
                    !(commonUtils.isUndefinedOrEmpty($scope.application.selectedClient.ClientSubType)))
                    return true;

                if ($scope.application.selectedClient && $scope.application.selectedClient.IsTempClient &&
                       $scope.application.selectedClient.ClientType === '' )
                    return true;

                return false;
            };

            $scope.isCreateNewClientDisabled = function ()
            {
                if (!$scope.application.selectedAdvisor || !$scope.application.selectedAdvisor.Code)
                    return true;

                if($scope.application.selectedClient && $scope.application.selectedClient.IsTempClient &&
                    $scope.application.selectedClient.ClientType === 'O' && $scope.application.selectedClient.ClientSubType === '')
                    return true;

                if ($scope.application.selectedClient && $scope.application.selectedClient.IsTempClient &&
                       $scope.application.selectedClient.ClientType === '')
                    return true;

                return false;
            };


            $scope.editClient = function ()
            {
                $scope.application.newClient = $scope.application.selectedClient;
                $scope.application.showNewClient = true;
            };

            $scope.createNewApplicationForm = function (quoteNumber)
            {
                $scope.application.showLoading = true;

                quotesService.createNewApplicationForm(quoteNumber).success(function (response)
                {
                    if (commonUtils.isUndefinedOrEmpty(response) || commonUtils.isUndefinedOrEmpty(response.Url) ||
                        commonUtils.isUndefinedOrEmpty(response.SessionId))
                    {
                        $scope.application.showLoading = false;
                        return;
                    }   

                    $window.location.href = response.Url + response.SessionId;
                });
            };


            // On Load

            $scope.getHistory($scope.selectedStatus);

            // Events

            var clientSelected = $rootScope.$on('Client.Selected', function (event, params)
            {
                getQuoteHistory($scope.application.selectedAdvisor.Code, params.clientNumber, $scope.selectedStatus.Code);
            });

            var advisorSelected = $rootScope.$on('Advisor.Selected', function (event, params)
            {
                getQuoteHistory(params.advisorCode, null, $scope.selectedStatus.Code);
            });


            // On Unload

            $scope.$on("$destroy", function ()
            {
                clientSelected();
                advisorSelected();
            });

        }]);
})();
