﻿
(function () {
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('feesController', ['$scope', 'lookupService', 'advisorService', '$rootScope','sectionType', function ($scope, lookupService, advisorService, $rootScope,sectionType) {
            $scope.fees = {};
            $scope.isDisable = false;

            // Behaviours 

            $scope.init = function (profile) {

                $scope.fees = profile;
                $scope.fees.VatVendor = typeof $scope.fees.VatVendor !== "undefined" ? $scope.fees.VatVendor :
                $scope.application.selectedAdvisor.VatVendor;
                //DEV-19457
                $scope.$ProductCode = lookupService
                   .getDisplayLabels($scope.quoteItem.Product.Code, sectionType.sectionNames.FEE);

                $scope.$Code = lookupService
                   .getExistingOngoingFeeLabels($scope.quoteItem.Product.Code);
            };


            // Events
            var getClientPolicyFund = $rootScope.$on('lumpSum.GetClientPolicyFund', function (event, policy) {
                debugger;
                //if (!commonUtils.isUndefinedOrEmpty($scope.quoteItem.additionProfile) && !commonUtils.isUndefinedOrEmpty($scope.quoteItem.additionProfile.IsVisible)) {
                advisorService.getAdvisorOngoingFee(policy.PolicyNumber,
                                                    $scope.application.selectedAdvisor.Code
                                                    ).success(function (response) {
                                                        $scope.fees.ExistingAdvisorOngoingFee = response;
                                                        //$scope.isDisable = true;
                                                    });
                //}
            });
            // on unload
            $scope.$on("$destroy", function () {
                getClientPolicyFund();
            });
        }]);
})();