﻿
(function ()
{
    'use strict';

    angular.module('quotesApp.controllers')
        .controller('phaseInController', ['$scope', '$rootScope', 'phaseInService', 'commonUtils',
    function ($scope, $rootScope, phaseInService, commonUtils)
    {
        $scope.profile = {};

        var offsetMs = 1000 * 60 * 60 * 24 * 93; // Offset by 2 months;

        $scope.startDate = new Date();
        $scope.endDate = new Date();

        $scope.endDate.setTime($scope.startDate.getTime() + offsetMs);


        // Behaviours 

        $scope.init = function (profile)
        {
            $scope.profile = profile;
            $scope.profile.ShowUseLumpSumFunds = false;
            $scope.profile.ShowExistingLumpSumFunds = false;
            $scope.quoteItem.phaseInProfile = $scope.profile;

            if (commonUtils.isUndefinedOrEmpty($scope.profile.PhaseInLumpSumAmount))
                $scope.profile.PhaseInLumpSumAmount = 0.00

            if (commonUtils.isUndefinedOrEmpty($scope.profile.Amount))
                $scope.profile.Amount = 0.00

            if (typeof $scope.profile.Funds === "undefined")
                $scope.profile.Funds = [];

            $scope.profile.LabelFundPercentage = "Monthly Phase-in Allocation Percentage";
            $scope.profile.LabelFundAmount = "Monthly Phase-in Allocation Amount";

            phaseInService.getFirstDate().success(function (response)
            {
                $scope.profile.PhaseInCommencementDate = response;
            });
        };

        $scope.amountChanged = function ()
        {
            $scope.$broadcast('profile.AmountChanged', null);
        };

        //$scope.validatePhaseInLumpsumAmt = function ()
        //{
        //    var total = 0.00;

        //    //if (!commonUtils.isUndefinedOrEmpty($scope.quoteItem.lumpSumProfile) &&
        //    //    !commonUtils.isUndefinedOrEmpty($scope.quoteItem.lumpSumProfile.Funds) && $scope.quoteItem.lumpSumProfile.Funds.length > 0)
        //    //{

        //    //    for (var i = 0; i < $scope.quoteItem.lumpSumProfile.Funds.length; i++)
        //    //    {
        //    //        if (!$scope.quoteItem.lumpSumProfile.Funds[i].IsSharedPortfolio)
        //    //        {
        //    //            var amount = parseFloat($scope.quoteItem.lumpSumProfile.Funds[i].Amount);
        //    //            total += isNaN(amount) ? 0 : amount;
        //    //        }
        //    //    }
        //    //}

        //    //else
        //    //{
        //    //    if (!commonUtils.isUndefinedOrEmpty($scope.quoteItem.lumpSumProfile) && !commonUtils.isUndefinedOrEmpty($scope.quoteItem.lumpSumProfile.Amount))
        //    //    {
        //    //        total = $scope.quoteItem.lumpSumProfile.Amount;

        //    //    }

        //    //}

        //    return total;
        //}


        $scope.validatePhaseInMonthAmt = function ()
        {
            var total = 0;
            var amount = $scope.profile.Amount === 0 ? 0.00 : $scope.profile.PhaseInLumpSumAmount / $scope.profile.Amount;
            total = parseInt(amount, 10)
            return total;
        }

        $scope.validatePhaseInMinmumAmt = function ()
        {
            var total = 0;

            var amount = $scope.profile.Amount === 0 ? 0.00 : $scope.profile.PhaseInLumpSumAmount / 12;
            amount = amount.toFixed(2);
            total = parseFloat(amount, 10);
            return total;
        }
        $scope.validatePhaseInLumpsumAmt = function ()
        {
            var total = 0.00;

            if (!commonUtils.isUndefinedOrEmpty($scope.quoteItem.lumpSumProfile) &&
                !commonUtils.isUndefinedOrEmpty($scope.quoteItem.lumpSumProfile.Funds) && $scope.quoteItem.lumpSumProfile.Funds.length > 0)
            {
                for (var i = 0; i < $scope.quoteItem.lumpSumProfile.Funds.length; i++)
                {
                    if ($scope.quoteItem.lumpSumProfile.Funds[i].Code === 'ABMM')
                    {
                        total = $scope.quoteItem.lumpSumProfile.Funds[i].Amount;
                    }


                }
            }
            return total;
        }


    }]);
})();
