﻿using System.Collections.Generic;
using System.Web.Http;

using WIMI.Quotes.UI.Web.ActionFilters;

namespace WIMI.Quotes.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class Regulation28Controller : ApiController
    {
        #region Contructors & DI

        private readonly Model.Domain.Contracts.IRegulation28Logic _regulation28Logic;

        public Regulation28Controller(
            Model.Domain.Contracts.IRegulation28Logic regulation28Logic)
        {
            _regulation28Logic = regulation28Logic;
        }

        #endregion

        // POST: api/Regulation28
        [HttpPost]
        public Entities.Regulation28.ComplianceCheckResult Post([FromBody]Entities.Regulation28.ComplianceCheckDetails complianceCheckDetails)
        {
            return _regulation28Logic.CheckCompliant(complianceCheckDetails);
        }
    }
}
