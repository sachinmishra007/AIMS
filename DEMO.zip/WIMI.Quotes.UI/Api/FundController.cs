﻿using System.Collections.Generic;
using System.Web.Http;

using WIMI.Quotes.Common;
using WIMI.Quotes.UI.Web.ActionFilters;

namespace WIMI.Quotes.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class FundController : ApiController
    {
        #region Contructors & DI

        private readonly Model.Domain.Contracts.IFundsLogic _fundsLogic;
        public FundController(Model.Domain.Contracts.IFundsLogic fundsLogic)//,
        {
            _fundsLogic = fundsLogic;
        }

        #endregion

        // GET: api/Fund
        [AuthorizeApiMustBeUser(Constants.Roles.Advisor, "brokerCode")]
        public IEnumerable<Entities.Fund> Get(string productCode, string fundRangeCode, string brokerCode)
        {
            return _fundsLogic.GetFundsList(productCode, fundRangeCode, brokerCode);
        }

        // GET: api/Fund
        [Route("api/Fund/FundFactSheetsList")]
        public IEnumerable<Entities.FundFactSheet> GetFundFactSheetsList(int quoteNumber)
        {
            return _fundsLogic.GetFundFactSheetsForQuote(quoteNumber);
        }

        // GET: api/Fund
        [HttpPost]
        public Entities.FundProductRulesResult Post([FromBody]Entities.FundMinimumDetails fundMinimumDetails)
        {
            return _fundsLogic.CheckFundMinimumAmount(fundMinimumDetails);
        }

    }
}
