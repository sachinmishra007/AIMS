﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using WIMI.Quotes.Model.Domain.Contracts;


namespace WIMI.Quotes.UI.Api
{
    public class PhaseInController : ApiController
    {
        #region Constructor

        private readonly IPhaseInLogic _phaseInLogic;

        public PhaseInController(IPhaseInLogic phaseInLogic)
        {
            _phaseInLogic = phaseInLogic;
        }

        #endregion
        // GET: PhaseIn
        [Route("api/PhaseIn/FirstDate")]
        public DateTime? GetFirstDate()
        {
            return _phaseInLogic.GetPhaseInFirstDate();
        }
    }
}