﻿using System;
using System.Collections.Generic;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMI.Quotes.UI.Web.ActionFilters;

namespace WIMI.Quotes.UI.Api
{
    [ValidateApiAntiForgeryToken]
    public class QuoteItemController : ApiController
    {
        #region Contructors & DI

        private readonly Model.Domain.Contracts.IQuoteItemLogic _quoteItemLogic;

        public QuoteItemController(
            Model.Domain.Contracts.IQuoteItemLogic quoteItemLogic)
        {
            _quoteItemLogic = quoteItemLogic;
        }

        #endregion

        // GET: api/QuoteItem/? or 5
        public Entities.QuoteItem Get(Guid quoteItemId, [ModelBinder]IPrincipal user)
        {
            return _quoteItemLogic.GetQuoteItem(quoteItemId);
        }

        // GET: api/QuoteItemByNumber/? or 5
        [Route("api/QuoteItem/QuoteNumber/")]
        public Entities.QuoteItem Get(int quoteNumber, [ModelBinder]IPrincipal user)
        {
            return _quoteItemLogic.GetQuoteItem(quoteNumber);
        }

        // GET: api/QuoteItem/Group/? or 5
        [Route("api/QuoteItem/Group/")]
        public List<Entities.QuoteItem> GetGroupItems(Guid quoteGroupId, [ModelBinder]IPrincipal user)
        {
            return _quoteItemLogic.GetQuoteItems(quoteGroupId);
        }

        // POST: api/QuoteItem
        [HttpPost]
        public Guid Post([FromBody]Entities.QuoteItem quoteItem, [ModelBinder]IPrincipal user)
        {
            return _quoteItemLogic.SaveQuoteItem(quoteItem, user.Identity.Name);
        }        
    }
}
