﻿using System;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;

using WIMI.Quotes.Common;
using WIMI.Quotes.Common.Helpers;
using WIMI.Quotes.UI.Web.ActionResults;

namespace WIMI.Quotes.UI.Api
{
    public class ReportController : ApiController
    {
        #region Contructors & DI

        private readonly Model.Domain.Contracts.IQuoteGenerationLogic _quoteGenerationLogic;
        private readonly Model.Domain.Contracts.IQuoteReportLogic _quoteReportLogic;

        public ReportController(
            Model.Domain.Contracts.IQuoteGenerationLogic quoteGenerationLogic,
            Model.Domain.Contracts.IQuoteReportLogic quoteReportLogic)
        {
            _quoteGenerationLogic = quoteGenerationLogic;
            _quoteReportLogic = quoteReportLogic;
        }

        #endregion

        // POST: api/Report
        [HttpPost]
        public Entities.QuoteGenerationResult Post([FromBody]Entities.ReportOptions reportOptions, [ModelBinder]IPrincipal user)
        {
            return _quoteGenerationLogic.GenerateQuote(reportOptions, user.Identity.Name);
        }

        // GET: api/Report/quoteNumber
        [Route("api/Report/{quoteNumber}")]
        public HttpResponseMessage Get(int quoteNumber, [ModelBinder]IPrincipal user)
        {
            try
            {
                if (quoteNumber <= 0)
                    return Request.CreateResponse(HttpStatusCode.BadRequest);

                if (!_quoteReportLogic.CanAccessQuoteReport(quoteNumber, user.Identity.Name))
                    return Request.CreateResponse(HttpStatusCode.Unauthorized);

                var reportFile = _quoteReportLogic.GetConsolidatedQuoteReport(quoteNumber);

                if (reportFile == null)
                    return Request.CreateResponse(HttpStatusCode.BadRequest);

                return new FileHttpResponseMessage(reportFile.Data, reportFile.Name, Constants.MimeTypes.Pdf);
            }
            catch (Exception ex)
            {
                AuditHelper.LogException(ex);
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
        }
    }
}