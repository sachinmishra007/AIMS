﻿using System.Web.Mvc;
using System.Web.Security;

namespace WIMI.Quotes.UI.Controllers
{
    public class LoginController : Controller
    {
        #region Contructors & DI

        private readonly Model.Domain.Contracts.IUserLogic _userLogic;

        public LoginController(
            Model.Domain.Contracts.IUserLogic userLogic)
        {
            _userLogic = userLogic;
        }

        #endregion

        // GET: Login
        [AllowAnonymous]
        public ActionResult Index()
        {

            return View();
        }

        // POST: Login
        [HttpPost]
        [AllowAnonymous]
        public ActionResult Index(Entities.Login loginDetails)
        {
            if (!ModelState.IsValid || !_userLogic.AuthenticateUser(loginDetails.Username, loginDetails.Password))
            {
                TempData["ValidationMessage"] = "Invalid Username and/or Password specified";
                return RedirectToAction("Index");
            }

            FormsAuthentication.SetAuthCookie(loginDetails.Username, false);
            return RedirectToAction("Index", "QuoteForm");
        }
    }
}