﻿using System;
using System.Web.Mvc;

using WIMI.Quotes.Common.Extensions;

namespace WIMI.Quotes.UI.Web.ModelBinders
{
    public class GuidModelBinder : IModelBinder
    {
        public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            var parameter = bindingContext.ValueProvider.GetValue(bindingContext.ModelName);
            return parameter != null ? parameter.AttemptedValue.ToGuid() : Guid.Empty;
        }
    }
}