﻿using System.Security.Principal;
using System.Web.Http.ModelBinding;

namespace WIMI.Quotes.UI.Web.ModelBinders
{
    public class PrincipalApiModelBinder : IModelBinder
    {
        public bool BindModel(System.Web.Http.Controllers.HttpActionContext actionContext, 
            ModelBindingContext bindingContext)
        {
            if (bindingContext.ModelType != typeof(IPrincipal))
                return false;

            bindingContext.Model = actionContext.ControllerContext.RequestContext.Principal;

            return true;
        }
    }
}