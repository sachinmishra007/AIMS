﻿using System;
using System.Linq.Expressions;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace WIMI.Quotes.UI.Web.HtmlHelpers
{
    public static class HtmlExtensions
    {
        public static MvcHtmlString PartialFor<TModel, TValue>(
            this HtmlHelper<TModel> html, 
            Expression<Func<TModel, TValue>> expression)
        {
            return html.PartialFor(typeof(TValue).Name, expression);
        }

        public static MvcHtmlString PartialFor<TModel, TValue>(
            this HtmlHelper<TModel> html, 
            string partialViewName, 
            Expression<Func<TModel, TValue>> expression)
        {
            var containingModel = html.ViewData.Model;
            var model = expression.Compile()(containingModel);
            var oldTemplateInfo = html.ViewData.TemplateInfo;

            var newViewData = new ViewDataDictionary(html.ViewData)
            {
                TemplateInfo = new TemplateInfo
                {
                    FormattedModelValue = oldTemplateInfo.FormattedModelValue,
                }
            };

            var newPrefix = ExpressionHelper.GetExpressionText(expression);

            if (oldTemplateInfo.HtmlFieldPrefix.Length > 0)
            {
                newPrefix = oldTemplateInfo.HtmlFieldPrefix + "." + newPrefix;
            }

            newViewData.TemplateInfo.HtmlFieldPrefix = newPrefix;

            return html.Partial(partialViewName, model, newViewData);
        }
    }
}