﻿using System.Web.Http.Filters;
using System.Web.Mvc;

namespace WIMI.Quotes.UI
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
            filters.Add(new AuthorizeAttribute());
        }

        public static void RegisterWebApiFilters(HttpFilterCollection filters)
        {
            filters.Add(new Web.ActionFilters.ElmahHandleErrorApiAttribute());
            filters.Add(new System.Web.Http.AuthorizeAttribute());
        }
    }
}
