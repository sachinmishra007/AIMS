﻿using System.Web.Optimization;

namespace WIMI.Quotes.UI
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            RegisterCommonBundles(bundles);
            RegisterCustomBundles(bundles);
        }

        private static void RegisterCommonBundles(BundleCollection bundles)
        {
            // Scripts 

            bundles.Add(new ScriptBundle("~/Scripts/common/bundle").Include(
                "~/Scripts/common/jquery-{version}.js",
                "~/Scripts/common/chosen.jquery.min.js",
                "~/Scripts/common/angular-1.4.2.js",
                "~/Scripts/common/angular.directives.js"));


            // CSS

            bundles.Add(new StyleBundle("~/Content/styles/common/bundle").Include(
                "~/Content/styles/common/bootstrap.css",
                "~/Content/styles/common/chosen.css"));

            bundles.Add(new StyleBundle("~/Content/styles/site/bundle").Include(
                "~/Content/styles/site/master.css",
                "~/Content/styles/site/input.css",
                "~/Content/styles/site/site.css"));
        }

        private static void RegisterCustomBundles(BundleCollection bundles)
        {
            // Scripts 

            bundles.Add(new ScriptBundle("~/Scripts/app/bundle")
                .Include("~/Scripts/app/app.js",
                    "~/Scripts/app/filters.js",
                    "~/Scripts/app/commonUtils.js")
                .IncludeDirectory("~/Scripts/app/controllers/", "*.js", true)
                .IncludeDirectory("~/Scripts/app/directives/", "*.js", true)
                .IncludeDirectory("~/Scripts/app/services/", "*.js", true));
        }
    }
}
