﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.Entites.Entities
{
    public class ClientInfo
    {
        public string CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string PolicyNumber { get; set; }
    }
}
