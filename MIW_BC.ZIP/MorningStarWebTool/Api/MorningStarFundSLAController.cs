﻿using MorningStarWebTool.DataLayer.Class;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using MorningStarWebTool.Entites.Entities;
using System.Data;
using Newtonsoft.Json;
using System.Web;
using MorningStarWebTool.SessionAPI;
using MorningStarWebTool.Web.ActionFilters;
using MorningStarWebTool.Common.ApplicationConstant;
namespace MorningStarWebTool.Api
{    
    [RoutePrefix("api/SlaFund")]
    [AuthorizeRoles(Constants.Roles.ALL)]    
    public class MorningStarFundSLAController : ApiController
    {
        private Connection _con;

        public MorningStarFundSLAController()
        {
            _con = new Connection();
        }

        [HttpGet]
        [Route("FundSLAMappings")]
        public string getFundSLAMappings()
        {
            return JsonConvert.SerializeObject(_con.getFundSLAMappings());

        }

        [HttpGet]
        [Route("ClientDetails/")]
        public string getClientDetails(string ClientParam, string BrokerCode)
        {            
            return JsonConvert.SerializeObject(_con.getClientDetails(ClientParam, BrokerCode));
        }

        

        [HttpGet]
        [Route("ClientPolicyDetails/")]
        public string getClientPolicyDetails(string ClientNumber)
        {
            return JsonConvert.SerializeObject(_con.getClientPolicyDetails(ClientNumber));
        }

        [HttpGet]
        [Route("ClientPolicyFundDetails/")]
        public string getClientPolicyFundDetails(string ClientNumber, string PolicyNumber)
        {
            return JsonConvert.SerializeObject(_con.getClientPolicyFundDetails(ClientNumber, PolicyNumber));
        }


        //[HttpPost]
        //[Route("ClientPrimaryInformation/")]
        //public string getClientPrimaryInformation(IList<ClientInfo> _clientInfo)
        //{
        //    return string.Empty;
        //}


    }
}
