﻿$(document).ready(function () {

    $('#xray-container').ready(function () {
        var toolName = "XRAY";
        $.ajax({
            type: "POST",
            dataType: "JSON",
            url: "api/MorningStarComponent/GetMorningStarLoadingDetails/" + toolName,
            success: function (result) {
                var _obtainedResult = result;
                var authUrlTemplate = _obtainedResult.AuthUrlTemplate;
                var authenticateAwsSso = function () {
                    return $.ajax(authUrlTemplate);
                };
                authenticateAwsSso().done(function (jsonData) {
                    var data = JSON.parse(jsonData);

                    /*
                        Dyamic XRay Report Tool
                    */
                    //var portfolio = JSON.parse(window.localStorage.getItem('portfolio'));
                    ////console.log(window.localStorage.getItem('portfolio'));
                    //if (portfolio != null && portfolio != undefined) {

                    //Static Portfolio population
                    var portfolio = {
                        name: 'Portfolio',
                        totalValue: 100,
                        currencyId: 'ZAR',
                        //holdings: [{
                        //    identifier: 'F000002CVM',
                        //    identifierType: 'msid',
                        //    weight: 1510351.7812
                        //},
                        //{
                        //    identifier: 'F000002CO9',
                        //    identifierType: 'msid',
                        //    weight: 95807.46
                        //}],
                        benchmark: {
                            holdings: {
                                identifier: 'CAZAF$$ASI_4123',
                                identifierType: 'msid',
                                weight: 100
                            }
                        }
                    };


                    if (data.attachment && data.attachment.SessionID) {
                        morningstar.loader.load({
                            instid: _obtainedResult.InstanceId,
                            environment: _obtainedResult.Environment,
                            appConfig: {},
                            apiTokens: {
                                marketsApiToken: data.attachment.SessionID
                            },
                            configurationNamespace: _obtainedResult.ConfigurationNamespace,
                            customStyles: [_obtainedResult.CustomStyles]
                        }, function (appConfig) {
                            var xray = morningstar.initComponent('ecXray', {
                                container: document.getElementById('xray-container')
                            });
                            xray.setParameter('portfolio', portfolio);
                            //window.localStorage.removeItem('portfolio');
                        });

                    } else {
                        console.log('MarketsApiToken authentication failed');
                    }

                    //}
                })
            },
            error: function (error) {
                console.log(error);
            }

        })



    });

});
