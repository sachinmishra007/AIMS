﻿$(document).ready(function () {

    $('#report-container').ready(function () {
        var toolName = "FUNDREPORT";
        $.ajax({
            type: "POST",
            dataType: "JSON",
            url: "api/MorningStarComponent/GetMorningStarLoadingDetails/" + toolName,
            success: function (result) {
                var _obtainedReport = result;
                var authUrl = _obtainedReport.AuthUrlTemplate;
                var authenticateAwsSso = function () {
                    return $.ajax(authUrl);
                };
                authenticateAwsSso().done(function (jsonData) {
                    var data = JSON.parse(jsonData);
                    var FundCode = JSON.parse(window.localStorage.getItem('FundCode'));
                    if (FundCode == null && FundCode == undefined) {
                        if (data.attachment && data.attachment.SessionID) {
                            morningstar.loader.load({
                                instid: _obtainedReport.InstanceId,
                                appConfig: {},
                                environment: _obtainedReport.Environment,
                                apiTokens: {
                                    marketsApiToken: data.attachment.SessionID
                                },
                                configurationNamespace: _obtainedReport.ConfigurationNamespace,
                                customStyles: [_obtainedReport.CustomStyles]

                            }, function (appConfig) {
                                //init morningstar component with container.
                                var report = morningstar.initComponent('securityReportLoader', {
                                    container: document.getElementById('report-container')
                                });

                            });

                            //window.localStorage.setItem('FundCode', 'FundCode');
                            window.localStorage.removeItem('FundCode');

                        } else {
                            console.log('MarketsApiToken authentication failed');
                        }
                    }
                }).fail(function () {
                    console.log('MarketsApiToken authentication failed');
                });
            },
            error: function (error) {
                console.log(error);
            }
        });
    });
});