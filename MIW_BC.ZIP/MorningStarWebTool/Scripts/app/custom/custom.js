﻿window.sr = ScrollReveal();
sr.reveal('#ReportBtn', {
    origin: 'left',
    duration: 2000,
    delay: 500
}, 50);


sr.reveal('#frame-target', {
    origin: 'bottom',
    duration: 2000
   
}, 50);