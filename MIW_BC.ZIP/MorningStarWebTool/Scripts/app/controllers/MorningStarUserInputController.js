﻿(function () {
    "use strict";

    angular.module('morningStar.controllers')
        .controller('MorningStarUserInput', ['$scope', 'MorningStarService', 'ApplicationSetting',
            function ($scope, MorningStarService, ApplicationSetting) {

                $scope.showLoading = true;
                $scope.FundSLAMapping;

                $scope.init = function () {
                    //Get fund SLA Mapping details
                    MorningStarService
                        .GetMornigStarFundMapping()
                        .success(function (data) {
                            $scope.FundSLAMapping = JSON.parse(data);
                            $scope.fundname = $scope.FundSLAMapping[0];
                            $scope.showLoading = false;
                        })
                        .error(function (error) {
                            console.log(error);
                        })
                };

                $scope.ResettheReportViewOption = function () {
                    $scope.showIframe = false;
                };

                $scope.getClearLocalStorage = function () {
                    window.localStorage.setItem(ApplicationSetting.LocalStorage.FundCode,
                        ApplicationSetting.LocalStorage.FundCode);
                };


                $scope.init();

            }]);
})();