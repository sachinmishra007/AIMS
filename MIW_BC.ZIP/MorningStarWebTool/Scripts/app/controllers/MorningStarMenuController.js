﻿(function () {
    "use strict";

    angular.module('morningStar.controllers')
        .controller('MorningStarMenu', ['$scope', 'lookupService', 'ApplicationSetting',
            function ($scope, lookupService, ApplicationSetting) {

                $scope.showUserInputSource = '';
                $scope.MorningStarMenuItem;

                $scope.init = function () {

                    //Get Morning Star Menu Items
                    $scope.MorningStarMenuItem = lookupService
                        .getMorningStarMenuItem();


                    $scope.getIframeSourceOptions = function (menuItem, selectedIndex) {
                        if (menuItem != undefined) {
                            $scope.showUserInputSource = menuItem.src;

                            //For Fund Report to hide if index value is 1
                            if (selectedIndex == 1) {
                                window.localStorage.setItem(ApplicationSetting.LocalStorage.FundCode, 'null');
                            }
                            else {
                                window.localStorage.removeItem(ApplicationSetting.LocalStorage.FundCode);
                            }
                        }
                    }

                };

                $scope.init();

            }]);
})();