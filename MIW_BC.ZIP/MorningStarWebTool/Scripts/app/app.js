﻿(function () {

    "use strict";
    var UserApplicationPoolName = '/MorningStarWebTool/';
    var morningStarApp = angular.module("morningStar", [
        'morningStar.controllers',
        'morningStar.services',
        'morningStar.directives'
    ]);

    angular.module('morningStar.controllers', []);
    angular.module('morningStar.services', []);


    //UAT WebApiURL:MorningStarTool
    morningStarApp.constant('ApplicationSetting', {
        InputSearchUpto: 2,
        LocalStorage: {
            FundCode: 'FundCode',
            Portfolio: 'portfolio'
        },
        WebApiUrl: {
            URL: UserApplicationPoolName
        }
    });

    //Closing the User Session
    $(window).on('beforeunload', function () {
        $.ajax({
            url: UserApplicationPoolName + 'Entry/Closed',
            method: 'POST',
            success: function (_result, _status, _xhr) {
                return confirm("Exit");
            },
            error: function (_xhr, _status, _error) {
                alert("Error while Processing the Request");
            }
        });
    });

})();