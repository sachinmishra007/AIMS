﻿using MorningStarWebTool.DataLayer.Class;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.Common
{
    public class Util
    {
        private Connection _con = null;
        public Util()
        {
            _con = new Connection();
        }

        public object GetMorningStarInformation()
        {
            var _result = _con.getMSConfigToolInformation("", ConfigurationManager.AppSettings["Type"].ToString());
            if (_result != null)
            {
                var _AuthURL = string.Empty;
                var _siteUrl = GetParameterValue(_result, ConfigurationManager.AppSettings["AuthUrl"].ToString());
                var _email = GetParameterValue(_result, ConfigurationManager.AppSettings["AuthEmail"].ToString());
                var _instanceId = GetParameterValue(_result, ConfigurationManager.AppSettings["AuthInstanceId"].ToString());
                var _password = GetParameterValue(_result, ConfigurationManager.AppSettings["AuthPWD"].ToString());
                _AuthURL = _siteUrl + "email=" + _email + "&pwd=" + _password + "&instid=" + _instanceId;
                return _AuthURL;
            }
            else
            {
                return null;
            }
        }

        private object GetParameterValue(DataTable _result, string ParameterName)
        {
            return (from st in _result.AsEnumerable()
                    where st.Field<object>("ConfigName").Equals(ParameterName)
                    select st.Field<object>("ConfigValue")).ToList()[0];
        }


    }
}
