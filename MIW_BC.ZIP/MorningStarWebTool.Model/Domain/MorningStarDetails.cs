﻿using MorningStarWebTool.Model.Domain.Contract;
using MorningStarWebTool.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.Model.Domain
{
    public class MorningStarDetails : IMorningStarDetails
    {
        private readonly MorningStarDetailsRepository _morningStarDetailsRepository = null;
        public MorningStarDetails(MorningStarDetailsRepository morningStarDetailsRepository)
        {
            _morningStarDetailsRepository = morningStarDetailsRepository;
        }
        public object GetMorningStarDetails(string ToolName)
        {
            return _morningStarDetailsRepository.GetMorningStarDetails(ToolName);
        }
    }
}
