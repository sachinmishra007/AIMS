﻿using MorningStarWebTool.Model.Domain.Contract;
using MorningStarWebTool.Repositories.Contract;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.Model.Domain
{
    public class SettingLogic : ISettingLogic
    {
        private readonly ISettingLogicRepository _settingLogicRepository = null;
        public SettingLogic(ISettingLogicRepository settingLogicRepository)
        {
            _settingLogicRepository = settingLogicRepository;
        }
        public T GetApplicationSetting<T>(string _appSettingKey)
        {
            return _settingLogicRepository.GetApplicationSetting<T>(_appSettingKey);
        }
    }
}
