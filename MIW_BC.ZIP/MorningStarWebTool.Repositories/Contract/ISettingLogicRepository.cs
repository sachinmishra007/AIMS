﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.Repositories.Contract
{
    public interface ISettingLogicRepository
    {
        T GetApplicationSetting<T>(string _appSettingKey);
    }
}
