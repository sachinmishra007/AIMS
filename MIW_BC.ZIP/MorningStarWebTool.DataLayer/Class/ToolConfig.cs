﻿
using MorningStarWebTool.DataLayer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MorningStarWebTool.DataLayer.Class
{
    public class ToolConfig : IMSToolConfig
    {       
        
        public ToolConfig()
        {
           
            //_wimFundEntities = new WIMFundsEntities();
        }
        public List<Entites.Entities.ToolConfig> GetMSToolConfig()
        {   

            return null;
        }
    }
}
