﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMI.Quotes.Entities.Profiles;

namespace WIMI.Quotes.Entities
{
    public class SolutionQuoteItem
    {
        public string AdvisorCode { get; set; }
        public string ClientNumber { get; set; }
        public string ProductCode { get; set; }
        public int AkmId { get; set; }

        public LumpSum LumpSum { get; set; }
        public DebitOrder DebitOrder { get; set; }
        public Income Income { get; set; }
        public GuaranteedGrowth GuaranteedGrowth { get; set; }
        public GuaranteedIncome GuaranteedIncome { get; set; }
        public Fees Fees { get; set; }
    }
}
