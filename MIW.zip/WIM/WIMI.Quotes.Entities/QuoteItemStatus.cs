﻿namespace WIMI.Quotes.Entities
{
    public enum QuoteItemStatus
    {
        Incomplete = 0,
        Complete = 1,
        Historical = 2
    }
}
