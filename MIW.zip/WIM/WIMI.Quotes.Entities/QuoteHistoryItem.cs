﻿using System;

namespace WIMI.Quotes.Entities
{
    public class QuoteHistoryItem
    {
        public int? QuoteNumber { get; set; }
        public Guid QuoteItemId { get; set; }
        public QuoteItemStatus Status { get; set; }
        public DateTime CreatedDate { get; set; }
        public string AdvisorCode { get; set; }
        public string ClientNumber { get; set; }
        public string Description { get; set; }
        public string ReportUrl { get; set; }
        public bool CanTransact { get; set; }
    }
}
