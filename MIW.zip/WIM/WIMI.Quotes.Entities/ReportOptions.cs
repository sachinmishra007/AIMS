﻿using System;

namespace WIMI.Quotes.Entities
{
    public class ReportOptions
    {
        public Guid QuoteItemId { get; set; }
        public ReportType ReportType { get; set; }
        public Language Language { get; set; }

        public bool IncludeAssetAllocations { get; set; }
        public bool IncludeProductBrochure { get; set; }
        public bool IncludeRegulation28 { get; set; }
    }
}
