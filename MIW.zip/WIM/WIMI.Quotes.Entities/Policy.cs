﻿namespace WIMI.Quotes.Entities
{
    public class Policy
    {
        public string PolicyNumber { get; set; }
        public decimal? LatestMarketValue { get; set; }
        public string ProductCode { get; set; }
        public int? CaNumber { get; set; }
        public string ClientNumber { get; set; }
        public bool? IsActive { get; set; }
        public string BDANumber { get; set; }
       
    }
}
