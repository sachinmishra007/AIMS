﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ReportType
    {
        ShortQuote,
        FullQuote
    }
}
