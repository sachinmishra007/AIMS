﻿namespace WIMI.Quotes.Entities
{
    public enum ProductType
    {
        Discretionary = 0,
        Contractual = 1
    }
}
