﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities.Profiles
{
    public class GuaranteedGrowth : IProfile
    {
        #region Interface Members

        [JsonConverter(typeof(StringEnumConverter))]
        public ProfileType Type
        {
            get { return ProfileType.GuaranteedGrowth; }
        }

        public string Description { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisible { get; set; }

        #endregion

        [JsonConverter(typeof(StringEnumConverter))]
        public GuaranteedGrowthType GrowthType { get; set; }

        public double Amount { get; set; }
        public double CommissionPercentage { get; set; }
        public double MaturityValue { get; set; }
        public double DiscountFee { get; set; }
    }
}
