﻿using System.Collections.Generic;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities.Profiles
{
    public class DebitOrder : IProfile, IFundsProfile, IRegulation28Profile
    {
        #region Interface Members

        [JsonConverter(typeof(StringEnumConverter))]
        public ProfileType Type
        {
            get { return ProfileType.DebitOrder; }
        }

        public string Description { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisible { get; set; }

        #endregion

        public double Amount { get; set; }
        public double EscalationPercentage { get; set; }
        public bool? IsRegulation28Compliant { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public Frequency Frequency { get; set; }

        public List<Fund> Funds { get; set; }
    }
}
