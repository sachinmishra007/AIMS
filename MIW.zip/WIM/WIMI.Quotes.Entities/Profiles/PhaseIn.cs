﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;

namespace WIMI.Quotes.Entities.Profiles
{
    public class PhaseIn : IProfile, IFundsProfile, IRegulation28Profile
    {
        #region Interface Members

        [JsonConverter(typeof(StringEnumConverter))]
        public ProfileType Type
        {
            get { return ProfileType.PhaseIn; }
        }

        public string Description { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisible { get; set; }

        #endregion

        public double Amount { get; set; }
        public double PhaseInLumpSumAmount { get; set; }
        public DateTime PhaseInCommencementDate { get; set; }
        
        public bool? IsRegulation28Compliant { get; set; }
        
        public List<Fund> Funds { get; set; }
    }
}
