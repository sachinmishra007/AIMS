﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities.Profiles
{
    public class Fees : IProfile
    {
        public Fees()
        {
            VatVendor = true;
        }

        #region Interface Members

        [JsonConverter(typeof(StringEnumConverter))]
        public ProfileType Type
        {
            get { return ProfileType.Fees; }
        }

        public string Description { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisible { get; set; }

        #endregion

        public string SpecialFeeRefNo { get; set; }
        public bool VatVendor { get; set; }

        public decimal AdvisorInitialFee { get; set; }
        public decimal AdvisorRecurringFee { get; set; }
        public decimal AdvisorOngoingFee { get; set; }
        public decimal ExistingAdvisorOngoingFee { get; set; }
    }
}
