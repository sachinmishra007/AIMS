﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities.Profiles
{
    public class GuaranteedIncome : IProfile
    {
        #region Interface Members

        [JsonConverter(typeof(StringEnumConverter))]
        public ProfileType Type
        {
            get { return ProfileType.GuaranteedIncome; }
        }

        public string Description { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisible { get; set; }

        #endregion

        [JsonConverter(typeof(StringEnumConverter))]
        public GuaranteedIncomeType IncomeType { get; set; }

        public double InvestmentAmount { get; set; }
        public double IncomeAmount { get; set; }
        public double MonthlyIncome { get; set; }
        public double CommissionPercentage { get; set; }
        public double MaturityValue { get; set; }
        public double InterestRate { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public TaxationMethod TaxationMethod { get; set; }

        public double DirectivePercentage { get; set; }
    }
}
