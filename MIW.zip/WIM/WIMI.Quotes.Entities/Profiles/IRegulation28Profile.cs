﻿namespace WIMI.Quotes.Entities.Profiles
{
    public interface IRegulation28Profile
    {
        bool? IsRegulation28Compliant { get; set; }
    }
}
