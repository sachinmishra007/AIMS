﻿
namespace WIMI.Quotes.Entities.Profiles
{
    public interface IProfile
    {
        ProfileType Type { get; }
        string Description { get; set; }
        bool IsActive { get; set; }
        bool IsVisible { get; set; }
    }
}
