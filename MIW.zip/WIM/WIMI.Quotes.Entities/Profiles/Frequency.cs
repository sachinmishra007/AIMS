﻿using System.ComponentModel;

namespace WIMI.Quotes.Entities.Profiles
{
    public enum Frequency
    {
        [Description("Monthly")]
        Monthly = 12,
        [Description("Quarterly")]
        Quarterly = 4,
        [Description("Half Annual")]
        HalfYearly = 2,
        [Description("Annual")]
        Yearly = 1
    }
}
