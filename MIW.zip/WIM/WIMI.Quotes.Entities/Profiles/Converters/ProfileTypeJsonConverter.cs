﻿using System;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace WIMI.Quotes.Entities.Profiles.Converters
{
    public class ProfilesTypeJsonConverter : JsonConverter
    {
        private const string TypePropertyKey = "Type";

        public override bool CanConvert(Type objectType)
        {
            return typeof(IProfile).IsAssignableFrom(objectType);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            var profile = JToken.Load(reader);

            if (profile != null && profile[TypePropertyKey] != null)
            {
                var className = profile[TypePropertyKey].Value<string>();
                var type = Type.GetType(String.Format("{0}.{1}, {2}", objectType.Namespace, className, objectType.Assembly.FullName));

                return profile.ToObject(type);
            }

            return null;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            serializer.Serialize(writer, value, value.GetType());
        }
    }
}
