﻿using System.Collections.Generic;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities.Profiles
{
    public class Income : IProfile, IFundsProfile
    {
        #region Interface Members

        [JsonConverter(typeof(StringEnumConverter))]
        public ProfileType Type
        {
            get { return ProfileType.Income; }
        }

        public string Description { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisible { get; set; }

        #endregion

        public double Amount { get; set; }
        public double Percentage { get; set; }
        public double EscalationPercentage { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public Frequency Frequency { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public IncomeType? IncomeType { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        public TaxationMethod TaxationMethod { get; set; }
        public DistributionMethod DistributionMethod { get; set; }

        public double PreferredTaxRate { get; set; }

        public List<Fund> Funds { get; set; }
    }
}
