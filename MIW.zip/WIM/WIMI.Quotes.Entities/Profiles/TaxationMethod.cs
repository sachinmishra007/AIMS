﻿using System.ComponentModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities.Profiles
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum TaxationMethod
    {
        [Description("PAYE")]
        PAYE = 0,
        [Description("Directive")]
        Directive = 1
    }
}
