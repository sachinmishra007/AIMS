﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities.Profiles
{
    [JsonConverter(typeof(StringEnumConverter))]
    public enum DistributionMethod
    {
        Reinvest,
        Payout
    }
}
