﻿using System.Collections.Generic;

namespace WIMI.Quotes.Entities.Profiles
{
    public interface IFundsProfile
    {
        List<Fund> Funds { get; set; }
    }
}
