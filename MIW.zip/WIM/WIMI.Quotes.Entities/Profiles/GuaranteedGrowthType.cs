﻿using System.ComponentModel;

namespace WIMI.Quotes.Entities.Profiles
{
    public enum GuaranteedGrowthType
    {
        [Description("Growth")]
        Growth = 0,
        [Description("Capital")]
        Capital = 1
    }
}
