﻿
namespace WIMI.Quotes.Entities.Profiles
{
    public enum ProfileType
    {
        LumpSum,
        DebitOrder,
        Income,
        Fees,
        GuaranteedGrowth,
        GuaranteedIncome,
        Addition,
        PhaseIn
    }
}
