﻿namespace WIMI.Quotes.Entities.Profiles
{
    public enum IncomeType
    {
        Percentage,
        Amount
    }
}
