﻿using System.ComponentModel;

namespace WIMI.Quotes.Entities.Profiles
{
    public enum GuaranteedIncomeType
    {
        [Description("Income")]
        Income = 0,
        [Description("Investment")]
        Investment = 1
    }
}
