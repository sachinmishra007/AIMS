﻿using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities.Profiles
{
    public class LumpSum : IProfile, IFundsProfile, IRegulation28Profile
    {
        #region Interface Members

        [JsonConverter(typeof(StringEnumConverter))]
        public ProfileType Type
        {
            get { return ProfileType.LumpSum; }
        }

        public string Description { get; set; }

        public bool IsActive { get; set; }
        public bool IsVisible { get; set; }

        #endregion

        public double Amount { get; set; }
        public bool? IsRegulation28Compliant { get; set; }
        public string PolicyNumber { get; set; }
        public double PolicyMarketValue { get; set; }
        public string BDANumber { get; set; }
        
        public List<Fund> Funds { get; set; }
    }
}
