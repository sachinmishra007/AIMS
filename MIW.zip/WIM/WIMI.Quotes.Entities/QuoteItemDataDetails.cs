﻿using System;

namespace WIMI.Quotes.Entities
{
    public class QuoteItemDataDetails
    {
        public Guid QuoteItemId { get; set; }

        public QuoteItemStatus? Status { get; set; }
        public int? QuoteNumber { get; set; }
        public string ReportFileName { get; set; }
    }
}
