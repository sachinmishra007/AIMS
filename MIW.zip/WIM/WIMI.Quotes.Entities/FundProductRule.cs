﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMI.Quotes.Entities
{
    public class FundProductRule
    {
        public decimal Amount { get; set; }
        public string ProductId { get; set; }
        public string RuleId { get; set; }
        public int TransactionTypeId { get; set; }
        public bool IsValid { get; set; }
        public string ClientNumber { get; set; }
        public decimal? AssociatedFundAmnt { get; set; }
        public decimal? AssociatedFundPercentage { get; set; }
        public decimal? TopUpFrequency { get; set; }
        public decimal? MinFundAmount { get; set; }
        public string FundId { get; set; }
        public string FundName { get; set; }

    }
}


