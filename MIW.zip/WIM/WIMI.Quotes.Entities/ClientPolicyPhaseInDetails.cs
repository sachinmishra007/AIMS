﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMI.Quotes.Entities
{
    public class ClientPolicyPhaseInDetails
    {
        public string FundName { get; set; }
        public Nullable<double> PercSplit { get; set; }
        public string FundCode { get; set; }

    }
}
