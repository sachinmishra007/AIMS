﻿using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities
{
    public class Validation
    {
        public Validation()
        {
            ChildValidations = new List<Validation>();
        }

        [JsonConverter(typeof(StringEnumConverter))]
        public ValidationType Type { get; set; }

        public int Id { get; set; }
        public string MethodName { get; set; }
        public string FieldName { get; set; }
        public string ContainerClass { get; set; }
        public string Message { get; set; }

        public IDictionary<string, object> Parameters { get; set; }
        public bool ValidateChildrenOnValid { get; set; }
        public List<Validation> ChildValidations { get; set; }
    }
}
