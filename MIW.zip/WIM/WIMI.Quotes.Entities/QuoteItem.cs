﻿using System;
using System.Collections.Generic;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities
{
    public class QuoteItem
    {
        public QuoteItem()
        {
            Profiles = new List<Profiles.IProfile>();
        }

        public Guid QuoteItemId { get; set; }
        public int? QuoteNumber { get; set; }
        public int AkmId { get; set; }

        [JsonConverter(typeof(StringEnumConverter))]
        [JsonProperty(ItemConverterType = typeof(StringEnumConverter))]
        public QuoteItemStatus Status { get; set; }

        public int Term { get; set; }

        public Product Product { get; set; }
        public Client Client { get; set; }
        public Advisor Advisor { get; set; }
        public Currency Currency { get; set; }
        public ReportOptions ReportOptions { get; set; }

        [JsonProperty(ItemConverterType = typeof(Profiles.Converters.ProfilesTypeJsonConverter))]
        public List<Profiles.IProfile> Profiles { get; set; }
        public List<Entities.FundFactSheet> FundFactSheets { get; set; }
    }
}
