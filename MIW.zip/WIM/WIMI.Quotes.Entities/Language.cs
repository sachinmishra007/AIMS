﻿using System.Xml.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities
{
    [JsonConverter(typeof(StringEnumConverter))]
    [XmlType(TypeName="Entities.Language")]
    public enum Language
    {
        English,
        Afrikaans
    }
}
