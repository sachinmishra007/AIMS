﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMI.Quotes.Entities
{
    public class TaxYears
    {
        public int TaxYearId { get; set; }
        public Nullable<System.DateTime> StartDate { get; set; }
        public Nullable<System.DateTime> EndDate { get; set; }
        public Nullable<int> StartYear { get; set; }
        public Nullable<int> EndYear { get; set; }
    }
}
