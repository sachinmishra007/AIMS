﻿namespace WIMI.Quotes.Entities
{
    public class FundFactSheet
    {
        public string Name { get; set; }
        public string Code { get; set; }
        public string Url { get; set; }
    }
}
