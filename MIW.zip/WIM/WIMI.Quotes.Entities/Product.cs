﻿using System.Collections.Generic;

using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

using WIMI.Quotes.Entities.Profiles;

namespace WIMI.Quotes.Entities
{
    public class Product
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public ProductType Type { get; set; }
        public bool IsOffshore { get; set; }
        public bool IsRegulation28Required { get; set; }
        public bool IsGuaranteedProduct { get; set; }
        public bool HasRecurringFees { get; set; }
        public bool HasOngoingFees { get; set; }
        public int Term { get; set; }

        [JsonProperty(ItemConverterType = typeof(StringEnumConverter))]
        public List<ProfileType> ProfileTypes { get; set; }
    }
}
