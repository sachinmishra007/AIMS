﻿namespace WIMI.Quotes.Entities
{
    public enum ValidationType
    {
        Error = 1,
        Warning = 2
    }
}
