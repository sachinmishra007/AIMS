﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WIMI.Quotes.Entities
{
    public class Client
    {
        public int ClientID { get; set; }
        public string ClientNumber { get; set; }
        public string ClientType { get; set; }
        public string ClientSubType { get; set; }
        public int OrganisationTypeLookupID { get; set; }
        public string Language { get; set; }
        public string IdentificationType { get; set; }
        public string Title { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string IDNumber { get; set; }
        public string FullName { get; set; }
        public string DateOfBirth { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public string Staff { get; set; }
        public string Advisor { get; set; }
        public bool IsTempClient { get; set; }
        public string MemberType { get; set; }
        public string EntityName { get; set; }
        public string EntityType { get; set; }
    }
}
