﻿
namespace WIMI.Quotes.Entities
{
    public class Advisor
    {
        public string Code { get; set; }
        public string Surname { get; set; }
        public string FirstName { get; set; }
        public string FullName { get; set; }
        public string Brokerage { get; set; }
        public bool VatVendor { get; set; }
        public decimal ExistingAdvisorOngoingFee { get; set; }
    }
}
