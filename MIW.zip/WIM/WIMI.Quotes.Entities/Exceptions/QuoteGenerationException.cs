﻿using System;

namespace WIMI.Quotes.Entities.Exceptions
{
    public class QuoteGenerationException : Exception
    {
        #region Constructors & Private Members

        private const string ToStringFormat = "QuoteItemId: {0}\nException:\n{1}";

        public QuoteGenerationException(Exception exception, Guid quoteItemId)
            : base(exception != null ? exception.Message : String.Empty, exception)
        {
            QuoteItemId = quoteItemId;
        }

        #endregion

        #region Public Properties

        public Guid QuoteItemId { get; set; }

        #endregion

        #region Public Overrides

        public override string ToString()
        {
            return String.Format(ToStringFormat, QuoteItemId, base.ToString());
        }

        #endregion
    }
}
