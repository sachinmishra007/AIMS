﻿using System;

namespace WIMI.Quotes.Entities.Exceptions
{
    public class ValidationException : Exception
    {
        #region Constructors & Private Members

        public ValidationException(string message)
            : base(message) {}

        #endregion
    }
}
