﻿namespace WIMI.Quotes.Entities
{
    public class Fund
    {
        public string Name { get; set; }
        public string Code { get; set; }
        public string Type { get; set; }
        public double Amount { get; set; }
        public double Percentage { get; set; }
        public bool? IsSharedPortfolio { get; set; }
        public bool? IsEtf { get; set; }
        public bool? IsPhaseRemove { get; set; }
    }
}
