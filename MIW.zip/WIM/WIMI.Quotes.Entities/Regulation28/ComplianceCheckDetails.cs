﻿using System.Collections.Generic;

namespace WIMI.Quotes.Entities.Regulation28
{
    public class ComplianceCheckDetails
    {
        public ComplianceCheckDetails()
        {
            Funds = new List<Fund>();
        }

        public string ClientNumber { get; set; }
        public string ProductCode { get; set; }
        public InstructionType Type { get; set; }
        public List<Fund> ExistingPortfolioFunds { get; set; }

        public List<Fund> Funds { get; set; }
    }
}
