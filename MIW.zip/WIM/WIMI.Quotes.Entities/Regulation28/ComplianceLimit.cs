﻿namespace WIMI.Quotes.Entities.Regulation28
{
    public class ComplianceLimit
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public double Value { get; set; }
        public double Regulation28LimitValue { get; set; }
        public bool IsLimitCompliant { get; set; }
    }
}
