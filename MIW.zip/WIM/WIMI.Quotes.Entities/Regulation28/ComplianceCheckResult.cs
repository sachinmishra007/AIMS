﻿using System.Collections.Generic;

namespace WIMI.Quotes.Entities.Regulation28
{
    public class ComplianceCheckResult
    {
        public ComplianceCheckResult()
        {
            FundCompliance = new List<FundCompliance>();
        }

        public bool IsOverallCompliant { get; set; }
        public List<FundCompliance> FundCompliance { get; set; }
        public List<ComplianceLimit> OverallComplianceLimits { get; set; } 
    }
}
