﻿namespace WIMI.Quotes.Entities.Regulation28
{
    public enum InstructionType
    {
        NewBusiness,
        Addition
    }
}
