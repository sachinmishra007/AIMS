﻿using System.Collections.Generic;

namespace WIMI.Quotes.Entities.Regulation28
{
    public class FundCompliance
    {
        public FundCompliance()
        {
            ComplianceLimits = new List<ComplianceLimit>();
        }

        public string FundCode { get; set; }
        public string FundName { get; set; }
        public decimal FundAmount { get; set; }
        public decimal FundPercentage { get; set; }
        public bool IsFundCompliant { get; set; }
        public List<ComplianceLimit> ComplianceLimits { get; set; }
    }
}
