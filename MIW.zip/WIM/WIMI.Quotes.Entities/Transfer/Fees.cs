﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMI.Quotes.Entities.Transfer
{
    public class Fees
    {
        public double AnnualAdminFee { get; set; }
        public double AnnualProcessingFee { get; set; }
        public double InitialFee { get; set; }
        public double DebitORderFee { get; set; }
        public double AnnualFee { get; set; }
    }
}
