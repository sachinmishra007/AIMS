﻿using System.Collections.Generic;

namespace WIMI.Quotes.Entities.Transfer
{
    public class Income
    {
        public double Amount { get; set; }
        public double Percentage { get; set; }
        public IncomeType IncomeType { get; set; }
        public double EscalationPercentage { get; set; }
        public FrequencyType Frequency { get; set; }
        public DistributionMethod DistributionMethod { get; set; }
        public bool IsIncomeEqualsLumpSum { get; set; }

        public List<Fund> Funds { get; set; } 
    }
}
