﻿namespace WIMI.Quotes.Entities.Transfer
{
    public enum DistributionMethod
    {
        Reinvest,
        Payout
    }
}
