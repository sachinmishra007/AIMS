﻿namespace WIMI.Quotes.Entities.Transfer
{
    public class GuaranteedSeries
    {
        public int QuoteNumber { get; set; }
        public string ProductCode { get; set; }
        public GuaranteedGrowth Growth { get; set; }
        public GuaranteedIncome Income { get; set; }
    }
}
