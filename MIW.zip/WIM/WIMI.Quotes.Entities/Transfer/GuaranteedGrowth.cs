﻿using System;

using WIMI.Quotes.Entities.Profiles;

namespace WIMI.Quotes.Entities.Transfer
{
    public class GuaranteedGrowth
    {
        public GuaranteedGrowthType GrowthType { get; set; }

        public double InvestmentAmount { get; set; }
        public double MaturityValue { get; set; }
        public DateTime MaturityDate { get; set; }

        public double AdminFeePercentage { get; set; }
        public double AdminLifeFeePercentage { get; set; }
        public double TaxLossFeePercentage { get; set; }
        public double AdvisorCommissionPercentage { get; set; }
    }
}
