﻿namespace WIMI.Quotes.Entities.Transfer
{
    public enum FundType
    {
        Individual,
        Wrap,
        SharePortfolio
    }
}
