﻿namespace WIMI.Quotes.Entities.Transfer
{
    public enum IncomeType
    {
        Amount = 0,
        Percentage = 1
    }
}
