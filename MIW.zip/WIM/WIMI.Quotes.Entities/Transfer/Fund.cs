﻿namespace WIMI.Quotes.Entities.Transfer
{
    public class Fund
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public FundType FundType { get; set; }
        public bool IsWealthSeries { get; set; }
        public bool IsEtfFund { get; set; }

        public double GrossAmount { get; set; }
        public double NettAmount { get; set; }
        public double Percentage { get; set; }
    }
}
