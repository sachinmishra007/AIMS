﻿namespace WIMI.Quotes.Entities.Transfer
{
    public enum FrequencyType
    {
        Initial = 1,
        Daily = 2,
        Weekly = 3,
        Monthly = 4,
        Quarterly = 5,
        HalfAnnual = 6,
        Annual = 7,
        MaturityRollOver = 8
    }
}
