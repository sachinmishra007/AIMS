﻿using System;
using System.Collections.Generic;

namespace WIMI.Quotes.Entities.Transfer
{
    public class PhaseIn
    {
        public double Amount { get; set; }
        public double PhaseInLumpSumAmount { get; set; }
        public DateTime PhaseInCommencementDate { get; set; }

        public bool? IsRegulation28Compliant { get; set; }

        public List<Fund> PhaseFromFunds { get; set; } 
        public List<Fund> Funds { get; set; }
        public Fund PhaseFromFund { get; set; }
    }
}
