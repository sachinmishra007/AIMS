﻿namespace WIMI.Quotes.Entities.Transfer
{
    public enum FormStatus
    {
        Incomplete = 0,
        Complete = 1,
        Cancelled = 2
    }
}
