﻿using System.Collections.Generic;

namespace WIMI.Quotes.Entities.Transfer
{
    public class DebitOrder
    {
        public double GrossAmount { get; set; }
        public double NettAmount { get; set; }
        public double EscalationPercentage { get; set; }
        public FrequencyType Frequency { get; set; }

        public List<Fund> Funds { get; set; } 
    }
}
