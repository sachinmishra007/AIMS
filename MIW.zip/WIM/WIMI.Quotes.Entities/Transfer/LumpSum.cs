﻿using System.Collections.Generic;

namespace WIMI.Quotes.Entities.Transfer
{
    public class LumpSum
    {
        public double GrossAmount { get; set; }
        public double NettAmount { get; set; }
        public string BDANumber { get; set; }
        public List<Fund> Funds { get; set; } 
    }
}
