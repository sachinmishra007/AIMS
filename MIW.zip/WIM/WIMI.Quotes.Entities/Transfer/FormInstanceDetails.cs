﻿using System;

namespace WIMI.Quotes.Entities.Transfer
{
    public class FormInstanceDetails
    {
        public Guid InstanceId { get; set; }
        public FormStatus FormStatus { get; set; }
        public string ClientNumber { get; set; }
        public string BrokerCode { get; set; }
    }
}
