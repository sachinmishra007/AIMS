﻿using System;
using System.Collections.Generic;

using WIMI.Quotes.ServiceReferences.WIMQuotesWCFService;

namespace WIMI.Quotes.Entities
{
    [Serializable]
    public class QuoteReportData
    {
        #region Constructor

        public QuoteReportData()
        {
            ConsolidatedFundCodes = new List<string>();
            ReportOptions = new ReportOptions();
        }

        #endregion

        public Guid QuoteItemId { get; set; }
        public int QuoteNumber { get; set; }
        public int AkmId { get; set; }

        public ReportOptions ReportOptions { get; set; }
        public Product Product { get; set; }
        public Client Client { get; set; }
        public Advisor Advisor { get; set; }
        public List<string> ConsolidatedFundCodes { get; set; } 

        public Investment Quote { get; set; }
        public GuaranteedSeries GuaranteedSeries { get; set; }
    }
}
