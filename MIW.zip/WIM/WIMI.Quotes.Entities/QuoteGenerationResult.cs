﻿namespace WIMI.Quotes.Entities
{
    public class QuoteGenerationResult
    {
        public int? QuoteGroupId { get; set; }
        public int? QuoteNumber { get; set; }
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
    }
}
