﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using WIMI.Quotes.Common.Extensions;
using WIMI.Quotes.Repositories.Contracts;

namespace WIMI.Quotes.Repositories
{
    public class WIMQuotesDataRepository : IWIMQuotesDataRepository
    {

        #region History

        public List<Entities.QuoteHistoryItem> GetQuoteHistoryItems(
            string advisorNumber,
            string clientNumber,
            Entities.QuoteItemStatus status)
        {
            Data.WIMQuotesEntities context = null;

            try
            {
                using (context = new Data.WIMQuotesEntities())
                {
                    return context.pGetWorkInProgressHistory(advisorNumber, clientNumber, (int)status)
                        .Select(w => new Entities.QuoteHistoryItem
                        {
                            QuoteItemId = w.QuoteItemId,
                            Status = (Entities.QuoteItemStatus)w.Status,
                            AdvisorCode = w.BrokerCode,
                            Description = w.Description,
                            CreatedDate = w.CreatedOn
                        }).ToList();
                }
            }
            finally
            {
                if (context != null)
                {
                    context.Dispose();
                }
            }
        }

        #endregion

        #region Quote Items

        public Entities.QuoteItem GetQuoteItem(Guid quoteItemId)
        {
            Data.WIMQuotesEntities context = null;

            try
            {
                using (context = new Data.WIMQuotesEntities())
                {
                    var result = context.WorkInProgresses.SingleOrDefault(w => w.QuoteItemId == quoteItemId);
                    return result != null ? JsonConvert.DeserializeObject<Entities.QuoteItem>(result.SerialisedData) : null;
                }
            }
            finally
            {
                if (context != null)
                {
                    context.Dispose();
                }
            }
        }

        public List<Entities.QuoteItem> GetQuoteItems(Guid quoteGroupId)
        {
            Data.WIMQuotesEntities context = null;
            var group = new List<Entities.QuoteItem>();

            try
            {
                using (context = new Data.WIMQuotesEntities())
                {
                    var result = context.QuoteGroups.Where(w => w.QuoteGroupId == quoteGroupId)
                                                    .Select(f => new Entities.QuoteGroup{ QuoteItemId = f.QuoteItemId});

                    foreach (var item in result)
                    {
                        group.Add(GetQuoteItem(item.QuoteItemId.ToGuid()));
                    }

                    return group;
                }
            }
            finally
            {
                if (context != null)
                {
                    context.Dispose();
                }
            }
        }

        public Entities.QuoteItem GetQuoteItem(int quoteNumber)
        {
            Data.WIMQuotesEntities context = null;

            try
            {
                using (context = new Data.WIMQuotesEntities())
                {
                    var result = context.WorkInProgresses.SingleOrDefault(w => w.QuoteNumber == quoteNumber);

                    if (result == null)
                        return null;

                    var quoteItem = JsonConvert.DeserializeObject<Entities.QuoteItem>(result.SerialisedData);

                    if (quoteItem == null)
                        return null;

                    quoteItem.QuoteNumber = result.QuoteNumber;
                    quoteItem.Status = (Entities.QuoteItemStatus) result.Status;

                    return quoteItem;
                }
            }
            finally
            {
                if (context != null)
                {
                    context.Dispose();
                }
            }
        }

        public void SaveQuoteItem(Entities.QuoteItem quoteItem, string userId)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var workInProgress = new Data.WorkInProgress
                {
                    QuoteItemId = quoteItem.QuoteItemId,
                    BrokerCode = (quoteItem.Advisor != null ? quoteItem.Advisor.Code : String.Empty),
                    ClientNumber = (quoteItem.Client != null ? quoteItem.Client.ClientNumber : String.Empty),
                    ProductCode = quoteItem.Product.Code,
                    Description = quoteItem.Product.Name,
                    UserId = userId,
                    CreatedOn = DateTime.Now,
                    SerialisedData = JsonConvert.SerializeObject(quoteItem)
                };

                var persistedInstance = context.WorkInProgresses.SingleOrDefault(w => w.QuoteItemId == quoteItem.QuoteItemId);
                
                if (persistedInstance == null)
                {
                    context.WorkInProgresses.Add(workInProgress);
                }
                else
                {
                    persistedInstance.BrokerCode = workInProgress.BrokerCode;
                    persistedInstance.ClientNumber = workInProgress.ClientNumber;
                    persistedInstance.ProductCode = workInProgress.ProductCode;
                    persistedInstance.Description = workInProgress.Description;
                    persistedInstance.UserId = workInProgress.UserId;
                    persistedInstance.CreatedOn = workInProgress.CreatedOn;
                    persistedInstance.SerialisedData = workInProgress.SerialisedData;
                }
                
                context.SaveChanges();
            }
        }

        public void UpdateQuoteItemDataDetails(Entities.QuoteItemDataDetails quoteItemDataDetails)
        {
            if (quoteItemDataDetails == null || quoteItemDataDetails.QuoteItemId == Guid.Empty)
                return;

            using (var context = new Data.WIMQuotesEntities())
            {
                var persistedInstance = context.WorkInProgresses.SingleOrDefault(w => w.QuoteItemId == quoteItemDataDetails.QuoteItemId);

                if (persistedInstance == null)
                    return;

                if (quoteItemDataDetails.Status.HasValue)
                    persistedInstance.Status = (int)quoteItemDataDetails.Status;

                if (quoteItemDataDetails.QuoteNumber.HasValue)
                    persistedInstance.QuoteNumber = quoteItemDataDetails.QuoteNumber.Value;

                if (quoteItemDataDetails.ReportFileName != null)
                    persistedInstance.ReportFileName = quoteItemDataDetails.ReportFileName;

                context.SaveChanges();
            }
        }

        public void SaveQuoteGroup(Guid quoteGroupId, Guid quoteItemId)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var quoteGroup = new Data.QuoteGroup
                {
                    QuoteGroupId = quoteGroupId,
                    QuoteItemId = quoteItemId.ToString()
                };

                context.QuoteGroups.Add(quoteGroup);
                context.SaveChanges();
            }
        }

        #endregion

        #region Report Data

        public string GetQuoteReportFileName(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var persistedInstance = context.WorkInProgresses.SingleOrDefault(w => w.QuoteNumber == quoteNumber);
                return persistedInstance != null ? persistedInstance.ReportFileName : String.Empty;
            }
        }

        /// <summary>
        /// Returns the broker that was captured against the Quote Report Data by the supplie <param name="quoteNumber">quoteNumber</param>
        /// </summary>
        /// <param name="quoteNumber">Quote Number to return the Broker Code for</param>
        /// <returns>string of Broker Code</returns>
        public string GetQuoteReportBroker(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var reportData = context.ReportDatas.FirstOrDefault(r => r.QuoteNumber == quoteNumber);
                return reportData != null ? reportData.BrokerCode : null;
            }
        }

        public void UpdateQuoteAkmId(int quoteNumber, int akmId)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                context.pUpdateQuoteAkmId(quoteNumber, akmId);
            }
        }

        #endregion

        #region Funds

        public List<Entities.Fund> GetFundsList(string productCode, string fundRangeCode, string brokerCode)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var funds = context.pGetFundListQuotes(productCode, brokerCode, fundRangeCode);

                if (funds == null)
                    return new List<Entities.Fund>();

                return funds.Select(f => new Entities.Fund
                {
                    Code = f.Code,
                    Name = f.Name,
                    Type = f.FundType,
                    IsSharedPortfolio = f.IsSharedPortfolio
                }).ToList();
            }
        }

        public List<Entities.Fund> GetQuoteConsolidatedFunds(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var funds = context.pGetQuoteConsolidatedFunds(quoteNumber);

                if (funds == null)
                    return new List<Entities.Fund>();

                return funds.Select(f => new Entities.Fund
                {
                    Code = f
                }).ToList();
            }
        }

        #endregion

        #region Products

        public Entities.Product GetProduct(string productCode)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var products = context.pGetQuoteProduct(productCode);

                if (products == null || !products.Any())
                    return null;

                return Mappings.WIMQuotesDataMappings.ToProduct(products.First());
            }
        }

        public IEnumerable<Entities.Product> GetProductsList(string brokerCode, string clientType, string clientSubType)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var products = context.pGetQuoteProducts(brokerCode, clientType, clientSubType);

                if (products == null)
                    return new List<Entities.Product>();

                return products.Select(Mappings.WIMQuotesDataMappings.ToProduct).ToList();
            }
        }

        #endregion

        #region Validations

        public List<Entities.Validation> GetValidations(string productCode, string brokerCode, int stepId)
        {
            List<Data.Validation> contextValidations;

            using (var context = new Data.WIMQuotesEntities())
            {
                contextValidations = context.pGetQuoteValidations(productCode, brokerCode, stepId).ToList();
            }

            var validations = contextValidations
                .Where(v => !v.ParentId.HasValue && v.IsActive)
                .Select(Mappings.WIMQuotesDataMappings.ToValidation).ToList();

            GetValidationsRecursive(contextValidations, validations);

            return validations;
        }

        private void GetValidationsRecursive(List<Data.Validation> contextValidations, IEnumerable<Entities.Validation> validations)
        {
            foreach (var validation in validations)
            {
                validation.ChildValidations = contextValidations
                    .Where(v => v.ParentId == validation.Id)
                    .Select(Mappings.WIMQuotesDataMappings.ToValidation).ToList();

                GetValidationsRecursive(contextValidations, validation.ChildValidations);
            }
        }

        public Entities.ClientContribution GetClientContribution(string clientNumber, string productCode)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var contributions = context.pGetContributionsMade(clientNumber, productCode).FirstOrDefault();

                if (contributions == null)
                    return null;

                return new Entities.ClientContribution
                {
                    RemainingNettLife = (double)contributions.RemainingNettLife.GetValueOrDefault(),
                    RemainingNettTaxYear =(double) contributions.RemainingNettTaxYear.GetValueOrDefault()
                };
            }
        }

        #endregion

        #region Lookups

        public List<Entities.LookupItem> GetLookupData(string lookupCode)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var lookupItems = context.pGetLookupData(lookupCode);

                if (lookupItems == null)
                    return new List<Entities.LookupItem>();

                return lookupItems.Select(l => new Entities.LookupItem
                {
                    Code = l.Code,
                    Description = l.Description
                }).ToList();
            }
        }

        #endregion

        #region TaxYear

        public List<Entities.TaxYears> GetTaxYearData()
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var taxYears = context.pFindTaxYearDifference();

                if (taxYears == null)
                    return new List<Entities.TaxYears>();

                return taxYears.Select(t => new Entities.TaxYears
                {
                    TaxYearId = t.TaxYearId,
                    StartDate = t.StartDate,
                    EndDate = t.EndDate,
                    StartYear = t.StartYear,
                    EndYear = t.EndYear

                }).ToList();
            }
        }

        #endregion

        #region Client

        public bool CanAdvisorAccessClient(string clientNumber, string brokerCode)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var results = context.pGetCanAdvisorAccessClient(clientNumber, brokerCode);

                if (results == null)
                    return false;

                bool? canAccess = results.FirstOrDefault();
                return canAccess.GetValueOrDefault();
            }
        }

        public List<Entities.Policy> GetClientProductPolicies(string clientNumber, string productCode)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var results = context.pGetClientProductPolicies(clientNumber, productCode);

                if (results == null)
                    return null;

                return results.Select(p => new Entities.Policy
                {
                    PolicyNumber = p.PolicyNumber
                }).ToList();
            }
        }

        public List<Entities.Fund> GetClientProductPortfolio(string clientNumber, string productCode)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var results = context.pGetClientProductPortfolio(clientNumber, productCode);

                if (results == null)
                    return null;

                return results.Select(r => new Entities.Fund
                {
                    Code = r.FundCode,
                    Name = r.FundName,
                    Amount = (double)r.RandValue.GetValueOrDefault()
                }).ToList();
            }
        }

        #endregion
    }
}
