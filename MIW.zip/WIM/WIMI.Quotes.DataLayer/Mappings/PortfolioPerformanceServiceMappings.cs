﻿using System.Collections.Generic;
using System.Linq;

using WIMI.Quotes.ServiceReferences.PortfolioPerformanceService;

namespace WIMI.Quotes.Repositories.Mappings
{
    public static class PortfolioPerformanceServiceMappings
    {
        public static List<Fund> ToFunds(List<Entities.Fund> funds)
        {
            return funds.Select(f => new Fund
            {
                Code = f.Code,
                Name = f.Name,
                PercentageSplit = (decimal)f.Percentage
            }).ToList();
        }

        public static Language ToLanguage(Entities.Language language)
        {
            switch (language)
            {
                case Entities.Language.Afrikaans:
                    return Language.Afrikaans;
                default:
                    return Language.English;
            }
        }

        public static Entities.FundFactSheet FromFundFactSheet(FundFactSheet fundFactSheet)
        {
            return new Entities.FundFactSheet
            {
                Code = fundFactSheet.FundCode,
                Name = fundFactSheet.FundName,
                Url = fundFactSheet.MorningStarURL
            };
        }
    }
}
