﻿namespace WIMI.Quotes.Repositories.Mappings.MappingTypes
{
    public enum CategoryType
    {
        Administrator = 1,
        Advisor = 2
    }
}