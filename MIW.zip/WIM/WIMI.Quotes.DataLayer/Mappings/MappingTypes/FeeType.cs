﻿namespace WIMI.Quotes.Repositories.Mappings.MappingTypes
{
    public enum FeeType
    {
        InitialFee = 1,
        OngoingFee = 2,
        RecurringFee = 3,
        PhaseInInitialFee = 4,
        PhaseInOngoingFee = 5,
        ExistingOngoingFee = 6
    }
}
