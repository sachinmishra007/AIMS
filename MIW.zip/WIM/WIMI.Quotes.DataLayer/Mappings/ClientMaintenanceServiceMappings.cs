﻿using WIMI.Quotes.ServiceReferences.ClientMaintenanceService;

namespace WIMI.Quotes.Repositories.Mappings
{
    public static class ClientMaintenanceServiceMappings
    {
        public static Gender? ToGender(string gender)
        {
            switch (gender)
            {
                case "Male":
                    return Gender.Male;
                case "Female":
                    return Gender.Female;
                default:
                    return null;
            }
        }

        public static Language? ToLanguage(string language)
        {
            switch (language)
            {
                case "English":
                    return Language.English;
                case "Afrikaans":
                    return Language.Afrikaans;
                default:
                    return null;
            }
        }

        public static string ToMemberType(string staff)
        {
            switch (staff)
            {
                case "NonStaff":
                    return "Non";
                case "AIMS":
                    return "AIMS";
                case "ABSA":
                    return "ABSA";
                default:
                    return null;
            }
        }
    }
}
