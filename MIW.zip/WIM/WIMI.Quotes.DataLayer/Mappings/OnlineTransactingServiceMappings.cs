﻿using System;
using System.Collections.Generic;
using System.Linq;

using WIMI.Quotes.Common.Extensions;
using Service = WIMI.Quotes.ServiceReferences.OnlineTransactingService;

namespace WIMI.Quotes.Repositories.Mappings
{
    public static class OnlineTransactingServiceMappings
    {
        #region To Services

        public static Service.AdvisorDetails ToAdvisorDetails(Entities.Advisor advisorDetails)
        {
            if (advisorDetails == null)
                return null;

            return new Service.AdvisorDetails
            {
                Code = advisorDetails.Code,
                FullName = advisorDetails.FullName,
                FirstName = advisorDetails.FirstName,
                Surname = advisorDetails.Surname,
                BrokerageName = advisorDetails.Brokerage,
                IsVatVendor = advisorDetails.VatVendor
            };
        }

        public static Service.ClientDetails ToClientDetails(Entities.Client client)
        {
            if (client == null)
                return null;

            return new Service.ClientDetails
            {
                InvestorType = client.ClientType == "O" ? Service.InvestorType.NonIndividual : Service.InvestorType.Individual,
                ClientNumber = client.ClientNumber,
                Surname = client.ClientType == "I" ? client.Surname : String.Empty,
                FirstNames = client.Name,
                Title = client.Title != null ? client.Title.Trim() : String.Empty,
                DateOfBirth = client.DateOfBirth.ToDateTimeNullable(),
                EntityName = client.ClientType == "O" ? client.Surname : String.Empty,
                EntityType = client.ClientSubType,
                IdType = ToIdType(client.ClientType, client.IdentificationType),
                IdNumber = client.IDNumber,
                Language = client.Language == "AFR" ? Service.Language.Afrikaans : Service.Language.English,
                Gender = ToGender(client.ClientType, client.Gender)
            };
        }

        public static Service.IdType ToIdType(string clientType, string idType)
        {
            if (clientType == "O")
                return Service.IdType.RegistrationNumber;

            return idType == "Pass" ? Service.IdType.Passport : Service.IdType.IdentityNumber;
        }

        public static Service.Gender? ToGender(string clientType, string gender)
        {
            if (clientType == "O")
                return null;

            switch (gender)
            {
                case "M":
                    return Service.Gender.Male;
                case "F":
                    return Service.Gender.Female;
                default:
                    return null;
            }
        }

        #region Standard Products

        public static Service.LumpSum ToLumpSum(Entities.Transfer.LumpSum lumpSum)
        {
            if (lumpSum == null)
                return null;

            return new Service.LumpSum
            {  
                Amount = lumpSum.GrossAmount,
                BDANumber = lumpSum.BDANumber,
                Funds = ToFunds(lumpSum.Funds)
            };
        }

        public static Service.DebitOrder ToDebitOrder(Entities.Transfer.DebitOrder debitOrder)
        {
            if (debitOrder == null)
                return null;

            return new Service.DebitOrder
            {
                Amount = debitOrder.GrossAmount,
                EscalationPercentage = debitOrder.EscalationPercentage,
                Frequency = ToFrequency(debitOrder.Frequency),
                Funds = ToFunds(debitOrder.Funds)
            };
        }

        public static Service.Income ToIncome(Entities.Transfer.Income income)
        {
            if (income == null)
                return null;

            return new Service.Income
            {
                Amount = income.Amount,
                Percentage = income.Percentage,
                IncomeType = ToIncomeType(income.IncomeType),
                EscalationPercentage = income.EscalationPercentage,
                Frequency = ToFrequency(income.Frequency),
                IsIncomeEqualsLumpSum = income.IsIncomeEqualsLumpSum,
                Funds = ToFunds(income.Funds)
            };
        }

        public static List<Service.Fund> ToFunds(List<Entities.Transfer.Fund> funds)
        {
            if (funds == null || funds.Count == 0)
                return new List<Service.Fund>();

            return funds.Select(f => new Service.Fund
            {
                Code = f.Code,
                Name = f.Name,
                Amount = f.GrossAmount,
                Percentage = f.Percentage,
                Type = ToFundType(f.FundType),
                IsEtfFund = f.IsEtfFund
            }).ToList();
        }

        private static Service.Frequency ToFrequency(Entities.Transfer.FrequencyType frequency)
        {
            switch (frequency)
            {
                case Entities.Transfer.FrequencyType.Quarterly:
                    return Service.Frequency.Quarterly;
                case Entities.Transfer.FrequencyType.HalfAnnual:
                    return Service.Frequency.HalfYearly;
                case Entities.Transfer.FrequencyType.Annual:
                    return Service.Frequency.Yearly;
                default:
                    return Service.Frequency.Monthly;
            }
        }

        private static Service.IncomeType ToIncomeType(Entities.Transfer.IncomeType incomeType)
        {
            switch (incomeType)
            {
                case Entities.Transfer.IncomeType.Percentage:
                    return Service.IncomeType.Percentage;
                default:
                    return Service.IncomeType.Amount;
            }
        }

        public static Service.FundType ToFundType(Entities.Transfer.FundType fundType)
        {
            switch (fundType)
            {
                case Entities.Transfer.FundType.Wrap:
                    return Service.FundType.Wrap;
                case Entities.Transfer.FundType.SharePortfolio:
                    return Service.FundType.SharePortfolio;
                default:
                    return Service.FundType.Individual;
            }
        }

        public static Service.PhaseIn ToPhaseIn(Entities.Transfer.PhaseIn phaseIn)
        {
            if (phaseIn == null)
                return null;

            return new Service.PhaseIn
            {
                Amount = phaseIn.Amount,
                PhaseInCommencementDate = phaseIn.PhaseInCommencementDate,
                IsRegulation28Compliant = phaseIn.IsRegulation28Compliant,
                PhaseInLumpSumAmount = phaseIn.PhaseInLumpSumAmount,
                PhaseFromFunds = ToFunds(phaseIn.PhaseFromFunds),
                Funds = ToFunds(phaseIn.Funds)
            };
        }

        public static Service.Fees ToFees(Entities.Transfer.Fees feeDetails)
        {
            if (feeDetails == null)
                return null;

            return new Service.Fees
            {
                AnnualProcessingFee = feeDetails.AnnualProcessingFee,
                AnnualFee = feeDetails.AnnualFee,
                DebitOrderFee = feeDetails.DebitORderFee,
                InitialFee = feeDetails.InitialFee,
                AnnualAdminFee = feeDetails.AnnualAdminFee
            };
        }

        public static bool IsFundListIdentical(List<Entities.Transfer.Fund> firstFundsList, List<Entities.Transfer.Fund> secondFundsList)
        {
            if (firstFundsList != null && secondFundsList != null && firstFundsList.Count != secondFundsList.Count)
                return false;

            foreach (var fund in firstFundsList)
            {
                if (!secondFundsList.Any(f => f.Code == fund.Code))
                {
                    return false;
                }
            }

            foreach (var fund in secondFundsList)
            {
                if (!firstFundsList.Any(f => f.Code == fund.Code))
                {
                    return false;
                }
            }

            return true;
        }

        #endregion

        #region Guaranteed Series

        public static Service.GuaranteedGrowth ToGuaranteedGrowth(Entities.Transfer.GuaranteedGrowth guaranteedGrowth)
        {
            if (guaranteedGrowth == null)
                return null;

            return new Service.GuaranteedGrowth
            {
                IsActive = true,
                GrowthType = Service.GuaranteedGrowthType.Growth,
                InvestmentAmount = guaranteedGrowth.InvestmentAmount,
                MaturityValue = guaranteedGrowth.MaturityValue,
                MaturityDate = guaranteedGrowth.MaturityDate
            };
        }

        public static Service.GuaranteedIncome ToGuaranteedIncome(Entities.Transfer.GuaranteedIncome guaranteedIncome)
        {
            if (guaranteedIncome == null)
                return null;

            return new Service.GuaranteedIncome
            {
                IsActive = true,
                IncomeType = Service.GuaranteedIncomeType.Income,
                InvestmentAmount = guaranteedIncome.InvestmentAmount,
                GrossMonthlyIncome = guaranteedIncome.GrossMonthlyIncome,
                NetMonthlyIncome = guaranteedIncome.NetMonthlyIncome,
                EffectiveRate = guaranteedIncome.EffectiveRate,
                PreferredTaxRate = guaranteedIncome.PreferredTaxRate,
                TaxPayable = guaranteedIncome.TaxPayable,
                TaxablePortion = guaranteedIncome.TaxablePortion,
                CommencementDate = guaranteedIncome.CommencementDate,
                FirstIncomePaymentDate = guaranteedIncome.FirstIncomePaymentDate,
                MaturityDate = guaranteedIncome.MaturityDate
            };
        }

        public static Service.GuaranteedSeriesFees ToGuaranteedGrowthFees(Entities.Transfer.GuaranteedGrowth guaranteedGrowth)
        {
            if (guaranteedGrowth == null)
                return null;

            return new Service.GuaranteedSeriesFees
            {
                IsActive = true,
                AdvisorCommissionPercentage = guaranteedGrowth.AdvisorCommissionPercentage,
                AdminFeePercentage = guaranteedGrowth.AdminFeePercentage,
                AdminLifeFeePercentage = guaranteedGrowth.AdminLifeFeePercentage,
                TaxLossFeePercentage = guaranteedGrowth.TaxLossFeePercentage
            };
        }

        public static Service.GuaranteedSeriesFees ToGuaranteedIncomeFees(Entities.Transfer.GuaranteedIncome guaranteedIncome)
        {
            if (guaranteedIncome == null)
                return null;

            return new Service.GuaranteedSeriesFees
            {
                IsActive = true,
                AdvisorCommissionPercentage = guaranteedIncome.AdvisorCommissionPercentage,
                AdminFeePercentage = guaranteedIncome.AdminFeePercentage,
                AdminLifeFeePercentage = guaranteedIncome.AdminLifeFeePercentage,
                TaxLossFeePercentage = guaranteedIncome.TaxLossFeePercentage
            };
        }

        #endregion

        #endregion

        #region From Services

        public static Entities.Transfer.FormInstanceDetails FromFormInstanceDetails(Service.FormInstanceDetails formInstanceDetails)
        {
            if (formInstanceDetails == null)
                return null;

            return new Entities.Transfer.FormInstanceDetails
            {
                InstanceId = formInstanceDetails.InstanceId,
                FormStatus = FromFormStatus(formInstanceDetails.FormStatus),
                BrokerCode = formInstanceDetails.BrokerCode,
                ClientNumber = formInstanceDetails.ClientNumber
            };
        }

        public static Entities.Transfer.FormStatus FromFormStatus(Service.FormStatus formStatus)
        {
            switch (formStatus)
            {
                case Service.FormStatus.Cancelled:
                    return Entities.Transfer.FormStatus.Cancelled;
                case Service.FormStatus.Complete:
                    return Entities.Transfer.FormStatus.Complete;
                default:
                    return Entities.Transfer.FormStatus.Incomplete;
            }
        }

        #endregion
    }
}
