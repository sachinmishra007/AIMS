﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

using WIMI.Quotes.Common.Extensions;

namespace WIMI.Quotes.Repositories.Mappings
{
    public static class WIMQuotesDataMappings
    {
        public static Entities.Validation ToValidation(Data.Validation validation)
        {
            return new Entities.Validation
            {
                Id = validation.Id,
                FieldName = validation.FieldName,
                Type = ToValidationType(validation.ValidationTypeId),
                MethodName = validation.MethodName,
                Parameters = String.IsNullOrWhiteSpace(validation.Parameters) ? new Dictionary<string, object>() : 
                    JsonConvert.DeserializeObject<IDictionary<string, object>>(validation.Parameters),
                ValidateChildrenOnValid = validation.ValidateChildrenOnValid.GetValueOrDefault(),
                Message = validation.Message,
                ContainerClass = validation.ContainerClass
            };
        }

        public static Entities.ValidationType ToValidationType(int typeId)
        {
            switch (typeId)
            {
                case 2:
                    return Entities.ValidationType.Warning;
                default:
                    return Entities.ValidationType.Error;
            }
        }

        public static Entities.Product ToProduct(Data.pGetQuoteProduct_Result product)
        {
            return new Entities.Product
            {
                Code = product.ProductCode,
                Name = product.ProductName,
                IsOffshore = product.IsOffshore.GetValueOrDefault(),
                IsRegulation28Required = product.IsRegulation28CheckRequired.GetValueOrDefault(),
                IsGuaranteedProduct = product.IsGuaranteedProduct.GetValueOrDefault(),
                Term = product.InvestmentTerm.GetValueOrDefault(),
                HasRecurringFees = product.HasRecurringFees.GetValueOrDefault(),
                HasOngoingFees = product.HasOngoingFees.GetValueOrDefault(),
                ProfileTypes = product.Profiles.Split('|').ToEnumList<Entities.Profiles.ProfileType>()
            };
        }

        public static Entities.Product ToProduct(Data.pGetQuoteProducts_Result product)
        {
            return new Entities.Product
            {
                Code = product.ProductCode,
                Name = product.ProductName,
                IsOffshore = product.IsOffshore.GetValueOrDefault(),
                IsRegulation28Required = product.IsRegulation28CheckRequired.GetValueOrDefault(),
                IsGuaranteedProduct = product.IsGuaranteedProduct.GetValueOrDefault(),
                Term = product.InvestmentTerm.GetValueOrDefault(),
                HasRecurringFees = product.HasRecurringFees.GetValueOrDefault(),
                HasOngoingFees = product.HasOngoingFees.GetValueOrDefault(),
                ProfileTypes = product.Profiles.Split('|').ToEnumList<Entities.Profiles.ProfileType>()
            };
        }
    }
}
