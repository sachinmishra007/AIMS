﻿using System.Collections.Generic;
using System.Linq;

using WIMI.Quotes.ServiceReferences.Regulation28Service;

namespace WIMI.Quotes.Repositories.Mappings
{
    public static class Regulation28ServiceMapping
    {
        #region To Regulation 28 Models from Quotes Entities Models

        /// <summary>
        /// Maps a Funds to Investment item for the Reg 28 Service
        /// </summary>
        public static ComplianceCheckDetails ToComplianceCheckDetails(Entities.Regulation28.ComplianceCheckDetails complianceCheckDetails)
        {
            if (complianceCheckDetails == null)
                return null;

            return new ComplianceCheckDetails
            {
                InstructionType = ToInstructionType(complianceCheckDetails.Type),
                FundAllocations = ToFunds(complianceCheckDetails.Funds),
                ExistingPortfolioFundAllocations = ToFunds(complianceCheckDetails.ExistingPortfolioFunds)
            };
        }

        /// <summary>
        /// Maps Entities Funds to Funds for the Reg 28 Service
        /// </summary>
        public static List<Fund> ToFunds(List<Entities.Fund> funds)
        {
            if (funds == null)
                return null;

            return funds.Select(f => new Fund
            {
                Code = f.Code,
                Name = f.Name,
                Amount = f.Amount,
                Percentage = f.Percentage
            }).ToList();
        }

        public static InstructionType ToInstructionType(Entities.Regulation28.InstructionType instructionType)
        {
            switch (instructionType)
            {
                case Entities.Regulation28.InstructionType.Addition:
                    return InstructionType.Addition;
                default:
                    return InstructionType.NewBusiness;
            }
        }

        #endregion

        #region From Regulation 28 Models to Quotes Entities Models

        public static Entities.Regulation28.ComplianceCheckResult FromComplianceCheckResult(ComplianceCheckResult result)
        {
            if (result == null)
                return null;

            return new Entities.Regulation28.ComplianceCheckResult
            {
                IsOverallCompliant = result.IsOverallCompliant,
                FundCompliance = FromFundCompliances(result.FundCompliance),
                OverallComplianceLimits = FromComplianceLimits(result.OverallComplianceLimits)
            };
        }

        public static List<Entities.Regulation28.FundCompliance> FromFundCompliances(List<FundCompliance> fundCompliances)
        {
            if (fundCompliances == null || fundCompliances.Count == 0)
                return new List<Entities.Regulation28.FundCompliance>();

            return fundCompliances.Select(f => new Entities.Regulation28.FundCompliance
            {
                FundCode = f.FundCode,
                FundName = f.FundName,
                FundAmount = (decimal)f.FundAmount,
                FundPercentage = (decimal)f.FundPercentage,
                IsFundCompliant = f.IsFundCompliant,
                ComplianceLimits = FromComplianceLimits(f.ComplianceLimits)
            }).ToList();
        }

        public static List<Entities.Regulation28.ComplianceLimit> FromComplianceLimits(List<ComplianceLimit> complianceLimits)
        {
            if (complianceLimits == null || complianceLimits.Count == 0)
                return new List<Entities.Regulation28.ComplianceLimit>();

            return complianceLimits.Select(c => new Entities.Regulation28.ComplianceLimit
            {
                Code = c.Code,
                Name = c.Name,
                IsLimitCompliant = c.IsLimitCompliant,
                Regulation28LimitValue = c.Regulation28LimitValue,
                Value = c.Value
            }).ToList();
        }

        #endregion
    }
}
