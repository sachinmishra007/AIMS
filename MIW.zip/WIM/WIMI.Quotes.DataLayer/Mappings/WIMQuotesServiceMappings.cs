﻿using System;
using System.Collections.Generic;
using System.Linq;

using WIMI.Quotes.Common;
using WIMI.Quotes.Common.Extensions;
using WIMI.Quotes.ServiceReferences.WIMQuotesWCFService;


namespace WIMI.Quotes.Repositories.Mappings
{
    public static class WIMQuotesServiceMappings
    {
        #region Investment Mappings

        /// <summary>
        /// Maps a Quote Details to Investment item for the Quotes Service
        /// </summary>
        public static Investment ToInvestment(
            Entities.QuoteItem quoteItem)
        {
            var lumpSumProfile = quoteItem.Profiles.SingleOrDefault(p => p.Type == Entities.Profiles.ProfileType.LumpSum) as Entities.Profiles.LumpSum ??
                new Entities.Profiles.LumpSum();

            return new Investment
            {
                AkmId = quoteItem.AkmId.ToString(),
                Broker = ToBroker(quoteItem.Advisor),
                Client = ToClient(quoteItem.Client),
                Details = new List<InvestmentDetail> { ToInvestmentDetail(quoteItem) },
                Language = ToLanguage(quoteItem.ReportOptions.Language),
                Reference = Constants.References.QuotesServiceReference,
                ThirdParty = ThirdParty.NotSet,
                TotalLumpSum = 0,
                ReportOptions = ToReportOptions(quoteItem.ReportOptions),
                Currency = quoteItem.Currency != null ? quoteItem.Currency.Code : string.Empty,
                MarketValue = ToMarketValue(quoteItem),
                PolicyNumber = lumpSumProfile.PolicyNumber
            };
        }

        /// <summary>
        /// Maps a Quote Item to Investment Details for the Quotes Service
        /// </summary>
        private static InvestmentDetail ToInvestmentDetail(Entities.QuoteItem quoteItem)
        {
            var lumpSumProfile = quoteItem.Profiles.SingleOrDefault(p => p.Type == Entities.Profiles.ProfileType.LumpSum) as Entities.Profiles.LumpSum ?? 
                new Entities.Profiles.LumpSum();

            return new InvestmentDetail 
            {
                ProductCode = quoteItem.Product.Code,
                LumpSum = (lumpSumProfile.IsActive ? (decimal)lumpSumProfile.Amount : 0),
                Funds = (lumpSumProfile.IsActive ? ToFunds(lumpSumProfile.Funds) : null),
                Term = quoteItem.Product.Term,
                DebitOrder = ToDebitOrder(quoteItem.Profiles.OfType<Entities.Profiles.DebitOrder>().SingleOrDefault()),
                Income = ToIncome(quoteItem.Profiles.OfType<Entities.Profiles.Income>().SingleOrDefault(), quoteItem.Client),
                PhaseIn = ToPhaseIn(quoteItem.Profiles.OfType<Entities.Profiles.PhaseIn>().SingleOrDefault()),
                Fees = ExtractFees(quoteItem.Profiles),
                SpecialFeeReference = quoteItem.Profiles.OfType<Entities.Profiles.Fees>().Select(f => f.SpecialFeeRefNo).FirstOrDefault(),
                IsRegulation28Compliant = (lumpSumProfile.IsActive ? lumpSumProfile.IsRegulation28Compliant : null)
            };
        }

        /// <summary>
        /// Maps Entities Debit Order to Debit Order for the Quotes Service
        /// </summary>
        /// <param name="debitOrder"></param>
        /// <returns></returns>
        private static DebitOrder ToDebitOrder(Entities.Profiles.DebitOrder debitOrder)
        {
            if (debitOrder == null || !debitOrder.IsActive)
                return null;

            return new DebitOrder
            {
                Amount = (decimal)debitOrder.Amount,
                Funds = ToFunds(debitOrder.Funds),
                EscalationPercentage = (decimal)debitOrder.EscalationPercentage,
                Frequency = debitOrder.Frequency.ToDescription(),
                IsRegulation28Compliant = debitOrder.IsRegulation28Compliant
            };
        }

        /// <summary>
        /// Maps Entities Income to Income for the Quotes Service
        /// </summary>
        private static Income ToIncome(Entities.Profiles.Income income, Entities.Client client)
        {
            if (income == null || !income.IsActive)
                return null;

            return new Income
            {
                Amount = income.IncomeType == Entities.Profiles.IncomeType.Amount ? (decimal)income.Amount : 0,
                Percentage = income.IncomeType == Entities.Profiles.IncomeType.Percentage ? (decimal)income.Percentage : 0,
                Funds = ToFunds(income.Funds),
                EscalationPercentage = (decimal)income.EscalationPercentage,
                Frequency = income.Frequency.ToDescription(),
                Tax = ToIncomeTax(income, client)
            };
        }

        /// <summary>
        /// Maps Income details to Income tax for the Quotes Service
        /// </summary>
        /// <param name="income">Income details for the quote</param>
        /// <param name="client">Client details the quote is being generated for</param>
        private static IncomeTax ToIncomeTax(Entities.Profiles.Income income, Entities.Client client)
        {
            return new IncomeTax
            {
                DateOfBirth = client != null ? client.DateOfBirth : null,
                PreferedTaxRate = (decimal)(income.TaxationMethod == Entities.Profiles.TaxationMethod.Directive ? income.PreferredTaxRate : 0)
            };
        }

        private static PhaseIn ToPhaseIn(Entities.Profiles.PhaseIn phaseIn)
        {
            if (phaseIn == null || !phaseIn.IsActive)
                return null;

            return new PhaseIn
            {
                Amount = phaseIn.Amount,
                Funds = ToFunds(phaseIn.Funds),
                PhaseInCommencementDate = phaseIn.PhaseInCommencementDate,
                PhaseInLumpSumAmount = phaseIn.PhaseInLumpSumAmount,
                IsRegulation28Compliant = phaseIn.IsRegulation28Compliant
            };
        }

        private static List<Fee> ExtractFees(List<Entities.Profiles.IProfile> profiles)
        {
            if (profiles == null || profiles.Count == 0)
                return new List<Fee>();

            var phaseInProfile = profiles.SingleOrDefault(p => p.Type == Entities.Profiles.ProfileType.PhaseIn) as Entities.Profiles.PhaseIn ??
                new Entities.Profiles.PhaseIn();

            var feesProfile = profiles.OfType<Entities.Profiles.Fees>().SingleOrDefault();

            var fees = ToFees(feesProfile);

            if (fees == null)
                return null;

            if (phaseInProfile.IsActive)
            {
                var phaseInFees = ToFeesPhaseIn(feesProfile);

                if (phaseInFees != null && phaseInFees.Count > 0)
                    fees.AddRange(phaseInFees);
            }

            return fees;
        }

        /// <summary>
        /// Maps Entities Income to Income for the Quotes Service
        /// </summary>
        private static List<Fee> ToFees(Entities.Profiles.Fees profileFees)
        {
            if (profileFees == null || !profileFees.IsActive)
                return null;

            return new List<Fee>
            {
                new Fee
                {
                    BasePercentage = profileFees.AdvisorInitialFee,
                    TotalPercentage = profileFees.AdvisorInitialFee,
                    TypeId = (int) MappingTypes.FeeType.InitialFee,
                    CategoryId = (int) MappingTypes.CategoryType.Advisor
                },
                new Fee
                {
                    BasePercentage = profileFees.AdvisorRecurringFee,
                    TotalPercentage = profileFees.AdvisorRecurringFee,
                    TypeId = (int) MappingTypes.FeeType.RecurringFee,
                    CategoryId = (int) MappingTypes.CategoryType.Advisor
                },
                new Fee
                {
                    BasePercentage = profileFees.AdvisorOngoingFee,
                    TotalPercentage = profileFees.AdvisorOngoingFee,
                    TypeId = (int) MappingTypes.FeeType.OngoingFee,
                    CategoryId = (int) MappingTypes.CategoryType.Advisor
                },
                new Fee
                {
                    BasePercentage = profileFees.ExistingAdvisorOngoingFee,
                    TotalPercentage = profileFees.ExistingAdvisorOngoingFee,
                    TypeId = (int) MappingTypes.FeeType.ExistingOngoingFee,
                    CategoryId = (int) MappingTypes.CategoryType.Advisor
                }
            };
        }

        /// <summary>
        /// Maps Entities Fees to Phase In fees for the Quotes Service
        /// </summary>
        private static List<Fee> ToFeesPhaseIn(Entities.Profiles.Fees profileFees)
        {
            if (profileFees == null)
                return new List<Fee>();

            return new List<Fee>
            {
                new Fee
                {
                    BasePercentage = profileFees.AdvisorInitialFee,
                    TotalPercentage = profileFees.AdvisorInitialFee,
                    TypeId = (int) MappingTypes.FeeType.PhaseInInitialFee,
                    CategoryId = (int) MappingTypes.CategoryType.Advisor
                },
                new Fee
                {
                    BasePercentage = profileFees.AdvisorOngoingFee,
                    TotalPercentage = profileFees.AdvisorOngoingFee,
                    TypeId = (int) MappingTypes.FeeType.PhaseInOngoingFee,
                    CategoryId = (int) MappingTypes.CategoryType.Advisor
                }
            };
        }

        /// <summary>
        /// Maps Entities Funds to Funds for the Quotes Service
        /// </summary>
        private static List<Fund> ToFunds(List<Entities.Fund> funds)
        {
            if (funds == null || funds.Count == 0)
                return new List<Fund>();

            return funds.Select(f => new Fund
            {
                Amount = (decimal)f.Amount,
                FundCode = f.Code,
                FundName = f.Name,
                Percentage = (decimal)f.Percentage
            }).ToList();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="quoteItem"></param>
        /// <returns></returns>
        private static decimal? ToMarketValue(Entities.QuoteItem quoteItem)
        {
            var addition = quoteItem.Profiles.OfType<Entities.Profiles.Addition>().SingleOrDefault();
            var lumpSum = quoteItem.Profiles.OfType<Entities.Profiles.LumpSum>().SingleOrDefault();

            return addition != null && addition.IsActive && lumpSum != null && !string.IsNullOrWhiteSpace(lumpSum.PolicyNumber) ? 
                (decimal)lumpSum.PolicyMarketValue : (decimal?)null;
        }

        private static Language ToLanguage(Entities.Language language)
        {
            switch (language)
            {
                case Entities.Language.Afrikaans:
                    return Language.Afrikaans;
                case Entities.Language.English:
                    return Language.English;
                default:
                    return Language.NotSet;
            }
        }

        public static IncomeTypes ToIncomeType(Entities.Profiles.IncomeType? incomeType)
        {
            switch (incomeType)
            {
                case Entities.Profiles.IncomeType.Percentage:
                    return IncomeTypes.Percentage;
                default:
                    return IncomeTypes.Amount;
            }
        }

        #endregion

        #region Guaranteed Series

        /// <summary>
        /// Maps a Quote Details to Investment item for the Quotes Service
        /// </summary>
        public static GuaranteedSeries ToGuaranteedSeries(
            Entities.QuoteItem quoteItem)
        {
            return new GuaranteedSeries
            {
                Broker = ToBroker(quoteItem.Advisor),
                Client = ToClient(quoteItem.Client),
                Details = new List<GuaranteedSeriesDetails> { ToGuaranteedSeriesDetail(quoteItem) },
                Language = ToLanguage(quoteItem.ReportOptions.Language),
                Reference = Constants.References.QuotesServiceReference,
                ThirdParty = ThirdParty.NotSet
            };
        }

        public static AULSeries ToGuaranteedSeriesAUL(
            Entities.QuoteItem quoteItem)
        {
            return new AULSeries
            {
                Broker = ToBroker(quoteItem.Advisor),
                Client = ToClient(quoteItem.Client),
                Details = new List<AULSeriesDetails> { ToGuaranteedSeriesDetailAUL(quoteItem) },
                Language = ToLanguage(quoteItem.ReportOptions.Language),
                Reference = Constants.References.QuotesServiceReference,
                ThirdParty = ThirdParty.NotSet
            };
        }

        /// <summary>
        /// Maps a Quote Item to Investment Details for the Quotes Service
        /// </summary>
        private static GuaranteedSeriesDetails ToGuaranteedSeriesDetail(Entities.QuoteItem quoteItem)
        {
            return new GuaranteedSeriesDetails
            {
                DateOfBirth = String.IsNullOrWhiteSpace(quoteItem.Client.DateOfBirth) ? null : quoteItem.Client.DateOfBirth,
                GuaranteedGrowth = ToGuaranteedGrowth(quoteItem.Profiles.OfType<Entities.Profiles.GuaranteedGrowth>().SingleOrDefault()),
                GuaranteedCapital = ToGuaranteedCapital(quoteItem.Profiles.OfType<Entities.Profiles.GuaranteedGrowth>().SingleOrDefault()),
                GuaranteedIncome = ToGuaranteedIncome(quoteItem.Profiles.OfType<Entities.Profiles.GuaranteedIncome>().SingleOrDefault())
            };
        }

        private static AULSeriesDetails ToGuaranteedSeriesDetailAUL(Entities.QuoteItem quoteItem)
        {
            return new AULSeriesDetails
            {
                DateOfBirth = String.IsNullOrWhiteSpace(quoteItem.Client.DateOfBirth) ? null : quoteItem.Client.DateOfBirth,
                AULGrowth = ToGuaranteedGrowthAUL(quoteItem.Profiles.OfType<Entities.Profiles.GuaranteedGrowth>().SingleOrDefault()),
                AULCapital = ToGuaranteedCapitalAUL(quoteItem.Profiles.OfType<Entities.Profiles.GuaranteedGrowth>().SingleOrDefault()),
                AULIncome = ToGuaranteedIncomeAUL(quoteItem.Profiles.OfType<Entities.Profiles.GuaranteedIncome>().SingleOrDefault())
            };
        }

        private static GuaranteedGrowth ToGuaranteedGrowth(Entities.Profiles.GuaranteedGrowth guaranteedGrowth)
        {
            if (guaranteedGrowth == null || !guaranteedGrowth.IsActive || guaranteedGrowth.GrowthType != Entities.Profiles.GuaranteedGrowthType.Growth)
                return null;

            return new GuaranteedGrowth
            {
                InvestmentAmonunt = (decimal)guaranteedGrowth.Amount,
                AdvisorFee = (decimal)guaranteedGrowth.CommissionPercentage,
                AIMSDiscountFee = (decimal)guaranteedGrowth.DiscountFee
            };
        }

        private static AULGrowth ToGuaranteedGrowthAUL(Entities.Profiles.GuaranteedGrowth guaranteedGrowth)
        {
            if (guaranteedGrowth == null || !guaranteedGrowth.IsActive || guaranteedGrowth.GrowthType != Entities.Profiles.GuaranteedGrowthType.Growth)
                return null;

            return new AULGrowth
            {
                
                InvestmentAmount = guaranteedGrowth.Amount,
                AdvisorFee = guaranteedGrowth.CommissionPercentage,
                AIMSDiscountFee = guaranteedGrowth.DiscountFee
            };
        }

        private static GuaranteedCapital ToGuaranteedCapital(Entities.Profiles.GuaranteedGrowth guaranteedGrowth)
        {
            if (guaranteedGrowth == null || !guaranteedGrowth.IsActive || guaranteedGrowth.GrowthType != Entities.Profiles.GuaranteedGrowthType.Capital)
                return null;

            return new GuaranteedCapital
            {
                MaturityValue = (decimal)guaranteedGrowth.MaturityValue,
                AdvisorFee = (decimal)guaranteedGrowth.CommissionPercentage,
                AIMSDiscountFee = (decimal)guaranteedGrowth.DiscountFee
            };
        }

        private static AULCapital ToGuaranteedCapitalAUL(Entities.Profiles.GuaranteedGrowth guaranteedGrowth)
        {
            if (guaranteedGrowth == null || !guaranteedGrowth.IsActive || guaranteedGrowth.GrowthType != Entities.Profiles.GuaranteedGrowthType.Capital)
                return null;

            return new AULCapital
            {
                MaturityValue = guaranteedGrowth.MaturityValue,
                AdvisorFee = guaranteedGrowth.CommissionPercentage,
                AIMSDiscountFee = guaranteedGrowth.DiscountFee
            };
        }

        private static GuaranteedIncome ToGuaranteedIncome(Entities.Profiles.GuaranteedIncome guaranteedIncome)
        {
            if (guaranteedIncome == null || !guaranteedIncome.IsActive)
                return null;

            return new GuaranteedIncome
            {
                InvestmentAmonunt = guaranteedIncome.IncomeType == Entities.Profiles.GuaranteedIncomeType.Investment ? 
                    (decimal)guaranteedIncome.InvestmentAmount : 0,
                GrossMthlyIncome = guaranteedIncome.IncomeType == Entities.Profiles.GuaranteedIncomeType.Income ? 
                    (decimal)guaranteedIncome.MonthlyIncome : 0,
                AdvisorFee = (decimal)guaranteedIncome.CommissionPercentage,
                PrefferedTaxRate = guaranteedIncome.TaxationMethod == Entities.Profiles.TaxationMethod.Directive ? 
                    (decimal)guaranteedIncome.DirectivePercentage : 0
            };
        }

        private static AULIncome ToGuaranteedIncomeAUL(Entities.Profiles.GuaranteedIncome guaranteedIncome)
        {
            if (guaranteedIncome == null || !guaranteedIncome.IsActive)
                return null;

            return new AULIncome
            {
                InvestmentAmount = guaranteedIncome.IncomeType == Entities.Profiles.GuaranteedIncomeType.Investment ?
                    guaranteedIncome.InvestmentAmount : 0,
                GrossMthlyIncome = guaranteedIncome.IncomeType == Entities.Profiles.GuaranteedIncomeType.Income ?
                    guaranteedIncome.MonthlyIncome : 0,
                AdvisorFee = guaranteedIncome.CommissionPercentage,
                PreferredTaxRate = guaranteedIncome.TaxationMethod == Entities.Profiles.TaxationMethod.Directive ?
                    guaranteedIncome.DirectivePercentage : 0
            };
        }

        #endregion

        #region Common Mappings

        private static Broker ToBroker(Entities.Advisor advisor)
        {
            if (advisor == null)
                return null;

            return new Broker
            {
                Code = advisor.Code,
                Brokerage = advisor.Brokerage,
                FirstName = advisor.FirstName,
                Surname = advisor.Surname
            };
        }

        private static Client ToClient(Entities.Client client)
        {
            if (client == null)
                return null;

            return new Client
            {
                ClientNumber = client.ClientNumber,
                Surname = client.ClientType == "I" ? client.Surname : string.Empty,
                Name = client.Name,
                Title = client.Title != null ? client.Title.Trim() : string.Empty,
                IdPassRegNumber = client.IDNumber,
                DateOfBirth = client.DateOfBirth,
                Language = client.Language.Trim() == "AFR" ? "Afrikaans" : "English",
                EntityName = client.ClientType == "O" ? client.Surname : string.Empty,
                EntityType = client.ClientSubType,
                ClientType = client.ClientType == "O" ? "Non-Individual" : "Individual",
                IDType = GetIdType(client.ClientType, client.IdentificationType)
            };
        }

        private static string GetIdType(string clientType, string idType)
        {
            if (clientType == "O")
                return "RegistrationNumber";

            return idType == "Pass" ? "Passport" : "IdentityNumber";
        }

        private static ReportOptions ToReportOptions(Entities.ReportOptions reportOptions)
        {
            return new ReportOptions
            {
                IncludeAssetAllocations = reportOptions.IncludeAssetAllocations,
                IncludeRegulation28 = reportOptions.IncludeRegulation28
            };
        }

        #endregion
    }
}
