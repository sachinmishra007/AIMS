﻿using System.Collections.Generic;

namespace WIMI.Quotes.Repositories.Mappings
{
    public static class WIMQuotesDataTransferMappings
    {
        public static Entities.Transfer.Fund ToFund(Data.QuoteDetailsLumpSum lumpSum)
        {
            if (lumpSum == null)
                return null;

            return new Entities.Transfer.Fund
            {
                Code = lumpSum.FundCode,
                Name = lumpSum.FundName,
                GrossAmount = (double)lumpSum.FundGrossAmount,
                NettAmount = (double)lumpSum.FundNettAmount,
                Percentage = (double)lumpSum.FundPercentage,
                FundType = lumpSum.FundType == "W" ? Entities.Transfer.FundType.Wrap :
                          (lumpSum.FundType == "S" ? Entities.Transfer.FundType.SharePortfolio : Entities.Transfer.FundType.Individual),
                IsWealthSeries = lumpSum.IsWealthSeries.GetValueOrDefault(),
                IsEtfFund = lumpSum.IsEtfFund.GetValueOrDefault()
            };
        }

        public static Entities.Transfer.Fund ToFund(Data.QuoteDetailsDebitOrder debitOrder)
        {
            if (debitOrder == null)
                return null;

            return new Entities.Transfer.Fund
            {
                Code = debitOrder.FundCode,
                Name = debitOrder.FundName,
                GrossAmount = (double)debitOrder.FundGrossAmount.GetValueOrDefault(),
                NettAmount = (double)debitOrder.FundNettAmount,
                Percentage = (double)debitOrder.FundPercentage,
                FundType = debitOrder.FundType == "W" ? Entities.Transfer.FundType.Wrap :
                          (debitOrder.FundType == "S" ? Entities.Transfer.FundType.SharePortfolio : Entities.Transfer.FundType.Individual),
                IsWealthSeries = debitOrder.IsWealthSeries.GetValueOrDefault(),
                IsEtfFund = debitOrder.IsEtfFund.GetValueOrDefault()
            };
        }

        public static Entities.Transfer.Fund ToFund(Data.QuoteDetailsIncome income)
        {
            if (income == null)
                return null;

            return new Entities.Transfer.Fund
            {
                Code = income.FundCode,
                Name = income.FundName,
                GrossAmount = (double)income.FundAmount.GetValueOrDefault(),
                Percentage = (double)income.FundPercentage,
                FundType = income.FundType == "W" ? Entities.Transfer.FundType.Wrap :
                           (income.FundType == "S" ? Entities.Transfer.FundType.SharePortfolio : Entities.Transfer.FundType.Individual),
                IsWealthSeries = income.IsWealthSeries.GetValueOrDefault(),
                IsEtfFund = income.IsEtfFund.GetValueOrDefault()
            };
        }

        public static Entities.Transfer.Fund ToFund(Data.PhaseInDetails phaseIn)
        {
            if (phaseIn == null)
                return null;

            return new Entities.Transfer.Fund
            {
                Code = phaseIn.FundCode,
                Name = phaseIn.FundName,
                GrossAmount = (double)phaseIn.FundGrossAmount.GetValueOrDefault(),
                NettAmount = (double)phaseIn.FundNettAmount,
                Percentage = (double)phaseIn.FundPercentage.GetValueOrDefault(),
                FundType = phaseIn.FundType == "W" ? Entities.Transfer.FundType.Wrap :
                           (phaseIn.FundType == "S" ? Entities.Transfer.FundType.SharePortfolio : Entities.Transfer.FundType.Individual),
                IsWealthSeries = phaseIn.IsWealthSeries.GetValueOrDefault(),
                IsEtfFund = phaseIn.IsEtfFund.GetValueOrDefault()
            };
        }

        public static List<Entities.Transfer.Fund> ToPhaseFromFunds(Data.PhaseInDetails phaseInDetails)
        {
            return new List<Entities.Transfer.Fund>
            {
                new Entities.Transfer.Fund
                {
                    Code = phaseInDetails.PhaseInFromFund,
                    Name = phaseInDetails.PhaseInFromFundName,
                    Percentage = 100.00
                }
            };
        }
    }
}
