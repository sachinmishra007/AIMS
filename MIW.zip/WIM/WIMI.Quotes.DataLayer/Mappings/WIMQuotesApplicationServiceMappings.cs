﻿namespace WIMI.Quotes.Repositories.Mappings
{
    public static class WIMQuotesApplicationServiceMappings
    {
        public static Entities.Advisor UserToEntitesAdvisor(ServiceReferences.WIMQuotesApplicationService.User user)
        {
            return new Entities.Advisor
            {
                Code = user.UserCode,
                FirstName = user.UserFirstName,
                Surname = user.UserSurname,
                FullName = user.UserFullName,
                Brokerage = user.UserHouse,
                VatVendor = user.UserVatVendor,
                ExistingAdvisorOngoingFee = 1
            };
        }

        public static Entities.QuoteHistoryItem ToQuoteHistoryItem(ServiceReferences.WIMQuotesApplicationService.QuoteHistoryResponse quoteHistory)
        {
            return new Entities.QuoteHistoryItem
            {
                Description = quoteHistory.Description,
                CreatedDate = quoteHistory.QuoteDate,
                QuoteNumber = quoteHistory.QuoteNumber,
                ReportUrl = quoteHistory.ServerURL
            };
        }
    }
}
