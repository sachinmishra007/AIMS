﻿using System;
using System.Linq;

using WIMI.Quotes.Repositories.Contracts;
using WIMI.Quotes.ServiceReferences.AuthenticationService;

namespace WIMI.Quotes.Repositories
{
    public class AuthenticationRepository : IAuthenticationService
    {
        public bool AuthenticateUser(string username, string password)
        {
            if (String.IsNullOrWhiteSpace(username) || String.IsNullOrWhiteSpace(password))
                return false;

            using (var authService = new GenericAuthSoapClient())
            {
                var auth = authService.Authenticate(username, password, "AbsaInvest");
                return auth != null && auth.Status == "SUCCESS";
                //return true;
            }
        }

        public string GetUserRole(string userId)
        {
            Data.WIMQuotesEntities context = null;

            try
            {
                using (context = new Data.WIMQuotesEntities())
                {
                    var result = context.pGetUserPermissions(userId).FirstOrDefault();
                    return result != null ? result.PermissionId : null;
                }
            }
            finally
            {
                if (context != null)
                {
                    context.Dispose();
                }
            }
        }
    }
}
