﻿using Newtonsoft.Json;

using WIMI.Quotes.Repositories.Contracts;
using WIMI.Quotes.ServiceReferences.SessionApiService;

namespace WIMI.Quotes.Repositories
{
    public class SessionApiRepository : ISessionApiRepository
    {
        #region Constructor & DI

        public SessionApiRepository()
        {
        }

        #endregion

        public string GetSessionApiItem(string sessionKey, string variableName)
        {
            if (string.IsNullOrWhiteSpace(sessionKey) || string.IsNullOrWhiteSpace(variableName))
                return null;

            using (var sessionApiService = new SessionServiceSoapClient())
            {
                var result = sessionApiService.GetSessionVariable(sessionKey, variableName);
                return result != null ? result.Value : null;
            }
        }

        public T DeserialiseSessionApiItem<T>(string sessionKey, string variableName)
        {
            if (string.IsNullOrWhiteSpace(sessionKey) || string.IsNullOrWhiteSpace(variableName))
                return default(T);

            using (var sessionApiService = new SessionServiceSoapClient())
            {
                var result = sessionApiService.GetSessionVariable(sessionKey, variableName);
                return result == null ? default(T) : JsonConvert.DeserializeObject<T>(result.Value);
            }
        }

        public void SetSessionApiItem(string sessionKey, string variableName, object value)
        {
            if (string.IsNullOrWhiteSpace(sessionKey) || string.IsNullOrWhiteSpace(variableName) || value == null)
                return;

            using (var sessionApiService = new SessionServiceSoapClient())
            {
                sessionApiService.AddSessionVariable(new SessionVariable
                {
                    SessionGuid = sessionKey,
                    Name = variableName,
                    Value = value.ToString()
                });
            }
        }
    }
}
