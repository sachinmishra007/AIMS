﻿using System;
using System.Collections.Generic;

using WIMI.Quotes.ServiceReferences.WIMQuotesWCFService;

namespace WIMI.Quotes.Repositories.Contracts
{
    public interface IWIMQuotesWCFServiceRepository
    {
        /// <summary>
        /// Generate a Quote for a Standard Product
        /// </summary>
        /// <param name="investment">Investment details to generate a quote for</param>
        /// <returns>Instance of <see cref="Investment"/></returns>
        Investment GenerateStandardQuote(Investment investment);

        /// <summary>
        /// Generate a Quote for Guaranteed Series data
        /// </summary>
        /// <param name="guaranteedSeries">Guaranteed Series details to generate a quote for</param>
        /// <returns>Instance of <see cref="GuaranteedSeries"/></returns>
        GuaranteedSeries GenerateGuaranteedSeriesQuote(GuaranteedSeries guaranteedSeries);

        /// <summary>
        /// Generate a Quote for Guaranteed Series AUL data
        /// </summary>
        /// <param name="guaranteedSeries">Guaranteed Series details to generate a quote for</param>
        /// <returns>Instance of <see cref="GuaranteedSeries"/></returns>
        AULSeries GenerateGuaranteedAULSeriesQuote(AULSeries aulSeries);

        /// <summary>
        /// Retrieves all Completed Quotes from the Quotes Service for supplied <param name="brokerCode">Broker Code</param> 
        /// and <param name="clientNumber">Client Number</param> 
        /// </summary>
        /// <param name="brokerCode">Broker Code</param>
        /// <param name="clientNumber">Client Number</param>
        /// <param name="vendorId">Vendor identifier setup on the Quotes Service to uniquely identify calling application</param>
        /// <returns>List of <see cref="Entities.QuoteHistoryItem"/></returns>
        List<Entities.QuoteHistoryItem> GetCompletedQuotes(string brokerCode, string clientNumber, Guid vendorId);

        /// <summary>
        /// Generates a Quote Report PDF for the supplied details
        /// </summary>
        /// <param name="quoteNumber">Quote Number of the generated quote to create a Quote Report for</param>
        /// <param name="brokerCode">Broker Code of the generated quote to create a Quote Report for</param>
        /// <param name="clientNumber">Client Number  of the generated quote to create a Quote Report for</param>
        /// <param name="vendorId">Vendor identifier setup on the Quotes Service to uniquely identify calling applicatio</param>
        Entities.File GenerateQuoteReport(int quoteNumber, string brokerCode, string clientNumber, Guid vendorId);
    }
}
