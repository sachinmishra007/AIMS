﻿using System;
using System.Collections.Generic;

namespace WIMI.Quotes.Repositories.Contracts
{
    public interface IWIMQuotesDataRepository
    {
        #region Quote Item

        List<Entities.QuoteHistoryItem> GetQuoteHistoryItems(string advisorNumber, string clientNumber, Entities.QuoteItemStatus status);

        Entities.QuoteItem GetQuoteItem(Guid quoteItemId);

        Entities.QuoteItem GetQuoteItem(int quoteNumber);

        List<Entities.QuoteItem> GetQuoteItems(Guid quoteGroupId);

        void SaveQuoteItem(Entities.QuoteItem quoteItem, string userId);

        void UpdateQuoteItemDataDetails(Entities.QuoteItemDataDetails quoteItemDataDetails);

        void SaveQuoteGroup(Guid quoteGroupId, Guid quoteItemId);

        #endregion

        #region Report Data

        /// <summary>
        /// Returns the broker that was captured against the Quote Report Data by the supplie <param name="quoteNumber">quoteNumber</param>
        /// </summary>
        /// <param name="quoteNumber">Quote Number to return the Broker Code for</param>
        /// <returns>string of Broker Code</returns>
        string GetQuoteReportBroker(int quoteNumber);

        string GetQuoteReportFileName(int quoteNumber);

        void UpdateQuoteAkmId(int quoteNumber, int akmId);

        #endregion

        #region Funds

        List<Entities.Fund> GetFundsList(string productCode, string fundRangeCode, string brokerCode);

        List<Entities.Fund> GetQuoteConsolidatedFunds(int quoteNumber);

        #endregion

        #region Products

        Entities.Product GetProduct(string productCode);

        IEnumerable<Entities.Product> GetProductsList(string brokerCode, string clientType, string clientSubType);

        #endregion

        #region Validations

        List<Entities.Validation> GetValidations(string productCode, string brokerCode, int stepId);
        Entities.ClientContribution GetClientContribution(string clientNumber, string productCode);

        #endregion

        #region Lookups

        List<Entities.LookupItem> GetLookupData(string lookupCode);

        #endregion

        #region TaxYears

        List<Entities.TaxYears> GetTaxYearData();

        #endregion

        #region Client

        bool CanAdvisorAccessClient(string clientNumber, string brokerCode);
        List<Entities.Policy> GetClientProductPolicies(string clientNumber, string productCode);
        List<Entities.Fund> GetClientProductPortfolio(string clientNumber, string productCode);

        #endregion
    }
}
