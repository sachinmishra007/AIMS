﻿using System.Collections.Generic;

namespace WIMI.Quotes.Repositories.Contracts
{
    public interface IWIMQuotesApplicationServiceRepository
    {
        List<Entities.Client> GetClientsByBroker(string brokerCode, string searchTerm);
        List<Entities.Advisor> GetAdvisors(string searchTerm);
        Entities.Advisor GetAdvisor(string advisorCode);
        List<Entities.QuoteHistoryItem> GetHistoricalQuotes(string brokerCode, string clientNumber);
        void SaveQuoteDocument(int quoteNumber, Entities.File quoteReportFile);
        decimal GetLatestInvestmentValue(string clientNumber, string productCode);
        decimal GetAdvisorOngoingFee(string brokerCode, string policyNumber);
    }
}
