﻿namespace WIMI.Quotes.Repositories.Contracts
{
    public interface IRegulation28ServiceRepository
    {
        Entities.Regulation28.ComplianceCheckResult CheckCompliance(Entities.Regulation28.ComplianceCheckDetails complianceCheckDetails);
    }
}
