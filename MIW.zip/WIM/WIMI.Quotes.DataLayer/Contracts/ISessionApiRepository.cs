﻿namespace WIMI.Quotes.Repositories.Contracts
{
    public interface ISessionApiRepository
    {
        string GetSessionApiItem(string sessionKey, string variableName);
        T DeserialiseSessionApiItem<T>(string sessionKey, string variableName);
        void SetSessionApiItem(string sessionKey, string variableName, object value);
    }
}
