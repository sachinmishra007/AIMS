﻿using System.Collections.Generic;

namespace WIMI.Quotes.Repositories.Contracts
{
    public interface IPortfolioPerformanceServiceRepository
    {
        /// <summary>
        /// Returns Fund Fact Sheet links for provided <param name="fundCodes">fund codes</param>
        /// </summary>
        List<Entities.FundFactSheet> GetFundFactSheetsList(List<Entities.Fund> fundCodes);

        /// <summary>
        /// Returns Product Brochure file for provided <param name="productCode">product code</param>
        /// </summary>
        /// <param name="productCode">Product code to return the Product Brochure file for</param>
        /// <param name="language">Language of the Product Brochure to return</param>
        /// <returns>Product brochure file</returns>
        byte[] GetProductBrochure(string productCode, Entities.Language language);
    }
}