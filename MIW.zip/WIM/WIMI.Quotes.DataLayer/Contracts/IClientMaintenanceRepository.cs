﻿namespace WIMI.Quotes.Repositories.Contracts
{
    public interface IClientMaintenanceRepository
    {
        string CreateClient(Entities.Client client);

        string UpdateClient(Entities.Client client);
    }
}
