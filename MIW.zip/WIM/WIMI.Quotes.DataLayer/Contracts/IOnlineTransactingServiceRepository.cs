﻿using System;

namespace WIMI.Quotes.Repositories.Contracts
{
    public interface IOnlineTransactingServiceRepository
    {
        Guid CreateNewFormInstance(ServiceReferences.OnlineTransactingService.FormInstance formInstance);
        Entities.Transfer.FormInstanceDetails GetFormInstanceDetails(string externalReferenceId);
    }
}
