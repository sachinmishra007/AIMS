﻿namespace WIMI.Quotes.Repositories.Contracts
{
    public interface IAuthenticationService
    {
        bool AuthenticateUser(string username, string password);
        string GetUserRole(string userId);  
    }
}
