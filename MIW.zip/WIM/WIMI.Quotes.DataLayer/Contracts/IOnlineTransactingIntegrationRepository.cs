﻿using System;

namespace WIMI.Quotes.Repositories.Contracts
{
    public interface IOnlineTransactingIntegrationRepository
    {
        Entities.Transfer.QuoteInstance GetQuoteInstanceDetails(int quoteNumber);
        Entities.Transfer.GuaranteedGrowth GetGuaranteeedGrowthDetails(int quoteNumber);
        Entities.Transfer.GuaranteedIncome GetGuaranteeedIncomeDetails(int quoteNumber);
        
        Guid CreateNewFormInstance(ServiceReferences.OnlineTransactingService.FormInstance formInstance);
    }
}
