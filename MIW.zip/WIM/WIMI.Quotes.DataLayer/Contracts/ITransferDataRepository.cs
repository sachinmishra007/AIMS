﻿namespace WIMI.Quotes.Repositories.Contracts
{
    public interface ITransferDataRepository
    {
        Entities.Transfer.QuoteInstance GetQuoteInstanceDetails(int quoteNumber);

        Entities.Transfer.Fees GetFeeDetails(int quoteNumber);
        Entities.Transfer.LumpSum GetLumpSumDetails(int quoteNumber);
        Entities.Transfer.DebitOrder GetDebitOrderDetails(int quoteNumber);
        Entities.Transfer.Income GetIncomeDetails(int quoteNumber);
        Entities.Transfer.PhaseIn GetPhaseInDetails(int quoteNumber);

        Entities.Transfer.GuaranteedGrowth GetGuaranteeedGrowthDetails(int quoteNumber);
        Entities.Transfer.GuaranteedIncome GetGuaranteeedIncomeDetails(int quoteNumber);
    }
}
