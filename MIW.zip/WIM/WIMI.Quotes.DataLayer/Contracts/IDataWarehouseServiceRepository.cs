﻿using System.Collections.Generic;

namespace WIMI.Quotes.Repositories.Contracts
{
    public interface IDataWarehouseServiceRepository
    {
        List<Entities.Policy> GetClientPolicy(string clientNumber, string productCode);

        List<Entities.Fund> GetClientPolicyFund(string clientNumber, string policyNumber);

        List<Entities.ClientPolicyPhaseInDetails> GetClientPolicyPhaseInDetails(string clientNumber, string policyNumber);
    }
}
