﻿using System.Linq;
using WIMI.Quotes.Common.Extensions;

namespace WIMI.Quotes.Repositories
{
    public class TransferDataRepository : Contracts.ITransferDataRepository
    {
        #region Data Retrieval Standard Products

        public Entities.Transfer.QuoteInstance GetQuoteInstanceDetails(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var details = context.pGetQuoteDetails_Details(quoteNumber).FirstOrDefault();

                if (details == null)
                    return null;

                return new Entities.Transfer.QuoteInstance
                {
                    QuoteNumber = details.QuoteNumber,
                    ProductCode = details.ProductCode,
                    BrokerCode = details.BrokerCode,
                    ClientNumber = details.ClientNumber
                };
            }
        }

        public Entities.Transfer.LumpSum GetLumpSumDetails(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var details = context.pGetQuoteDetails_LumpSum(quoteNumber).ToList();

                if (details.Count == 0)
                    return null;

                return new Entities.Transfer.LumpSum
                {
                    GrossAmount = (double)details.First().LumpSumGrossAmount.GetValueOrDefault(),
                    NettAmount = (double)details.First().LumpSumNettAmount,
                    Funds = details.Select(Mappings.WIMQuotesDataTransferMappings.ToFund).ToList()
                };
            }
        }

        public Entities.Transfer.DebitOrder GetDebitOrderDetails(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var details = context.pGetQuoteDetails_DebitOrder(quoteNumber).ToList();

                if (details.Count == 0)
                    return null;

                var initialDebitOrder = details.First();

                return new Entities.Transfer.DebitOrder
                {
                    GrossAmount = (double)initialDebitOrder.DebitOrderGrossAmount,
                    NettAmount = (double)initialDebitOrder.DebitOrderNettAmount,
                    EscalationPercentage = (double)initialDebitOrder.EscalationPercentage,
                    Frequency = (Entities.Transfer.FrequencyType)initialDebitOrder.FrequencyId,
                    Funds = details.Select(Mappings.WIMQuotesDataTransferMappings.ToFund).ToList()
                };
            }
        }

        public Entities.Transfer.Income GetIncomeDetails(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var details = context.pGetQuoteDetails_Income(quoteNumber).ToList();

                if (details.Count == 0)
                    return null;

                var initialIncome = details.First();

                return new Entities.Transfer.Income
                {
                    Amount = (double)initialIncome.IncomeAmount,
                    Percentage = (double)initialIncome.IncomePercentage,
                    EscalationPercentage = (double)initialIncome.EscalationPercentage,
                    Frequency = (Entities.Transfer.FrequencyType)initialIncome.FrequencyId,
                    IncomeType = (Entities.Transfer.IncomeType)initialIncome.IncomeType.ToInt(),
                    Funds = details.Select(Mappings.WIMQuotesDataTransferMappings.ToFund).ToList()
                };
            }
        }

        public Entities.Transfer.Fees GetFeeDetails(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var feeDetails = context.pGetQuoteDetails_FeeDetails(quoteNumber).FirstOrDefault();

                if (feeDetails == null)
                    return null;

                return new Entities.Transfer.Fees
                {
                    AnnualAdminFee = (double)feeDetails.AnnualAdminFee,
                    AnnualFee = (double)feeDetails.AnnualFee.GetValueOrDefault(),
                    AnnualProcessingFee = (double)feeDetails.AnnualProcessingFee.GetValueOrDefault(),
                    DebitORderFee = (double)feeDetails.DebitORderFee.GetValueOrDefault(),
                    InitialFee = (double)feeDetails.InitialFee.GetValueOrDefault()
                };
            }
        }

        public Entities.Transfer.PhaseIn GetPhaseInDetails(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var phaseInFunds = context.pGetQuoteDetails_PhaseIn(quoteNumber).ToList();

                if (phaseInFunds.Count == 0)
                    return null;

                var phaseInDetails = phaseInFunds.First();

                var phaseInRecords = new Entities.Transfer.PhaseIn
                {
                    Amount = (double) phaseInDetails.LumpSumGrossAmount.GetValueOrDefault(),
                    IsRegulation28Compliant = true,
                    PhaseInCommencementDate = phaseInDetails.CommencementDate.GetValueOrDefault(),
                    PhaseInLumpSumAmount = (double) phaseInDetails.LumpSumNettAmount,
                    PhaseFromFunds = Mappings.WIMQuotesDataTransferMappings.ToPhaseFromFunds(phaseInDetails),
                    Funds = phaseInFunds.Select(Mappings.WIMQuotesDataTransferMappings.ToFund).ToList()  
                };
                
                return phaseInRecords;
            }
        }

        #endregion

        #region Data Retrieval Guar Series

        public Entities.Transfer.GuaranteedGrowth GetGuaranteeedGrowthDetails(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var growth = context.pGetQuoteDetails_GuaranteedGrowth(quoteNumber).FirstOrDefault();

                if (growth == null)
                    return null;

                return new Entities.Transfer.GuaranteedGrowth
                {
                    GrowthType = Entities.Profiles.GuaranteedGrowthType.Growth,
                    InvestmentAmount = (double)growth.InvestmentAmount.GetValueOrDefault(),
                    MaturityValue = (double)growth.MaturityValue.GetValueOrDefault(),
                    MaturityDate = growth.MaturityDate.GetValueOrDefault(),
                    AdvisorCommissionPercentage = (double)growth.AdvisorCommissionPercentage.GetValueOrDefault(),
                    AdminFeePercentage = (double)growth.AdminFeePercentage.GetValueOrDefault(),
                    AdminLifeFeePercentage = (double)growth.AdminLifeFeePercentage.GetValueOrDefault(),
                    TaxLossFeePercentage = (double)growth.TaxLossFeePercentage.GetValueOrDefault()
                };
            }
        }

        public Entities.Transfer.GuaranteedIncome GetGuaranteeedIncomeDetails(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var income = context.pGetQuoteDetails_GuaranteedIncome(quoteNumber).FirstOrDefault();

                if (income == null)
                    return null;

                return new Entities.Transfer.GuaranteedIncome
                {
                    IncomeType = Entities.Profiles.GuaranteedIncomeType.Income,
                    InvestmentAmount = (double)income.InvestmentAmount.GetValueOrDefault(),
                    GrossMonthlyIncome = (double)income.GrossMonthlyIncome.GetValueOrDefault(),
                    NetMonthlyIncome = (double)income.NetMonthlyIncome.GetValueOrDefault(),
                    EffectiveRate = (double)income.EffectiveRate.GetValueOrDefault(),
                    PreferredTaxRate = (double)income.PreferredTaxRate.GetValueOrDefault(),
                    TaxPayable = (double)income.TaxPayable.GetValueOrDefault(),
                    TaxablePortion = (double)income.TaxablePortion.GetValueOrDefault(),
                    CommencementDate = income.CommencementDate.GetValueOrDefault(),
                    FirstIncomePaymentDate = income.FirstIncomePaymentDate.GetValueOrDefault(),
                    MaturityDate = income.MaturityDate.GetValueOrDefault(),
                    AdvisorCommissionPercentage = (double)income.AdvisorCommissionPercentage.GetValueOrDefault(),
                    AdminFeePercentage = (double)income.AdminFeePercentage.GetValueOrDefault(),
                    AdminLifeFeePercentage = (double)income.AdminLifeFeePercentage.GetValueOrDefault(),
                    TaxLossFeePercentage = (double)income.TaxLossFeePercentage.GetValueOrDefault()
                };
            }
        }

        #endregion
    }
}
