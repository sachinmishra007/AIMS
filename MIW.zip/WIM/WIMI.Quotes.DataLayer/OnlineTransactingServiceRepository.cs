﻿using System;

using Service = WIMI.Quotes.ServiceReferences.OnlineTransactingService;

namespace WIMI.Quotes.Repositories
{
    public class OnlineTransactingServiceRepository : Contracts.IOnlineTransactingServiceRepository
    {
        public Guid CreateNewFormInstance(Service.FormInstance formInstance)
        {
            using (var context = new Service.OnlineTransactingServiceClient())
            {
                return context.CreateNewFormInstance(formInstance);
            }
        }

        public Entities.Transfer.FormInstanceDetails GetFormInstanceDetails(string externalReferenceId)
        {
            using (var context = new Service.OnlineTransactingServiceClient())
            {
                var contextFormInstanceDetails = context.GetFormInstanceDetails(externalReferenceId);

                if (contextFormInstanceDetails == null)
                    return null;

                return Mappings.OnlineTransactingServiceMappings.FromFormInstanceDetails(contextFormInstanceDetails);
            }
        }
    }
}
