﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMI.Quotes.Repositories.Contracts;
using WIMI.Quotes.ServiceReferences.SLAMaintenanceService;

namespace WIMI.Quotes.Repositories
{
    public class SLAMaintenanceRepository : ISLAMaintenanceRepository
    {
        public List<Entities.LookupItem> GetFundRange(string ProductId, string SubCode)
        {
            List<Entities.LookupItem> lookupItems = new List<Entities.LookupItem>();

            using (var context = new SLAMaintenanceClient())
            {
                var categoryFunds = context.GetFundRange(ProductId, SubCode);

                lookupItems = categoryFunds.Select(f => new Entities.LookupItem
                   {
                       Code = f.Code,
                       Description = f.Description
                   }).ToList();

                return lookupItems;

            }
        }

        public List<Entities.FundProductRule> GetFundMinimum(List<Entities.FundProductRule> fundProductRule)
        {
            List<Entities.FundProductRule> fundProductRulesList = new List<Entities.FundProductRule>();

            if (fundProductRule == null || fundProductRule.Count == 0)

                return null;


            using (var context = new SLAMaintenanceClient())
            {
                var fundProductRules = fundProductRule.Select(f => new WIMI.Quotes.ServiceReferences.SLAMaintenanceService.FundProductRule
                    {

                        AssociatedFundAmnt = f.AssociatedFundAmnt,
                        AssociatedFundPercentage = f.AssociatedFundPercentage,
                        ClientNumber = f.ClientNumber,
                        IsValid = f.IsValid,
                        MinFundAmount = f.MinFundAmount,
                        TopUpFrequency = f.TopUpFrequency,
                        TransactionTypeId = f.TransactionTypeId,
                        FundId = f.FundId,
                        Amount = f.Amount,
                        ProductId = f.ProductId                       
                    }).ToList();

                var result = context.GetFundMinimum(fundProductRules);

                fundProductRulesList = result.Select(f => new Entities.FundProductRule
                   {

                       Amount = f.Amount,
                       AssociatedFundAmnt = f.AssociatedFundAmnt,
                       AssociatedFundPercentage = f.AssociatedFundPercentage,
                       ClientNumber = f.ClientNumber,
                       FundId = f.FundId,
                       IsValid = f.IsValid,
                       MinFundAmount = f.MinFundAmount,
                       ProductId = f.ProductId,
                       TopUpFrequency = f.TopUpFrequency,
                       TransactionTypeId = f.TransactionTypeId,
                       FundName = f.FundName
                   }).ToList();
                return fundProductRulesList != null ? fundProductRulesList : null;
            }
        }
    }

}
