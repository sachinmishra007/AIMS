﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;

using WIMI.Quotes.Repositories.Contracts;
using WIMI.Quotes.ServiceReferences.WIMQuotesWCFService;

namespace WIMI.Quotes.Repositories
{
    public class WIMQuotesWCFServiceRepository : IWIMQuotesWCFServiceRepository
    {
        /// <summary>
        /// Generate a Quote for a Standard Product
        /// </summary>
        /// <param name="investment">Investment details to generate a quote for</param>
        /// <returns>Instance of <see cref="Investment"/></returns>
        public Investment GenerateStandardQuote(Investment investment)
        {
            try
            {
                using (var client = new WIMQuotesWCFServiceClient())
                {
                    return client.Generate(investment);
                }
            }
            catch (FaultException<ValidationFault> valEx)
            {
                throw new Entities.Exceptions.ValidationException(valEx.Message);
            }
        }

        /// <summary>
        /// Generate a Quote for Guaranteed Series data
        /// </summary>
        /// <param name="guaranteedSeries">Guaranteed Series details to generate a quote for</param>
        /// <returns>Instance of <see cref="GuaranteedSeries"/></returns>
        public GuaranteedSeries GenerateGuaranteedSeriesQuote(GuaranteedSeries guaranteedSeries)
        {
            try
            {
                using (var client = new WIMQuotesWCFServiceClient())
                {
                    return client.GenerateGuaranteedSeriesQuotes(guaranteedSeries);
                }
            }
            catch (FaultException<ValidationFault> valEx)
            {
                throw new Entities.Exceptions.ValidationException(valEx.Message);
            }
        }

        public AULSeries GenerateGuaranteedAULSeriesQuote(AULSeries aulSeries)
        {
            try
            {
                using (var client = new WIMQuotesWCFServiceClient())
                {
                    return client.GenerateAULQuotes(aulSeries);
                }
            }
            catch (FaultException<ValidationFault> valEx)
            {
                throw new Entities.Exceptions.ValidationException(valEx.Message);
            }
        }

        /// <summary>
        /// Retrieves all Completed Quotes from the Quotes Service for supplied <param name="brokerCode">Broker Code</param> 
        /// and <param name="clientNumber">Client Number</param> 
        /// </summary>
        /// <param name="brokerCode">Broker Code</param>
        /// <param name="clientNumber">Client Number</param>
        /// <param name="vendorId">Vendor identifier setup on the Quotes Service to uniquely identify calling application</param>
        /// <returns>List of <see cref="Entities.QuoteHistoryItem"/></returns>
        public List<Entities.QuoteHistoryItem> GetCompletedQuotes(string brokerCode, string clientNumber, Guid vendorId)
        {
            if (string.IsNullOrWhiteSpace(brokerCode))
                return new List<Entities.QuoteHistoryItem>();

            try
            {
                using (var client = new WIMQuotesWCFServiceClient())
                {
                    var recentQuotes = client.GetRecentQuotes(brokerCode, clientNumber, vendorId);

                    if (recentQuotes == null)
                        return new List<Entities.QuoteHistoryItem>();

                    return recentQuotes.Select(r => new Entities.QuoteHistoryItem
                    {
                        QuoteNumber = r.Quotenumber,
                        AdvisorCode = r.BrokerCode,
                        ClientNumber = r.ClientNumber,
                        CreatedDate = r.DateCreated,
                        Description = r.ProductName,
                        Status = Entities.QuoteItemStatus.Complete,
                        CanTransact = r.CanTransact
                    }).OrderByDescending(q => q.CreatedDate).ToList();
                }
            }
            catch (FaultException<NoResultsFoundFault>)
            {
                // Service Throws NoResultsFoundFault for no results
                return new List<Entities.QuoteHistoryItem>();
            }
        }

        /// <summary>
        /// Generates a Quote Report PDF for the supplied details
        /// </summary>
        /// <param name="quoteNumber">Quote Number of the generated quote to create a Quote Report for</param>
        /// <param name="brokerCode">Broker Code of the generated quote to create a Quote Report for</param>
        /// <param name="clientNumber">Client Number  of the generated quote to create a Quote Report for</param>
        /// <param name="vendorId">Vendor identifier setup on the Quotes Service to uniquely identify calling applicatio</param>
        public Entities.File GenerateQuoteReport(int quoteNumber, string brokerCode, string clientNumber, Guid vendorId)
        {
            using (var client = new WIMQuotesWCFServiceClient())
            {
                var reportFile = client.GenerateQuoteReport(quoteNumber, brokerCode, clientNumber, vendorId);

                if (reportFile == null)
                    return null;

                return new Entities.File
                {
                    Name = reportFile.Name,
                    Data = reportFile.Data
                };
            }
        }
    }
}
