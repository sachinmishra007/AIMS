﻿using System;
using System.Collections.Generic;
using System.Linq;
using WIMI.Quotes.Common.Helpers;
using WIMI.Quotes.ServiceReferences.PortfolioPerformanceService;

namespace WIMI.Quotes.Repositories
{
    public class PortfolioPerformanceServiceRepository : Contracts.IPortfolioPerformanceServiceRepository
    {
        /// <summary>
        /// Returns Fund Fact Sheet links for provided <param name="fundCodes">fund codes</param>
        /// </summary>
        public List<Entities.FundFactSheet> GetFundFactSheetsList(List<Entities.Fund> fundCodes)
        {
            using (var context = new PortfolioPerformanceServiceClient())
            {
                var fundFactSheets = new List<Entities.FundFactSheet>();
                var funds = Mappings.PortfolioPerformanceServiceMappings.ToFunds(fundCodes);
                var serviceFundFactSheets = context.GetFundFactSheetsList(funds);

                foreach (var fundFactSheet in serviceFundFactSheets.Where(f => f != null))
                {
                    if (fundFactSheet.WrapFundFactSheets != null && fundFactSheet.WrapFundFactSheets.Count > 0)
                    {
                        fundFactSheets.AddRange(fundFactSheet.WrapFundFactSheets
                            .Where(f => f != null)
                            .Select(Mappings.PortfolioPerformanceServiceMappings.FromFundFactSheet));
                    }
                    else
                    {
                        fundFactSheets.Add(Mappings.PortfolioPerformanceServiceMappings.FromFundFactSheet(fundFactSheet));
                    }
                }

                return fundFactSheets.OrderBy(f => f.Name).ToList();
            }
        }

        /// <summary>
        /// Returns Product Brochure file for provided <param name="productCode">product code</param>
        /// </summary>
        /// <param name="productCode">Product code to return the Product Brochure file for</param>
        /// <param name="language">Language of the Product Brochure to return</param>
        /// <returns>Product brochure file</returns>
        public byte[] GetProductBrochure(string productCode, Entities.Language language)
        {
            try
            {
                using (var context = new PortfolioPerformanceServiceClient())
                {
                    var productBrochure = context.GetProductDocument(productCode, Mappings.PortfolioPerformanceServiceMappings.ToLanguage(language), 
                        DocumentType.ProductBrochure);

                    if (productBrochure == null || productBrochure.Data == null || productBrochure.Data.Length == 0)
                        return new byte[0];

                    return productBrochure.Data;
                }
            }
            catch (Exception ex)
            {
                AuditHelper.LogException(ex);
                return new byte[0];
            }
        }
    }
}
