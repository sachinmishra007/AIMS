﻿using WIMI.Quotes.ServiceReferences.Regulation28Service;

namespace WIMI.Quotes.Repositories
{
    public class Regulation28ServiceRepository : Contracts.IRegulation28ServiceRepository
    {
        public Entities.Regulation28.ComplianceCheckResult CheckCompliance(Entities.Regulation28.ComplianceCheckDetails complianceCheckDetails)
        {
            if (complianceCheckDetails == null || complianceCheckDetails.Funds == null ||
                complianceCheckDetails.Funds.Count == 0)
                return null;

            using (var client = new Regulation28ServiceClient())
            {
                var result = client.CheckFundCompliance(Mappings.Regulation28ServiceMapping.ToComplianceCheckDetails(complianceCheckDetails));
                return result == null ? null : Mappings.Regulation28ServiceMapping.FromComplianceCheckResult(result);
            }
        }
    }
}
