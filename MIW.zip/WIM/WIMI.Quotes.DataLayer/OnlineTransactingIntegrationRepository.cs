﻿using System;
using System.Linq;

using WIMI.Quotes.Entities.Profiles;
using Service = WIMI.Quotes.ServiceReferences.OnlineTransactingService;

namespace WIMI.Quotes.Repositories
{
    public class OnlineTransactingIntegrationRepository : Contracts.IOnlineTransactingIntegrationRepository
    {
        public Entities.Transfer.QuoteInstance GetQuoteInstanceDetails(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var details = context.pGetQuoteDetails_Details(quoteNumber).FirstOrDefault();

                if (details == null)
                    return null;

                return new Entities.Transfer.QuoteInstance
                {
                    QuoteNumber = details.QuoteNumber,
                    ProductCode = details.ProductCode,
                    BrokerCode = details.BrokerCode,
                    ClientNumber = details.ClientNumber
                };
            }
        }

        public Entities.Transfer.GuaranteedGrowth GetGuaranteeedGrowthDetails(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var growth = context.pGetQuoteDetails_GuaranteedGrowth(quoteNumber).FirstOrDefault();

                if (growth == null)
                    return null;

                return new Entities.Transfer.GuaranteedGrowth
                {
                    GrowthType = GuaranteedGrowthType.Growth,
                    InvestmentAmount = (double)growth.InvestmentAmount.GetValueOrDefault(),
                    MaturityValue = (double)growth.MaturityValue.GetValueOrDefault(),
                    MaturityDate = growth.MaturityDate.GetValueOrDefault(),
                    AdvisorCommissionPercentage = (double)growth.AdvisorCommissionPercentage.GetValueOrDefault(),
                    AdminFeePercentage = (double)growth.AdminFeePercentage.GetValueOrDefault(),
                    AdminLifeFeePercentage = (double)growth.AdminLifeFeePercentage.GetValueOrDefault(),
                    TaxLossFeePercentage = (double)growth.TaxLossFeePercentage.GetValueOrDefault()
                };
            }
        }

        public Entities.Transfer.GuaranteedIncome GetGuaranteeedIncomeDetails(int quoteNumber)
        {
            using (var context = new Data.WIMQuotesEntities())
            {
                var income = context.pGetQuoteDetails_GuaranteedIncome(quoteNumber).FirstOrDefault();

                if (income == null)
                    return null;

                return new Entities.Transfer.GuaranteedIncome
                {
                    IncomeType = GuaranteedIncomeType.Income,
                    InvestmentAmount = (double)income.InvestmentAmount.GetValueOrDefault(),
                    GrossMonthlyIncome = (double)income.GrossMonthlyIncome.GetValueOrDefault(),
                    NetMonthlyIncome = (double)income.NetMonthlyIncome.GetValueOrDefault(),
                    EffectiveRate = (double)income.EffectiveRate.GetValueOrDefault(),
                    PreferredTaxRate = (double)income.PreferredTaxRate.GetValueOrDefault(),
                    TaxPayable = (double)income.TaxPayable.GetValueOrDefault(),
                    TaxablePortion = (double)income.TaxablePortion.GetValueOrDefault(),
                    CommencementDate = income.CommencementDate.GetValueOrDefault(),
                    FirstIncomePaymentDate = income.FirstIncomePaymentDate.GetValueOrDefault(),
                    MaturityDate = income.MaturityDate.GetValueOrDefault(),
                    AdvisorCommissionPercentage = (double)income.AdvisorCommissionPercentage.GetValueOrDefault(),
                    AdminFeePercentage = (double)income.AdminFeePercentage.GetValueOrDefault(),
                    AdminLifeFeePercentage = (double)income.AdminLifeFeePercentage.GetValueOrDefault(),
                    TaxLossFeePercentage = (double)income.TaxLossFeePercentage.GetValueOrDefault()
                };
            }
        }

        public Guid CreateNewFormInstance(Service.FormInstance formInstance)
        {
            using (var context = new Service.OnlineTransactingServiceClient())
            {
                return context.CreateNewFormInstance(formInstance);
            }
        }
    }
}
