﻿using System;
using System.Linq;

using WIMI.Quotes.Common;

namespace WIMI.Quotes.Repositories
{
    public class PhaseInRepository : Contracts.IPhaseInRepository
    {
       public DateTime? GetCommencementDate()
        {
            Data.WIMQuotesEntities context = null;

            try
            {
                using (context = new Data.WIMQuotesEntities())
                {
                    return context.pGetQuoteProfileFirstDate(Constants.SectionId.PhaseInSectionId).FirstOrDefault();
                }
            }
            finally
            {
                if (context != null)
                {
                    context.Dispose();
                }
            }
        }
    }
}
