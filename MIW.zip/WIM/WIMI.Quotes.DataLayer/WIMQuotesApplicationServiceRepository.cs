﻿using System;
using System.Collections.Generic;
using System.Linq;
using WIMI.Quotes.Common;
using WIMI.Quotes.Repositories.Contracts;
using WIMI.Quotes.ServiceReferences.WIMQuotesApplicationService;

namespace WIMI.Quotes.Repositories
{
    public class WIMQuotesApplicationServiceRepository : IWIMQuotesApplicationServiceRepository
    {
        private const string AdvisorSearchControlName = "FullName";

        public List<Entities.Client> GetClientsByBroker(string brokerCode, string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
                return new List<Entities.Client>();

            using (var appService = new WIMQuotesApplicationServiceClient())
            {
                var clientList = appService.GetAdvisorsClientByPredictiveSearch(searchTerm, brokerCode, AdvisorSearchControlName);

                return clientList.Select(c => new Entities.Client
                {
                    ClientID = c.ClientID,
                    ClientType = c.ClientType,
                    ClientNumber = c.ClientNumber,
                    ClientSubType = c.ClientSubType,
                    Language = c.ClientLang,
                    Gender = c.ClientGender,
                    IdentificationType = c.IDType,
                    IDNumber = c.IDPassRegNo,
                    Name = c.ClientGivenNames,
                    Surname = c.ClientSurname,
                    Title = c.ClientTitle,
                    FullName = c.ClientFullName,
                    DateOfBirth = c.DOB.ToString(Common.Constants.StringFormats.DateFormat),
                    IsTempClient = c.IsTempClient,
                    Staff = c.MemberType,
                    Age=c.Age
                }).ToList();
            }
        }

        public List<Entities.Advisor> GetAdvisors(string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
                return new List<Entities.Advisor>();

            using (var appService = new WIMQuotesApplicationServiceClient())
            {
                var advisorList = appService.GetAdminAdvisorsbyPredictiveSearch(searchTerm);

                if (advisorList == null || advisorList.Count == 0)
                    return new List<Entities.Advisor>();

                return advisorList.Select(Mappings.WIMQuotesApplicationServiceMappings.UserToEntitesAdvisor).ToList();
            }
        }

        public Entities.Advisor GetAdvisor(string advisorCode)
        {
            if (string.IsNullOrWhiteSpace(advisorCode))
                return new Entities.Advisor();

            using (var appService = new WIMQuotesApplicationServiceClient())
            {
                var advisor = appService.GetAdvisorDetalisByAdisorId(advisorCode);

                if (advisor == null)
                    return null;

                return Mappings.WIMQuotesApplicationServiceMappings.UserToEntitesAdvisor(advisor);
            }
        }

        public List<Entities.QuoteHistoryItem> GetHistoricalQuotes(string brokerCode, string clientNumber)
        {
            using (var appService = new WIMQuotesApplicationServiceClient())
            {
                var historicalQuotes = appService.GetHistoricalQuotes(new QuoteHistoryRequest
                {
                    BrokerCode = brokerCode,
                    ClientNumber = clientNumber
                });

                if (historicalQuotes == null || historicalQuotes.Count == 0)
                    return new List<Entities.QuoteHistoryItem>();

                return historicalQuotes.Select(Mappings.WIMQuotesApplicationServiceMappings.ToQuoteHistoryItem).ToList();
            }
        }

        public void SaveQuoteDocument(int quoteNumber, Entities.File quoteReportFile)
        {
            using (var appService = new WIMQuotesApplicationServiceClient())
            {
                appService.SaveQuoteDocuments(new QuoteDocument
                {
                    QuoteNumber = quoteNumber,
                    DocumentCoreName = quoteReportFile.Name,
                    DocumentFullName = quoteReportFile.Name,
                    DocumentPath = quoteReportFile.FullQualifiedName
                });
            }
        }

        #region Existing Investments

        public decimal GetLatestInvestmentValue(string clientNumber, string productCode)
        {
            using (var appService = new WIMQuotesApplicationServiceClient())
            {
                var productInvestmentValue = appService.GetLatestInvestmentValue(clientNumber, productCode);
                return productInvestmentValue != null ? productInvestmentValue.Value : 0;
            }
        }

        #endregion

        #region Existing Advisor Ongoing Fee

        public decimal GetAdvisorOngoingFee(string brokerCode, string policyNumber)
        {
            using (var appService = new WIMQuotesApplicationServiceClient())
            {
                var brokerFee = appService.GetBrokerFee(brokerCode, policyNumber, Constants.FeeType.Fee);
                return brokerFee == null ? 0 : brokerFee.FeeAmt;
            }
        }

        #endregion
    }
}
