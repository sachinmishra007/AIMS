﻿using System;
using WIMI.Quotes.Repositories.Contracts;
using WIMI.Quotes.ServiceReferences.ClientMaintenanceService;

namespace WIMI.Quotes.Repositories 
{
    public class ClientMaintenanceRepository : IClientMaintenanceRepository
    {
        public string CreateClient(Entities.Client client)
        {
            using (var context = new ClientMaintenanceClient())
            {
               return context.AddClient(new Client
                {
                    SurnameOrganisation = !string.IsNullOrWhiteSpace(client.Surname) ? client.Surname : string.Empty,
                    FirstName = !string.IsNullOrWhiteSpace(client.Name) ? client.Name : string.Empty,
                    Age = client.Age,
                    DateOfBirth = !string.IsNullOrWhiteSpace(client.DateOfBirth) ? string.Format("{0:yyyy/MM/dd}", Convert.ToDateTime(client.DateOfBirth)) : string.Empty,
                    IDType = client.IdentificationType,
                    IdPassRegNumber = client.IDNumber,
                    AdvisorCode = client.Advisor,
                    Title = client.Title,
                    ClientType = client.ClientType,
                    EntityType = client.ClientSubType,
                    MemberType = Mappings.ClientMaintenanceServiceMappings.ToMemberType(client.Staff),
                    Gender = Mappings.ClientMaintenanceServiceMappings.ToGender(client.Gender),
                    Language = Mappings.ClientMaintenanceServiceMappings.ToLanguage(client.Language)
                });
            }
        }

        public string UpdateClient(Entities.Client client)
        {
            using (var context = new ClientMaintenanceClient())
            {
                context.UpdateClient(new Client
                {
                    ClientId=client.ClientID,
                    SurnameOrganisation = !string.IsNullOrWhiteSpace(client.Surname) ? client.Surname : string.Empty,
                    FirstName = !string.IsNullOrWhiteSpace(client.Name) ? client.Name : string.Empty,
                    Age = client.Age,
                    ClientType=client.ClientType,
                    DateOfBirth = !string.IsNullOrWhiteSpace(client.DateOfBirth) ? string.Format("{0:yyyy/MM/dd}", Convert.ToDateTime(client.DateOfBirth)) : string.Empty,
                    IDType = client.IdentificationType,
                    IdPassRegNumber = client.IDNumber,
                    AdvisorCode = client.Advisor,
                    Title = client.Title,
                    EntityType=client.ClientSubType,
                    MemberType = Mappings.ClientMaintenanceServiceMappings.ToMemberType(client.Staff),
                    Gender = Mappings.ClientMaintenanceServiceMappings.ToGender(client.Gender),
                    Language = Mappings.ClientMaintenanceServiceMappings.ToLanguage(client.Language)
                });

                return client.ClientNumber;
            }
        }

        
    }
}
