﻿using System.Collections.Generic;
using System.Linq;

using WIMI.Quotes.Repositories.Contracts;
using WIMI.Quotes.ServiceReferences.DataWarehouseService;

namespace WIMI.Quotes.Repositories
{
    public class DataWarehouseServiceRepository : IDataWarehouseServiceRepository
    {
        public List<Entities.Policy> GetClientPolicy(string clientNumber, string productCode)
        {
            using (var context = new DataWarehouseServiceClient())
            {
                var clientPolicyList = context.GetClientPolicies(clientNumber, productCode, false);

                return clientPolicyList.Select(p => new Entities.Policy
                {
                    PolicyNumber = p.PolicyNumber,
                    CaNumber = p.CaNumber,
                    LatestMarketValue = p.LatestMarketValue,
                    ClientNumber = p.ClientNumber,
                    ProductCode = p.ProductCode,
                    IsActive = p.IsActive,
                    BDANumber = p.BDANumber
                }).ToList();
            }
        }

        public List<Entities.Fund> GetClientPolicyFund(string clientNumber, string policyNumber)
        {
            using (var context = new DataWarehouseServiceClient())
            {
                var clientPolicyFundList = context.GetClientPolicyFundDetails(clientNumber, policyNumber);

                return clientPolicyFundList.Select(f => new Entities.Fund
                 {
                     Code = f.FundCode,
                     Name = f.FundName,
                     Type = f.FundType,
                     Percentage = (double)f.FundPercentage.GetValueOrDefault(),
                     Amount = (double)f.FundValue.GetValueOrDefault(),
                     IsSharedPortfolio = f.IsSharePortfolio,
                     IsEtf = f.IsEtf
                 }).ToList();
            }
        }

        public List<Entities.ClientPolicyPhaseInDetails> GetClientPolicyPhaseInDetails(string clientNumber, string policyNumber)
        {
            using (var context = new DataWarehouseServiceClient())
            {
                var policyPhaseInDetails = context.GetClientPolicyPhaseInDetails(clientNumber, policyNumber);

                if (policyPhaseInDetails == null)
                    return null;

                return policyPhaseInDetails.Select(policyPhase => new Entities.ClientPolicyPhaseInDetails
                {
                    PercSplit = policyPhase.PercSplit,
                    FundName = policyPhase.FundName,
                    FundCode = policyPhase.FundCode

                }).ToList();
            }
        }
    }
}
