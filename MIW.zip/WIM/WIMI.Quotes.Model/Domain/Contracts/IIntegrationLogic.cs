using System;
using System.Collections.Generic;

namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface IIntegrationLogic
    {
        string GetSolutionUserIdForSession(string sessionKey);
        List<Guid> ProcessSolutionQuoteItem(Guid quoteGroupId, string sessionKey);
        string GetSessionUser(string sessionApiKey);

        Entities.Transfer.TransferSessionDetails OnlineTransactingProcessApplication(int quoteNumber, string currentUserId);
    }
}
