﻿namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface ISettingsLogic
    {
        T GetApplicationSetting<T>(string appSettingKey);
    }
}
