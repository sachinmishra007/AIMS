﻿namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface IQuoteGenerationLogic
    {
        Entities.QuoteGenerationResult GenerateQuote(Entities.ReportOptions reportOptions, string userId);
    }
}
