﻿namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface IUserLogic
    {
        bool AuthenticateUser(string username, string password);
        string GetUserRole(string userId);
        bool IsValidUser(string userId);
    }
}
