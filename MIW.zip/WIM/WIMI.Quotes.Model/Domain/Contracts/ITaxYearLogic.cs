﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface ITaxYearLogic
    {
        List<Entities.TaxYears> GetTaxYear();
    }
}
