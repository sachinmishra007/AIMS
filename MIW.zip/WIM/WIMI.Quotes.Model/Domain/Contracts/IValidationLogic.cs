﻿using System.Collections.Generic;

namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface IValidationLogic
    {
        List<Entities.Validation> GetValidations(string productCode, string brokerCode, int stepId);
    }
}
