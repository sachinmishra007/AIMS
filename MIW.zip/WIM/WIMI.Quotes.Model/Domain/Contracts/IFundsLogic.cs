﻿using System.Collections.Generic;

namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface IFundsLogic
    {
        /// <summary>
        /// Returns List of <see cref="Entities.Fund"/> for the supplied filters
        /// </summary>
        /// <param name="productCode">Product code that the funds are linked to</param>
        /// <param name="fundRangeCode">Type of Fund Range to return funds for</param>
        /// <param name="brokerCode">Broker code to return any white labelled funds for</param>
        /// <returns>List of <see cref="Entities.Fund"/></returns>
        List<Entities.Fund> GetFundsList(string productCode, string fundRangeCode, string brokerCode);

        /// <summary>
        /// Returns a List of Fund Fact Sheet data for the provided <param name="quoteNumber">quote number</param>
        /// </summary>
        /// <param name="quoteNumber">Quote number to return Fund Fact Sheets for</param>
        /// <returns>List of file data bytes</returns>
        List<Entities.FundFactSheet> GetFundFactSheetsForQuote(int quoteNumber);

        Entities.FundProductRulesResult CheckFundMinimumAmount(Entities.FundMinimumDetails fundMinimumAmountDetails);
    }
}
