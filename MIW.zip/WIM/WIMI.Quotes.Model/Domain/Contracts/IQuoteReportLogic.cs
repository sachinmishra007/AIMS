﻿using System;

namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface IQuoteReportLogic
    {
        Entities.File GenerateQuoteReport(int quoteNumber, string brokerCode, string clientNumber);
        Entities.File GetConsolidatedQuoteReport(int quoteNumber);
        bool CanAccessQuoteReport(int quoteNumber, string userId);
    }
}
