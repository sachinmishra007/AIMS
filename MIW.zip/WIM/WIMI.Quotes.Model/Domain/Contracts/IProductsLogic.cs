﻿using System.Collections.Generic;

namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface IProductsLogic
    {
        /// <summary>
        /// Returns a <see cref="Entities.Product"/> for supplied <param name="productCode">product code</param>
        /// </summary>
        /// <param name="productCode">Product code to return product details for</param>
        /// <returns>Instance of <see cref="Entities.Product"/></returns>
        Entities.Product GetProduct(string productCode);

        /// <summary>
        /// Returns a List of <see cref="Entities.Product"/> setup to be used on the Quotations System and FAIS Licensed 
        /// for the supplied broker
        /// </summary>
        /// <param name="brokerCode">Broker Code to check FAIS License Products for</param>
        /// <param name="clientType">Client type Individual or Non-Inidividual</param>
        /// <param name="clientSubType">Sub type of the client i.e. Private Company for Non-Individual</param>
        /// <returns>List of <see cref="Entities.Product"/></returns>
        IEnumerable<Entities.Product> GetProductsList(string brokerCode, string clientType, string clientSubType);

        /// <summary>
        /// Returns Product Brochure file for provided <param name="productCode">product code</param>
        /// </summary>
        /// <param name="productCode">Product code to return the Product Brochure file for</param>
        /// <param name="language">Language of the Product Brochure to return</param>
        /// <returns>Product brochure file</returns>
        byte[] GetProductBrochure(string productCode, Entities.Language language);
    }
}
