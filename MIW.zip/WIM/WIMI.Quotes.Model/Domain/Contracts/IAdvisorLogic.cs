﻿using System.Collections.Generic;

namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface IAdvisorLogic
    {
        Entities.Advisor GetAdvisor(string brokerCode);
        List<Entities.Advisor> SearchAdvisors(string searchTerm);
        decimal GetAdvisorOngoingFee(string brokerCode, string policyNumber);
    }
}
