﻿using System.Collections.Generic;

namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface IClientLogic
    {
        IEnumerable<Entities.Client> GetBrokerClients(string brokerCode, string searchTerm);
        string CreateClient(Entities.Client client);
        decimal GetExistingInvestmentValue(string clientNumber, string brokerCode, string productCode);
        Entities.ClientContribution GetClientContributions(string clientNumber, string productCode);
        List<Entities.Policy> GetClientPolicies(string clientNumber, string productCode);
        List<Entities.Fund> GetClientPolicyFund(string clientNumber, string policyNumber);
        List<Entities.ClientPolicyPhaseInDetails> GetClientPolicyPhaseInDetails(string clientNumber, string policyNumber);
    }
}
