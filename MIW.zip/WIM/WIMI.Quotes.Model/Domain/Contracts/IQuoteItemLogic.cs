﻿using System;
using System.Collections.Generic;

namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface IQuoteItemLogic
    {
        List<Entities.QuoteHistoryItem> GetQuoteHistoryItems(string advisorNumber, string clientNumber, Entities.QuoteItemStatus status);
        Entities.QuoteItem GetQuoteItem(Guid quoteItemId);
        Entities.QuoteItem GetQuoteItem(int quoteNumber);
        List<Entities.QuoteItem> GetQuoteItems(Guid quoteGroupId);
        Guid SaveQuoteItem(Entities.QuoteItem quoteItem, string userId);
        void SaveQuoteGroup(Guid quoteGroupId, Guid quoteItemId);
    }
}
