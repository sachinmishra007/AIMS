﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface ILookupLogic
    {
        List<Entities.LookupItem> Get(string code);
        List<Entities.LookupItem> GetFundCategories(string productCode , string subCode);
    
    }
}
