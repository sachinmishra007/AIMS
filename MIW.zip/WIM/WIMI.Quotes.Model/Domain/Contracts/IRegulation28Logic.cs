﻿namespace WIMI.Quotes.Model.Domain.Contracts
{
    public interface IRegulation28Logic
    {
        Entities.Regulation28.ComplianceCheckResult CheckCompliant(Entities.Regulation28.ComplianceCheckDetails complianceCheckDetails);
    }
}
