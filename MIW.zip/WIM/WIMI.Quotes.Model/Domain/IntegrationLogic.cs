﻿using System;
using System.Collections.Generic;
using System.Linq;

using WIMI.Quotes.Common;
using WIMI.Quotes.Repositories.Contracts;

namespace WIMI.Quotes.Model.Domain
{
    public class IntegrationLogic : Contracts.IIntegrationLogic
    {
        #region Constructors & DI

        private readonly Contracts.IQuoteItemLogic _quoteItemLogic;
        private readonly Contracts.IClientLogic _clientLogic;
        private readonly Contracts.IAdvisorLogic _advisorLogic;
        private readonly Contracts.IProductsLogic _productsLogic;
        private readonly Contracts.ISettingsLogic _settingsLogic;

        private readonly ISessionApiRepository _sessionApiRepository;
        private readonly IWIMQuotesApplicationServiceRepository _applicationServiceRepository;
        private readonly ITransferDataRepository _transferDataRepository;
        private readonly IOnlineTransactingServiceRepository _onlineTransactingServiceRepository;

        public IntegrationLogic(
            Contracts.IQuoteItemLogic quoteItemLogic,
            Contracts.IClientLogic clientLogic,
            Contracts.IAdvisorLogic advisorLogic,
            Contracts.IProductsLogic productsLogic,
            Contracts.ISettingsLogic settingsLogic,
            ISessionApiRepository sessionApiRepository,
            IWIMQuotesApplicationServiceRepository applicationServiceRepository,
            ITransferDataRepository transferDataRepository,
            IOnlineTransactingServiceRepository onlineTransactingServiceRepository)
        {
            _sessionApiRepository = sessionApiRepository;
            _quoteItemLogic = quoteItemLogic;
            _clientLogic = clientLogic;
            _advisorLogic = advisorLogic;
            _productsLogic = productsLogic;
            _settingsLogic = settingsLogic;

            _applicationServiceRepository = applicationServiceRepository;
            _transferDataRepository = transferDataRepository;
            _onlineTransactingServiceRepository = onlineTransactingServiceRepository;
        }

        #endregion

        #region Solution Integration

        public string GetSolutionUserIdForSession(string sessionKey)
        {
            var quoteItem = _sessionApiRepository.DeserialiseSessionApiItem<List<Entities.SolutionQuoteItem>>(sessionKey, "SolutionQuoteItem").FirstOrDefault();
            return quoteItem != null ? quoteItem.AdvisorCode : null;
        }

        public List<Guid> ProcessSolutionQuoteItem(Guid quoteGroupId, string sessionKey)
        {
            var quoteItems = ExtractSolutionQuoteItem(sessionKey);
            var quoteItemIds = new List<Guid>();

            foreach (var quoteItem in quoteItems)
            {
                var quoteItemId = _quoteItemLogic.SaveQuoteItem(quoteItem, quoteItem.Advisor.Code);
                quoteItemIds.Add(quoteItemId);
                quoteItem.QuoteItemId = quoteItemId;
                _quoteItemLogic.SaveQuoteGroup(quoteGroupId, quoteItemId);
            }

            return quoteItemIds;
        }

        private List<Entities.QuoteItem> ExtractSolutionQuoteItem(string sessionKey)
        {
            var solutionQuoteItems = _sessionApiRepository.DeserialiseSessionApiItem<List<Entities.SolutionQuoteItem>>(sessionKey, "SolutionQuoteItem");

            if (solutionQuoteItems == null || solutionQuoteItems.Count == 0)
                return null;

            var firstQuoteItem = solutionQuoteItems.FirstOrDefault();

            if (firstQuoteItem == null)
                return null;

            //TODO:  Get this client using a proper getClient Search!
            var clients = _clientLogic.GetBrokerClients(firstQuoteItem.AdvisorCode, firstQuoteItem.ClientNumber);
            var client = clients.FirstOrDefault();

            if (client == null)
                return null;

            var advisor = _advisorLogic.GetAdvisor(firstQuoteItem.AdvisorCode);

            //TODO: Validate that client is linked to broker.

            var quoteItems = new List<Entities.QuoteItem>();

            foreach (var solutionQuoteItem in solutionQuoteItems)
            {
                var quoteItem = new Entities.QuoteItem
                {
                    Advisor = advisor,
                    Client = client,
                    Product = _productsLogic.GetProduct(solutionQuoteItem.ProductCode),
                    AkmId = solutionQuoteItem.AkmId,
                    Currency = new Entities.Currency { Code = "ZAR", Name = "South-African Rand", Symbol = "R" }
                };

                if (solutionQuoteItem.LumpSum != null)
                    quoteItem.Profiles.Add(solutionQuoteItem.LumpSum);

                if (solutionQuoteItem.Income != null)
                    quoteItem.Profiles.Add(solutionQuoteItem.Income);

                if (solutionQuoteItem.DebitOrder != null)
                    quoteItem.Profiles.Add(solutionQuoteItem.DebitOrder);

                if (solutionQuoteItem.GuaranteedGrowth != null)
                    quoteItem.Profiles.Add(solutionQuoteItem.GuaranteedGrowth);

                if (solutionQuoteItem.GuaranteedIncome != null)
                    quoteItem.Profiles.Add(solutionQuoteItem.GuaranteedIncome);

                if (
                    _applicationServiceRepository.GetLatestInvestmentValue(client.ClientNumber,
                        solutionQuoteItem.ProductCode) > 0)
                    quoteItem.Profiles.Add(new Entities.Profiles.Addition { IsActive = true });

                if (solutionQuoteItem.Fees != null && solutionQuoteItem.GuaranteedGrowth == null &&
                    solutionQuoteItem.GuaranteedIncome == null)
                {
                    solutionQuoteItem.Fees.VatVendor = advisor.VatVendor;

                    solutionQuoteItem.Fees.IsActive = true;

                    quoteItem.Profiles.Add(solutionQuoteItem.Fees);
                }
                else
                {
                    solutionQuoteItem.Fees = new Entities.Profiles.Fees { IsActive = false };
                }

                quoteItems.Add(quoteItem);
            }

            return quoteItems;
        }

        public string GetSessionUser(string sessionApiKey)
        {
            return _sessionApiRepository.GetSessionApiItem(sessionApiKey, "BrokerCode");
        }

        #endregion

        #region Online Transacting Integration

        public Entities.Transfer.TransferSessionDetails OnlineTransactingProcessApplication(int quoteNumber, string currentUserId)
        {
            var formInstanceDetails = _onlineTransactingServiceRepository.GetFormInstanceDetails(quoteNumber.ToString());

            Guid formInstanceId;

            if (formInstanceDetails == null || formInstanceDetails.InstanceId == Guid.Empty ||
                formInstanceDetails.FormStatus == Entities.Transfer.FormStatus.Cancelled)
            {
                formInstanceId = OnlineTransactingCreateNewApplication(quoteNumber);
            }
            else
            {
                formInstanceId = formInstanceDetails.InstanceId;
            }

            return StoreOnlineTransactingSessionDetails(formInstanceId, currentUserId);
        }

        private Guid OnlineTransactingCreateNewApplication(int quoteNumber)
        {
            var quoteInstanceDetails = _transferDataRepository.GetQuoteInstanceDetails(quoteNumber);

            if (quoteInstanceDetails == null || string.IsNullOrWhiteSpace(quoteInstanceDetails.ProductCode))
                throw new Exception(string.Format("No details found for Quote Number {0}", quoteNumber));

            var quoteItem = _quoteItemLogic.GetQuoteItem(quoteNumber);
            var lumpSum = quoteItem != null
                ? quoteItem.Profiles.FirstOrDefault(p => p.Type == Entities.Profiles.ProfileType.LumpSum) as
                    Entities.Profiles.LumpSum ?? new Entities.Profiles.LumpSum()
                : new Entities.Profiles.LumpSum();

            var advisorDetails = _advisorLogic.GetAdvisor(quoteInstanceDetails.BrokerCode);

            var formInstance = new ServiceReferences.OnlineTransactingService.FormInstance
            {
                FormType = string.IsNullOrWhiteSpace(lumpSum.PolicyNumber) ? ServiceReferences.OnlineTransactingService.FormType.NewBusiness :
                    ServiceReferences.OnlineTransactingService.FormType.Addition,
                ExternalReferenceId = quoteNumber.ToString(),
                PolicyNumber = lumpSum.PolicyNumber
            };

            var newBusinessDetails = new ServiceReferences.OnlineTransactingService.NewBusinessDetails
            {
                QuoteReferenceNumber = quoteNumber,
                ProductCode = quoteInstanceDetails.ProductCode,
                AdvisorDetails = Repositories.Mappings.OnlineTransactingServiceMappings.ToAdvisorDetails(advisorDetails)
            };

            if (quoteItem != null)
            {
                newBusinessDetails.ClientDetails = Repositories.Mappings.OnlineTransactingServiceMappings.ToClientDetails(quoteItem.Client);
            }
            else
            {
                newBusinessDetails.ClientDetails = new ServiceReferences.OnlineTransactingService.ClientDetails
                {
                    ClientNumber = quoteInstanceDetails.ClientNumber
                };
            }

            if (quoteItem.Product.IsGuaranteedProduct)
            {
                var growth = _transferDataRepository.GetGuaranteeedGrowthDetails(quoteNumber);
                var income = _transferDataRepository.GetGuaranteeedIncomeDetails(quoteNumber);

                newBusinessDetails.GuaranteedSeriesPlanDetails = new ServiceReferences.OnlineTransactingService.GuaranteedSeriesPlanDetails
            {
                Growth = Repositories.Mappings.OnlineTransactingServiceMappings.ToGuaranteedGrowth(growth),
                Income = Repositories.Mappings.OnlineTransactingServiceMappings.ToGuaranteedIncome(income)
            };

                newBusinessDetails.GuaranteedSeriesFeeDetails = new ServiceReferences.OnlineTransactingService.GuaranteedSeriesFeeDetails
                {
                    Growth = Repositories.Mappings.OnlineTransactingServiceMappings.ToGuaranteedGrowthFees(growth),
                    Income = Repositories.Mappings.OnlineTransactingServiceMappings.ToGuaranteedIncomeFees(income)
                };
            }
            else
            {
                var lumpSumDetails = _transferDataRepository.GetLumpSumDetails(quoteNumber);
                var incomeDetails = _transferDataRepository.GetIncomeDetails(quoteNumber);

                if (lumpSumDetails != null)
                    lumpSumDetails.BDANumber = lumpSum.BDANumber;

                if (lumpSumDetails != null && incomeDetails != null)
                    incomeDetails.IsIncomeEqualsLumpSum = Repositories.Mappings.OnlineTransactingServiceMappings.IsFundListIdentical(lumpSumDetails.Funds, incomeDetails.Funds);

                newBusinessDetails.LumpSum = Repositories.Mappings.OnlineTransactingServiceMappings.ToLumpSum(lumpSumDetails);
                newBusinessDetails.DebitOrder = Repositories.Mappings.OnlineTransactingServiceMappings.ToDebitOrder(_transferDataRepository.GetDebitOrderDetails(quoteNumber));
                newBusinessDetails.Income = Repositories.Mappings.OnlineTransactingServiceMappings.ToIncome(incomeDetails);
                newBusinessDetails.Fees = Repositories.Mappings.OnlineTransactingServiceMappings.ToFees(_transferDataRepository.GetFeeDetails(quoteNumber));
                newBusinessDetails.PhaseIn = Repositories.Mappings.OnlineTransactingServiceMappings.ToPhaseIn(_transferDataRepository.GetPhaseInDetails(quoteNumber));
            }

            formInstance.NewBusinessDetails = newBusinessDetails;

            return _onlineTransactingServiceRepository.CreateNewFormInstance(formInstance);
        }

        private Entities.Transfer.TransferSessionDetails StoreOnlineTransactingSessionDetails(Guid formInstanceId, string currentUserId)
        {
            Guid sessionKey = Guid.NewGuid();

            var returnUrl = _settingsLogic.GetApplicationSetting<string>(Constants.AppSettingsKeys.ReturnUrl);

            _sessionApiRepository.SetSessionApiItem(sessionKey.ToString(), "FormInstanceId", formInstanceId);
            _sessionApiRepository.SetSessionApiItem(sessionKey.ToString(), "UserId", currentUserId);
            _sessionApiRepository.SetSessionApiItem(sessionKey.ToString(), "ReturnUrl", returnUrl);

            return new Entities.Transfer.TransferSessionDetails
            {
                SessionId = sessionKey,
                Url = _settingsLogic.GetApplicationSetting<string>(Constants.AppSettingsKeys.TransferOnlineTransactingUrl)
            };
        }

        #endregion
    }
}
