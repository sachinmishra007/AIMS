﻿using System.Collections.Generic;

namespace WIMI.Quotes.Model.Domain
{
    public class ValidationLogic : Contracts.IValidationLogic
    {
        #region Contructor

        private readonly Repositories.Contracts.IWIMQuotesDataRepository _wimQuotesDataRepository;

        public ValidationLogic(Repositories.Contracts.IWIMQuotesDataRepository wimQuotesDataRepository)
        {
            _wimQuotesDataRepository = wimQuotesDataRepository;
        }

        #endregion

        public List<Entities.Validation> GetValidations(string productCode, string brokerCode, int stepId)
        {
            return _wimQuotesDataRepository.GetValidations(productCode, brokerCode, stepId);
        }
    }
}
