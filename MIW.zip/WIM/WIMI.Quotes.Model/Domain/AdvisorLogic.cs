﻿using System;
using System.Collections.Generic;

using WIMI.Quotes.Model.Domain.Contracts;
using WIMI.Quotes.Repositories.Contracts;

namespace WIMI.Quotes.Model.Domain
{
    public class AdvisorLogic : IAdvisorLogic
    {
        #region Constructor

        private readonly IWIMQuotesApplicationServiceRepository _wimQuotesApplicationServiceRepository;

        public AdvisorLogic(IWIMQuotesApplicationServiceRepository wimQuotesApplicationServiceRepository)
        {
            _wimQuotesApplicationServiceRepository = wimQuotesApplicationServiceRepository;
        }

        #endregion

        public Entities.Advisor GetAdvisor(string brokerCode)
        {
            return _wimQuotesApplicationServiceRepository.GetAdvisor(brokerCode);
        }

        public List<Entities.Advisor> SearchAdvisors(string searchTerm)
        {
            if (String.IsNullOrWhiteSpace(searchTerm) || searchTerm.Length < Common.Constants.Values.SearchTermMinLength)
                return new List<Entities.Advisor>();

            return _wimQuotesApplicationServiceRepository.GetAdvisors(searchTerm);
        }


        public decimal GetAdvisorOngoingFee(string brokerCode, string policyNumber)
        {
            return _wimQuotesApplicationServiceRepository.GetAdvisorOngoingFee(brokerCode, policyNumber);
        }
    }
}
