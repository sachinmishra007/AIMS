﻿using System;
using System.Collections.Generic;

using WIMI.Quotes.Common;
using WIMI.Quotes.Common.Helpers;

namespace WIMI.Quotes.Model.Domain
{
    public class QuoteReportLogic : Contracts.IQuoteReportLogic
    {
        #region Constructors & DI

        private readonly Contracts.ISettingsLogic _settingsLogic;
        private readonly Contracts.IUserLogic _userLogic;
        private readonly Contracts.IProductsLogic _productsLogic;
        private readonly Repositories.Contracts.IWIMQuotesDataRepository _wimQuotesDataRepository;
        private readonly Repositories.Contracts.IWIMQuotesWCFServiceRepository _wimQuotesWcfServiceRepository;

        public QuoteReportLogic(
            Contracts.ISettingsLogic settingsLogic,
            Contracts.IUserLogic userLogic,
            Contracts.IProductsLogic productsLogic,
            Repositories.Contracts.IWIMQuotesDataRepository wimQuotesDataRepository,
            Repositories.Contracts.IWIMQuotesWCFServiceRepository wimQuotesWcfServiceRepository)
        {
            _settingsLogic = settingsLogic;
            _userLogic = userLogic;
            _productsLogic = productsLogic;
            _wimQuotesDataRepository = wimQuotesDataRepository;
            _wimQuotesWcfServiceRepository = wimQuotesWcfServiceRepository;
        }

        #endregion

        #region Public Members

        public Entities.File GenerateQuoteReport(int quoteNumber, string brokerCode, string clientNumber)
        {
            if (quoteNumber <= 0 || String.IsNullOrEmpty(brokerCode) || String.IsNullOrEmpty(clientNumber))
                return null;

            var vendorId = _settingsLogic.GetApplicationSetting<Guid>(Constants.AppSettingsKeys.QuotesServiceVendorId);
            var quoteReport = _wimQuotesWcfServiceRepository.GenerateQuoteReport(quoteNumber, brokerCode, clientNumber, vendorId);

            if (quoteReport == null)
                return null;

            string persistentPath = GetReportPersistencePath();
            string quotedocumentPath = persistentPath + quoteReport.Name;

            System.IO.File.WriteAllBytes(quotedocumentPath, quoteReport.Data);

            return new Entities.File
            {
                Name = quoteReport.Name,
                FullQualifiedName = quotedocumentPath,
                Data = quoteReport.Data
            };
        }

        public Entities.File GetConsolidatedQuoteReport(int quoteNumber)
        {
            if (quoteNumber <= 0)
                return null;

            var quoteItem = _wimQuotesDataRepository.GetQuoteItem(quoteNumber);
            var storedQuoteReport = RetrieveStoredQuoteReport(quoteNumber);

            if (quoteItem == null || storedQuoteReport == null || storedQuoteReport.Data == null || storedQuoteReport.Data.Length == 0)
                return null;

            var reportFiles = new List<byte[]>
            {
                storedQuoteReport.Data
            };

            if (quoteItem.ReportOptions.IncludeProductBrochure && quoteItem.Product != null)
            {
                var productBrochure = _productsLogic.GetProductBrochure(quoteItem.Product.Code, quoteItem.ReportOptions.Language);

                if (productBrochure != null && productBrochure.Length != 0)
                    reportFiles.Add(productBrochure);
            }

            return new Entities.File
            {
                Name = storedQuoteReport.Name,
                Data = reportFiles.Count == 1 ? reportFiles[0] : PdfHelper.MergePdfFiles(reportFiles)
            };
        }

        public bool CanAccessQuoteReport(int quoteNumber, string userId)
        {
            if (quoteNumber <= 0 || String.IsNullOrWhiteSpace(userId))
                return false;

            string userRole = _userLogic.GetUserRole(userId);

            switch (userRole)
            {
                case Constants.Roles.Administrator:
                    return true;
                case Constants.Roles.Advisor:
                    return _wimQuotesDataRepository.GetQuoteReportBroker(quoteNumber) == userId;
                default:
                    return false;
            }
        }        

        #endregion

        #region Protected Members

        protected Entities.File RetrieveStoredQuoteReport(int quoteNumber)
        {
            string path = GetReportPersistencePath();
            string fileName = _wimQuotesDataRepository.GetQuoteReportFileName(quoteNumber);

            if (String.IsNullOrWhiteSpace(fileName))
                return null;

            return new Entities.File
            {
                Name = fileName,
                Data = System.IO.File.ReadAllBytes(path + fileName)
            };
        }

        protected string GetReportPersistencePath()
        {
            string path = _settingsLogic.GetApplicationSetting<string>(Constants.AppSettingsKeys.QuotesDocumentPath);

            if (String.IsNullOrWhiteSpace(path))
                return String.Empty;

            if (path.Substring(path.Length - 1, 1) != @"\")
                path += @"\";

            return path;
        }

        #endregion
    }
}
