﻿using System;

using WIMI.Quotes.Common;

namespace WIMI.Quotes.Model.Domain
{
    public class QuoteGenerationLogic : Contracts.IQuoteGenerationLogic
    {
        #region Constructors & DI

        private readonly Contracts.IQuoteItemLogic _quoteItemLogic;
        private readonly Contracts.ISettingsLogic _settingsLogic;
        private readonly Contracts.IQuoteReportLogic _quoteReportLogic;
        private readonly Repositories.Contracts.IWIMQuotesDataRepository _wimQuotesDataRepository;
        private readonly Repositories.Contracts.IWIMQuotesWCFServiceRepository _wimQuotesWcfServiceRepository;
        private readonly Repositories.Contracts.IWIMQuotesApplicationServiceRepository _applicationServiceRepository;

        public QuoteGenerationLogic(
            Contracts.IQuoteItemLogic quoteItemLogic,
            Contracts.ISettingsLogic settingsLogic,
            Contracts.IQuoteReportLogic quoteReportLogic,
            Repositories.Contracts.IWIMQuotesDataRepository wimQuotesDataRepository,
            Repositories.Contracts.IWIMQuotesWCFServiceRepository wimQuotesWcfServiceRepository,
            Repositories.Contracts.IWIMQuotesApplicationServiceRepository applicationServiceRepository)
        {
            _quoteItemLogic = quoteItemLogic;
            _settingsLogic = settingsLogic;
            _quoteReportLogic = quoteReportLogic;
            _wimQuotesDataRepository = wimQuotesDataRepository;
            _wimQuotesWcfServiceRepository = wimQuotesWcfServiceRepository;
            _applicationServiceRepository = applicationServiceRepository;
        }

        #endregion

        #region Commands

        public Entities.QuoteGenerationResult GenerateQuote(Entities.ReportOptions reportOptions, string userId)
        {
            if (reportOptions == null)
                throw new ArgumentNullException("reportOptions", "reportOptions not set");
            if (string.IsNullOrWhiteSpace(userId))
                throw new ArgumentNullException("userId", "userId not set");
            if (reportOptions.QuoteItemId == Guid.Empty)
                throw new NullReferenceException("Quote Item Id not set");

            try
            {
                var quoteItem = _quoteItemLogic.GetQuoteItem(reportOptions.QuoteItemId);

                if (quoteItem == null)
                    return null;
                
                quoteItem.ReportOptions = reportOptions;

                _quoteItemLogic.SaveQuoteItem(quoteItem, userId);

                int quoteNumber;

                switch (quoteItem.Product.Code)
                {
                    case Constants.ProductCodes.GuaranteedSeries:
                        quoteNumber = GenerateGuaranteedQuote(quoteItem);
                        break;
                    case Constants.ProductCodes.GuaranteedSeriesAUL:
                        quoteNumber = GenerateGuaranteedAULQuote(quoteItem);
                        break;
                    default:
                        quoteNumber = GenerateStandardQuote(quoteItem);
                        break;
                }

                if (quoteNumber <= 0)
                    return null;

                var reportFile = _quoteReportLogic.GenerateQuoteReport(quoteNumber, quoteItem.Advisor.Code, quoteItem.Client.ClientNumber);

                if (reportFile == null)
                    return null;

                if (quoteItem.AkmId > 0)
                    _applicationServiceRepository.SaveQuoteDocument(quoteItem.AkmId, reportFile);

                _wimQuotesDataRepository.UpdateQuoteAkmId(quoteNumber, quoteItem.AkmId);
                _wimQuotesDataRepository.UpdateQuoteItemDataDetails(new Entities.QuoteItemDataDetails
                {
                    QuoteItemId = quoteItem.QuoteItemId,
                    Status = Entities.QuoteItemStatus.Complete,
                    QuoteNumber = quoteNumber,
                    ReportFileName = reportFile.Name
                });

                return new Entities.QuoteGenerationResult
                {
                    QuoteNumber = quoteNumber,
                    IsSuccess = true
                };
            }
            catch (Entities.Exceptions.ValidationException valEx)
            {
                return new Entities.QuoteGenerationResult
                {
                    IsSuccess = false,
                    Message = valEx.Message
                };
            }
            catch (Exception ex)
            {
                throw new Entities.Exceptions.QuoteGenerationException(ex, reportOptions.QuoteItemId);
            }
        }

        #endregion

        #region Protected Members

        protected int GenerateStandardQuote(Entities.QuoteItem quoteItem)
        {
            var investment = Repositories.Mappings.WIMQuotesServiceMappings.ToInvestment(quoteItem);
            investment.VendorId = _settingsLogic.GetApplicationSetting<Guid>(Constants.AppSettingsKeys.QuotesServiceVendorId);

            var result = _wimQuotesWcfServiceRepository.GenerateStandardQuote(investment);

            if (result == null || result.QuoteNumber <= 0)
                return 0;

            return result.QuoteNumber;
        }

        protected int GenerateGuaranteedQuote(Entities.QuoteItem quoteItem)
        {
            var guaranteedSeries = Repositories.Mappings.WIMQuotesServiceMappings.ToGuaranteedSeries(quoteItem);
            guaranteedSeries.VendorId = _settingsLogic.GetApplicationSetting<Guid>(Constants.AppSettingsKeys.QuotesServiceVendorId);

            var result = _wimQuotesWcfServiceRepository.GenerateGuaranteedSeriesQuote(guaranteedSeries);

            if (result == null || result.QuoteNumber <= 0)
                return 0;

            return result.QuoteNumber;
        }

        protected int GenerateGuaranteedAULQuote(Entities.QuoteItem quoteItem)
        {
            var guaranteedSeries = Repositories.Mappings.WIMQuotesServiceMappings.ToGuaranteedSeriesAUL(quoteItem);
            guaranteedSeries.VendorId = _settingsLogic.GetApplicationSetting<Guid>(Constants.AppSettingsKeys.QuotesServiceVendorId);
            
            var result = _wimQuotesWcfServiceRepository.GenerateGuaranteedAULSeriesQuote(guaranteedSeries);

            if (result == null || result.QuoteNumber <= 0)
                return 0;

            return result.QuoteNumber;
        }

        #endregion
    }
}
