﻿using System;
using System.ComponentModel;
using System.Configuration;

namespace WIMI.Quotes.Model.Domain
{
    public class SettingsLogic : Contracts.ISettingsLogic
    {
        public T GetApplicationSetting<T>(string appSettingKey)
        {
            var value = ConfigurationManager.AppSettings[appSettingKey];
            return (T)TypeDescriptor.GetConverter(typeof(T)).ConvertFromInvariantString(value);
        }
    }
}
