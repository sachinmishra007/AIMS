﻿using System;

using WIMI.Quotes.Model.Domain.Contracts;
using WIMI.Quotes.Repositories.Contracts;

namespace WIMI.Quotes.Model.Domain
{
    public class UserLogic : IUserLogic
    {
        #region Constructor

        private readonly IAuthenticationService _authenticationService;

        public UserLogic(IAuthenticationService authenticationRepository)
        {
            _authenticationService = authenticationRepository;
        }

        #endregion
        
        public bool AuthenticateUser(string username, string password)
        {
            if (String.IsNullOrWhiteSpace(username) || String.IsNullOrWhiteSpace(password))
                return false;

            return _authenticationService.AuthenticateUser(username, password) && !String.IsNullOrWhiteSpace(GetUserRole(username));
        }

        public string GetUserRole(string userId)
        {
            return String.IsNullOrWhiteSpace(userId) ? null : _authenticationService.GetUserRole(userId);
        }

        public bool IsValidUser(string userId)
        {
            return !String.IsNullOrWhiteSpace(GetUserRole(userId));
        }
    }
}
