﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMI.Quotes.Model.Domain
{
    public class TaxYearLogic : Contracts.ITaxYearLogic
    {
        #region Contructors & DI

        private readonly Repositories.Contracts.IWIMQuotesDataRepository _wimQuotesDataRepository;

        public TaxYearLogic(Repositories.Contracts.IWIMQuotesDataRepository wimQuotesDataRepository)
        {
            _wimQuotesDataRepository = wimQuotesDataRepository;
        }

        #endregion

        public List<Entities.TaxYears> GetTaxYear()
        {
            return _wimQuotesDataRepository.GetTaxYearData();
        }
    }
}
