﻿using System.Collections.Generic;

using WIMI.Quotes.Model.Domain.Contracts;

namespace WIMI.Quotes.Model.Domain
{
    public class ClientLogic : IClientLogic
    {   
        #region Constructors & DI

        private readonly Repositories.Contracts.IClientMaintenanceRepository _clientMaintenanceRepository;
        private readonly Repositories.Contracts.IWIMQuotesApplicationServiceRepository _wimQuotesApplicationServiceRepository;
        private readonly Repositories.Contracts.IWIMQuotesDataRepository _wimQuotesDataRepository;
        private readonly Repositories.Contracts.IDataWarehouseServiceRepository _dataWarehouseServiceRepository;

        public ClientLogic(
            Repositories.Contracts.IClientMaintenanceRepository clientMaintenanceRepository,
            Repositories.Contracts.IWIMQuotesApplicationServiceRepository wimQuotesApplicationServiceRepository,
            Repositories.Contracts.IWIMQuotesDataRepository wimQuotesDataRepository,
            Repositories.Contracts.IDataWarehouseServiceRepository dataWarehouseServiceRepository)
        {
            _clientMaintenanceRepository = clientMaintenanceRepository;
            _wimQuotesApplicationServiceRepository = wimQuotesApplicationServiceRepository;
            _wimQuotesDataRepository = wimQuotesDataRepository;
            _dataWarehouseServiceRepository = dataWarehouseServiceRepository;
        }

        #endregion

        public IEnumerable<Entities.Client> GetBrokerClients(string brokerCode, string searchTerm)
        {
            return _wimQuotesApplicationServiceRepository.GetClientsByBroker(brokerCode, searchTerm);
        }

        public string CreateClient(Entities.Client client)
        {
            return client.ClientNumber == null ? _clientMaintenanceRepository.CreateClient(client) : _clientMaintenanceRepository.UpdateClient(client);
            }
      
        public decimal GetExistingInvestmentValue(string clientNumber, string brokerCode, string productCode)
        {
            if (string.IsNullOrWhiteSpace(clientNumber) || string.IsNullOrWhiteSpace(brokerCode) || string.IsNullOrWhiteSpace(productCode))
                return 0;

            if (!_wimQuotesDataRepository.CanAdvisorAccessClient(clientNumber, brokerCode))
                return 0;

            return _wimQuotesApplicationServiceRepository.GetLatestInvestmentValue(clientNumber, productCode);
        }

        public Entities.ClientContribution GetClientContributions(string clientNumber, string productCode)
        {
            return _wimQuotesDataRepository.GetClientContribution(clientNumber, productCode);
        }

        public List<Entities.Policy> GetClientPolicies(string clientNumber, string productCode)
        {
            return _dataWarehouseServiceRepository.GetClientPolicy(clientNumber, productCode);
        }

        public List<Entities.Fund> GetClientPolicyFund(string clientNumber, string policyNumber)
        {
            return _dataWarehouseServiceRepository.GetClientPolicyFund(clientNumber, policyNumber);
        }


        public List<Entities.ClientPolicyPhaseInDetails> GetClientPolicyPhaseInDetails(string clientNumber, string policyNumber)
        {
            return _dataWarehouseServiceRepository.GetClientPolicyPhaseInDetails(clientNumber, policyNumber);
        }
    }
}
