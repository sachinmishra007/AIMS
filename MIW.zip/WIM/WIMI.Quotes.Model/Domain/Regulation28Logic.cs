﻿namespace WIMI.Quotes.Model.Domain
{
    public class Regulation28Logic : Contracts.IRegulation28Logic
    {
        #region Constructors & DI

        private readonly Repositories.Contracts.IRegulation28ServiceRepository _regulation28ServiceRepository;
        private readonly Repositories.Contracts.IWIMQuotesDataRepository _wimQuotesDataRepository;

        public Regulation28Logic(
            Repositories.Contracts.IRegulation28ServiceRepository regulation28ServiceRepository,
            Repositories.Contracts.IWIMQuotesDataRepository wimQuotesDataRepository)
        {
            _regulation28ServiceRepository = regulation28ServiceRepository;
            _wimQuotesDataRepository = wimQuotesDataRepository;
        }

        #endregion

        /// <summary>
        /// Returns whether provided Fund List are Compliant or not
        /// </summary>
        public Entities.Regulation28.ComplianceCheckResult CheckCompliant(Entities.Regulation28.ComplianceCheckDetails complianceCheckDetails)
        {
            if (complianceCheckDetails == null || complianceCheckDetails.Funds == null || complianceCheckDetails.Funds.Count == 0)
                return null;

            if (complianceCheckDetails.Type == Entities.Regulation28.InstructionType.Addition)
            {
                complianceCheckDetails.ExistingPortfolioFunds = _wimQuotesDataRepository.GetClientProductPortfolio(complianceCheckDetails.ClientNumber,
                    complianceCheckDetails.ProductCode);
            }

            return _regulation28ServiceRepository.CheckCompliance(complianceCheckDetails);
        }
    }
}
