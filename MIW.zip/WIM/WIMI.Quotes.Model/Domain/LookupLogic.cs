﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMI.Quotes.Entities;

namespace WIMI.Quotes.Model.Domain
{
    public class LookupLogic : Contracts.ILookupLogic
    {
        #region Contructors & DI

        private readonly Repositories.Contracts.IWIMQuotesDataRepository _wimQuotesDataRepository;
        private readonly Repositories.Contracts.ISLAMaintenanceRepository _slaMaintenanceDataRepository;

        public LookupLogic(Repositories.Contracts.IWIMQuotesDataRepository wimQuotesDataRepository, Repositories.Contracts.ISLAMaintenanceRepository slaMaintenanceDataRepository)
        {
            _wimQuotesDataRepository = wimQuotesDataRepository;
            _slaMaintenanceDataRepository = slaMaintenanceDataRepository;
        }


        #endregion

        public List<Entities.LookupItem> Get(string code)
        {
            return _wimQuotesDataRepository.GetLookupData(code);
        }

        public List<Entities.LookupItem> GetFundCategories(string productCode ,string subCode)
        {
            return _slaMaintenanceDataRepository.GetFundRange(productCode , subCode);
        }
    }
}
