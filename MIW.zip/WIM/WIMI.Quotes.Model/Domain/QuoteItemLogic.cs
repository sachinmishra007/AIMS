﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WIMI.Quotes.Model.Domain
{
    public class QuoteItemLogic : Contracts.IQuoteItemLogic
    {
        #region Constructors & DI

        private readonly Contracts.ISettingsLogic _settingsLogic;
        private readonly Repositories.Contracts.IWIMQuotesDataRepository _wimQuotesDataRepository;
        private readonly Repositories.Contracts.IWIMQuotesWCFServiceRepository _wimQuotesWcfServiceRepository;
        private readonly Repositories.Contracts.IWIMQuotesApplicationServiceRepository _wimQuotesApplicationServiceRepository;

        public QuoteItemLogic(
            Contracts.ISettingsLogic settingsLogic,
            Repositories.Contracts.IWIMQuotesDataRepository wimQuotesDataRepository,
            Repositories.Contracts.IWIMQuotesWCFServiceRepository wimQuotesWcfServiceRepository,
            Repositories.Contracts.IWIMQuotesApplicationServiceRepository wimQuotesApplicationServiceRepository)
        {
            _settingsLogic = settingsLogic;
            _wimQuotesDataRepository = wimQuotesDataRepository;
            _wimQuotesWcfServiceRepository = wimQuotesWcfServiceRepository;
            _wimQuotesApplicationServiceRepository = wimQuotesApplicationServiceRepository;
        }

        #endregion

        #region Queries

        public List<Entities.QuoteHistoryItem> GetQuoteHistoryItems(
            string advisorNumber, 
            string clientNumber, 
            Entities.QuoteItemStatus status)
        {
            switch (status)
            {
                case Entities.QuoteItemStatus.Incomplete:
                    return _wimQuotesDataRepository.GetQuoteHistoryItems(advisorNumber, clientNumber, Entities.QuoteItemStatus.Incomplete);
                case Entities.QuoteItemStatus.Complete:
                    var vendorId = _settingsLogic.GetApplicationSetting<Guid>(Common.Constants.AppSettingsKeys.QuotesServiceVendorId);
                    return _wimQuotesWcfServiceRepository.GetCompletedQuotes(advisorNumber, String.Empty, vendorId);
                case Entities.QuoteItemStatus.Historical:
                    return _wimQuotesApplicationServiceRepository.GetHistoricalQuotes(advisorNumber, clientNumber);
                default:
                    return new List<Entities.QuoteHistoryItem>();
            }
        }

        public Entities.QuoteItem GetQuoteItem(Guid quoteItemId)
        {
            return _wimQuotesDataRepository.GetQuoteItem(quoteItemId);
        }

        public Entities.QuoteItem GetQuoteItem(int quoteNumber)
        {
            return _wimQuotesDataRepository.GetQuoteItem(quoteNumber);
        }

        public List<Entities.QuoteItem> GetQuoteItems(Guid quoteGroupId)
        {
            return _wimQuotesDataRepository.GetQuoteItems(quoteGroupId);
        }

        #endregion

        #region Commands

        public Guid SaveQuoteItem(Entities.QuoteItem quoteItem, string userId)
        {
            if (quoteItem == null)
                throw new ArgumentNullException("quoteItem", "quoteItems not set");
            if (string.IsNullOrWhiteSpace(userId))
                throw new ArgumentNullException("userId", "userId not set");

            if (quoteItem.QuoteItemId == Guid.Empty)
                quoteItem.QuoteItemId = Guid.NewGuid();

            _wimQuotesDataRepository.SaveQuoteItem(quoteItem, userId);

            return quoteItem.QuoteItemId;
        }

        public void SaveQuoteGroup(Guid quoteGroupId, Guid quoteItemId)
        {
            _wimQuotesDataRepository.SaveQuoteGroup(quoteGroupId, quoteItemId);
        }

        #endregion

        #region Public Static Methods

        public static List<string> ExtractUniqueFundCodes(Entities.QuoteItem quoteItem)
        {
            if (quoteItem == null || quoteItem.Profiles == null || quoteItem.Profiles.Count == 0)
                return new List<string>();

            var allFundCodes = new List<string>();

            foreach (var profile in quoteItem.Profiles.OfType<Entities.Profiles.IFundsProfile>())
            {
                if (profile.Funds != null && profile.Funds.Count > 0)
                    allFundCodes.AddRange(profile.Funds.Select(f => f.Code));
            }

            return allFundCodes.Distinct().ToList();
        }

        #endregion
    }
}
