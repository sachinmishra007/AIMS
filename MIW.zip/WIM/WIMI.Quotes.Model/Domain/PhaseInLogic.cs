﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WIMI.Quotes.Repositories.Contracts;
using WIMI.Quotes.Model.Domain.Contracts;

namespace WIMI.Quotes.Model.Domain
{
    public class PhaseInLogic:IPhaseInLogic
    {
        #region Constructor

        private readonly IPhaseInRepository _phaseInRepository;

        public PhaseInLogic(IPhaseInRepository phaseInRepository)
        {
            _phaseInRepository = phaseInRepository;
        }

        #endregion
        public DateTime? GetPhaseInFirstDate()
        {
            return _phaseInRepository.GetCommencementDate();
        }
    }
    
}
