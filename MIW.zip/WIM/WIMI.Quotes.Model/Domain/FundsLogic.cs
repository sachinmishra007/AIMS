﻿using System.Collections.Generic;
using System.Linq;

namespace WIMI.Quotes.Model.Domain
{
    public class FundsLogic : Contracts.IFundsLogic
    {
        #region Constructor

        private readonly Repositories.Contracts.IWIMQuotesDataRepository _wimQuotesDataRepository;
        private readonly Repositories.Contracts.IPortfolioPerformanceServiceRepository _portfolioPerformanceServiceRepository;
        private readonly Repositories.Contracts.ISLAMaintenanceRepository _slaServiceRepository;

        public FundsLogic(
            Repositories.Contracts.IWIMQuotesDataRepository wimQuotesDataRepository,
            Repositories.Contracts.IPortfolioPerformanceServiceRepository portfolioPerformanceServiceRepository,
            Repositories.Contracts.ISLAMaintenanceRepository slaServiceRepository)
        {
            _wimQuotesDataRepository = wimQuotesDataRepository;
            _portfolioPerformanceServiceRepository = portfolioPerformanceServiceRepository;
            _slaServiceRepository = slaServiceRepository;
        }

        #endregion

        /// <summary>
        /// Returns List of <see cref="Entities.Fund"/> for the supplied filters
        /// </summary>
        /// <param name="productCode">Product code that the funds are linked to</param>
        /// <param name="fundRangeCode">Type of Fund Range to return funds for</param>
        /// <param name="brokerCode">Broker code to return any white labelled funds for</param>
        /// <returns>List of <see cref="Entities.Fund"/></returns>
        public List<Entities.Fund> GetFundsList(string productCode, string fundRangeCode, string brokerCode)
        {
            return _wimQuotesDataRepository.GetFundsList(productCode, fundRangeCode, brokerCode);
        }

        /// <summary>
        /// Returns a List of Fund Fact Sheet data for the provided <param name="quoteNumber">quote number</param>
        /// </summary>
        /// <param name="quoteNumber">Quote number to return Fund Fact Sheets for</param>
        /// <returns>List of file data bytes</returns>
        public List<Entities.FundFactSheet> GetFundFactSheetsForQuote(int quoteNumber)
        {
            var funds = _wimQuotesDataRepository.GetQuoteConsolidatedFunds(quoteNumber);
            return _portfolioPerformanceServiceRepository.GetFundFactSheetsList(funds);
        }

        public Entities.FundProductRulesResult CheckFundMinimumAmount(Entities.FundMinimumDetails fundMinimumAmountDetails)
        {
            var fundProductRule = fundMinimumAmountDetails.Funds.Select(w => new Entities.FundProductRule
            {
                FundId = w.Code,
                Amount = (decimal)w.Amount,
                ClientNumber = fundMinimumAmountDetails.ClientNumber,
                ProductId = fundMinimumAmountDetails.ProductId,
               // TransactionTypeId = 1
               TransactionTypeId = (int)fundMinimumAmountDetails.Type

            }).ToList();

            var result = _slaServiceRepository.GetFundMinimum(fundProductRule);

            if (result == null)
                return null;

            return new Entities.FundProductRulesResult
            {
                FundProductRules = result,
                IsOverallCompliant = !result.Exists(f => f.IsValid == false)
            };
        }
    }
}
