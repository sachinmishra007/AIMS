﻿namespace WIMI.Quotes.Common
{
    public struct Constants
    {
        public struct Roles
        {
            public const string Administrator = "Admin";
            public const string Advisor = "Advisor";
        }

        public struct ReportFormat
        {
            public const string Pdf = "PDF";
            public const string Excel = "EXCEL";
        }

        public struct MimeTypes
        {
            public const string Pdf = "application/pdf";
        }

        public struct FileNameFormats
        {
            public const string QuoteReportFormat = "Quote_{0}_{1}.pdf";
        }

        public struct StringFormats
        {
            public const string DateFormat = "yyyy-MM-dd";
        }

        public struct Values
        {
            public const int SearchTermMinLength = 3;
        }

        public struct AppSettingsKeys
        {
            public const string QuoteReportPath = "QuoteReportPath";
            public const string QuotesServiceVendorId = "QuotesServiceVendorId";
            public const string QuotesDocumentPath = "QuotesDocumentPath";
            public const string TransferOnlineTransactingUrl = "TransferOnlineTransactingUrl";
            public const string ReturnUrl = "ReturnUrl";
        }

        public struct ProductCodes
        {
            public const string GuaranteedSeries = "GUARDGRO";
            public const string GuaranteedSeriesAUL = "GROWTH";
        }

        public struct References
        {
            public const string QuotesServiceReference = "AIMSQuotesSystem";
        }

        public struct SectionId
        {
            public const string PhaseInSectionId = "PHASEINDET";
        }

        public struct GuaranteeType
        {
            public const string Growth = "GROWTH";
            public const string Income = "INCOME";
        }

        public struct FeeType
        {
            public const string Fee = "AOCM";
        }

    }
}
