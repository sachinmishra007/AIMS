﻿using System.Collections.Generic;

using iTextSharp.text;
using iTextSharp.text.pdf;

namespace WIMI.Quotes.Common.Helpers
{
    public static class PdfHelper
    {
        public static byte[] MergePdfFiles(List<byte[]> pdfFiles)
        {
            if (pdfFiles == null || pdfFiles.Count == 0)
                return new byte[0];

            var document = new Document(new PdfReader(pdfFiles[0]).GetPageSizeWithRotation(1));

            using (var stream = new System.IO.MemoryStream())
            {
                var pdf = new PdfCopy(document, stream);
                pdf.SetMergeFields();

                document.Open();

                foreach (var pdfFile in pdfFiles)
                {
                    pdf.AddDocument(new PdfReader(pdfFile));
                }

                document.Close();

                return stream.ToArray();
            }
        }
    }
}
