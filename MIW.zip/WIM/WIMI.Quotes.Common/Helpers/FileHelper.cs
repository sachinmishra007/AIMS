﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WIMI.Quotes.Common.Helpers
{
    public static class FileHelper
    {
        /// <summary>
        /// Returns supplied file name with any invalid characters for file names stripped out
        /// </summary>
        /// <param name="fileName">File name to sanitise</param>
        /// <returns>Sanitised file name</returns>
        public static string SanitiseFileName(string fileName)
        {
            string invalidChars = System.Text.RegularExpressions.Regex.Escape(new string(System.IO.Path.GetInvalidFileNameChars()));
            string invalidRegStr = string.Format(@"([{0}]*\.+$)|([{0}]+)", invalidChars);

            return System.Text.RegularExpressions.Regex.Replace(fileName, invalidRegStr, "_");
        }
    }
}
