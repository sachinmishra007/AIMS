﻿using System.IO;
using System.Xml.Serialization;

namespace WIMI.Quotes.Common.Extensions
{
    public static class SerializeExtensions
    {
        /// <summary>
        /// Serializes provided object into a string. Object will need to marked as [Serializable]
        /// </summary>
        public static string ToSerializedString(this object serializableObject)
        {
            string serialisedData;
            var xmlSerializer = new XmlSerializer(serializableObject.GetType());

            using (var textWriter = new StringWriter())
            {
                xmlSerializer.Serialize(textWriter, serializableObject);
                serialisedData = textWriter.ToString();
            }

            return serialisedData;
        }

        /// <summary>
        /// Deserialize provided string into an object of type T. Object will need to marked as [Serializable]
        /// </summary>
        public static T ToDeserializedObject<T>(this string serializedString)
        {
            var xmlSerializer = new XmlSerializer(typeof(T));

            using (TextReader reader = new StringReader(serializedString))
            {
                return (T)xmlSerializer.Deserialize(reader);
            }
        }
    }
}
