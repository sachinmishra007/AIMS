﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace WIMI.Quotes.Common.Extensions
{
    public static class VariablesExtensions
    {
        #region String Extensions

        /// <summary>
        /// Returns string value as sentence case i.e. "StringName" as "String Name"
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToSentenceCase(this string value)
        {
            return Regex.Replace(value, "(?!^)([A-Z])", " $1");
        }

        /// <summary>
        /// Converts string to Enum value for where T is Enum
        /// </summary>
        /// <typeparam name="T">T : Enum</typeparam>
        public static T ToEnum<T>(this string value) where T : struct
        {
            return (T)Enum.Parse(typeof(T), value, true);
        }

        /// <summary>
        /// Converts array of strings to Enum values for where T is Enum
        /// </summary>
        /// <typeparam name="T">T : Enum</typeparam>
        public static List<T> ToEnumList<T>(this string[] values) where T : struct
        {
            return values.Select(t => t.ToEnum<T>()).ToList();
        }

        /// <summary>
        /// Converts a string to a Guid, return empty Guid if invalid guid
        /// </summary>
        public static Guid ToGuid(this string value)
        {
            Guid guid;
            return Guid.TryParse(value, out guid) ? guid : Guid.Empty;
        }

        /// <summary>
        /// Converts a string to an integer, return 0 if invalid integer
        /// </summary>
        public static int ToInt(this string value)
        {
            int intValue;
            return int.TryParse(value, out intValue) ? intValue : 0;
        }

        /// <summary>
        /// Converts a string to a nullable date time, returns null if invalid date
        /// </summary>
        public static DateTime? ToDateTimeNullable(this string value)
        {
            DateTime dateTimeValue;
            return DateTime.TryParse(value, out dateTimeValue) ? dateTimeValue : (DateTime?)null;
        }

        /// <summary>
        /// Returns whether any of the supplied strings matches the value
        /// </summary>
        public static bool In(this string value, params string[] comparisonStrings)
        {
            if (string.IsNullOrWhiteSpace(value))
                return false;

            return comparisonStrings.Any(s => value == s);
        }

        #endregion

        #region Enum Extensions

        /// <summary>
        /// Returns Enum value as sentence case i.e. "EnumValue" as "Enum Value"
        /// </summary>
        public static string ToSentenceCase(this Enum value)
        {
            return ToSentenceCase(value.ToString());
        }

        /// <summary>
        /// Returns Description if set by description attribute for Enum
        /// </summary>
        public static string ToDescription(this Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            if (null == fi) 
                return value.ToString();

            object[] attrs = fi.GetCustomAttributes(typeof(DescriptionAttribute), true);

            return attrs.Length > 0 ? ((DescriptionAttribute)attrs[0]).Description : value.ToString();
        }

        #endregion
    }
}
