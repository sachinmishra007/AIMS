﻿using MorningStarWebTool.Common;
using MorningStarWebTool.DataLayer.Class;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace MorningStarWebTool.Api
{    
    [RoutePrefix("api/MorningStarComponent")]    
    public class MorningStarComponentController : ApiController
    {
        private ToolConfig _msConfigTool = null;
        private Util _utilites = null;

        public MorningStarComponentController()
        {
            _msConfigTool = new ToolConfig();
            _utilites = new Util();

        }

        [HttpGet]
        [AcceptVerbs("POST", "GET")]
        [ActionName("GetMorningStarLoadingDetails")]
        [Route("GetMorningStarLoadingDetails/{_toolName}")]
        [ResponseType(typeof(string))]
        public async Task<IHttpActionResult> Get(string _toolName)
        {
            try
            {
                 
                var _AuthURL = _utilites.GetMorningStarInformation(); 
                var InstanceId = ConfigurationManager.AppSettings["InstanceId"].ToString();
                var Environment = ConfigurationManager.AppSettings["Environment"].ToString();
                var CustomStyles = ConfigurationManager.AppSettings["CustomStyles"].ToString();
                if (_toolName == ConfigurationManager.AppSettings["FUNDSCREENER"].ToString())
                {
                    var _fundScreenerLoadingDetails = new
                    {
                        AuthUrlTemplate = _AuthURL,
                        InstanceId,
                        Environment,
                        CustomStyles,
                        ConfigurationNamespace = ConfigurationManager.AppSettings["ConfigurationNamespace_FundScreener"].ToString()

                    };
                    return Ok(_fundScreenerLoadingDetails);
                }
                else if (_toolName == ConfigurationManager.AppSettings["XRAY"].ToString())
                {
                    var _fundScreenerXRAYDetails = new
                    {
                        AuthUrlTemplate = _AuthURL,
                        InstanceId,
                        Environment,
                        CustomStyles,
                        ConfigurationNamespace = ConfigurationManager.AppSettings["ConfigurationNamespace_XRAY"].ToString()
                    };
                    return Ok(_fundScreenerXRAYDetails);
                }
                else if (_toolName == ConfigurationManager.AppSettings["FUNDREPORT"].ToString())
                {
                    var _fundReportDetails = new
                    {
                        AuthUrlTemplate = _AuthURL,
                        InstanceId,
                        Environment,
                        CustomStyles,
                        ConfigurationNamespace = ConfigurationManager.AppSettings["ConfigurationNamespace_FundReport"].ToString()

                    };
                    return Ok(_fundReportDetails);
                }
                else
                {
                    var _fundInvalidToolOption = new
                    {
                        Result = "Invalid Tool Option"
                    };
                    return Ok(_fundInvalidToolOption);
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }
    }
}
