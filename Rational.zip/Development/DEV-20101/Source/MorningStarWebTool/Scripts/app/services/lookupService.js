﻿
(function () {
    "use strict";

    angular.module("morningStar.services")
           .factory('lookupService', ['$http', function () {

               var lookupService = {};

               lookupService.getMorningStarMenuItem = function () {
                   return [{
                       visible:true,
                       title: 'Fund Screener Tool',
                       href: 'Entry/FundScreener',
                       target: 'iframe',
                       src: ''
                   }, {
                       visible: false,
                       title: 'Fund Report Tool',
                       href: 'Entry/FundReport',
                       target: 'iframe',
                       src: 'Entry/UserInput'
                   }, {
                       visible: true,
                       title: 'XRay Report Tool',
                       href: 'Entry/ECLoader_XRay',
                       target: 'iframe',
                       src: ''
                       //src: 'Entry/UserXrayReportInput'
                   }];
               };

               return lookupService;


           }]);

})();
