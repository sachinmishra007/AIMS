﻿(function () {

    "use strict";

    angular.module('morningStar.controllers')
       .controller('MorningStarXRayReport', ['$scope', 'MorningStarService', 'ApplicationSetting',
           function ($scope, MorningStarService, ApplicationSetting) {

               $scope.XRayReport = true;
               $scope.showLoading = false;
               $scope.displayUserSearchOption = true;

               $scope.FundSLAMapping;
               $scope.ClientDetails;
               $scope.ClientPolicyDetails;
               $scope.ClientFundPolicyDetails;
               $scope.ClientUserLoggedUser = [];

               //var _clientInfo = [{
               //    CustomerId: '00012345',
               //    CustomerName: 'Albert Parker',
               //    PolicyNumber: 'IA0001245'
               //}, {
               //    CustomerId: '00011774',
               //    CustomerName: 'Deno Marsh',
               //    PolicyNumber: 'IA0001254'
               //}];

               //MorningStarService
               //    .GetClientPrimaryDetails(_clientInfo)
               //    .success(function (_result) {
               //        console.log(_result);
               //    })
               //.error(function (_error) {
               //    console.log(_result);
               //});



               //Default Values for XRay Report
               $scope.XRay = {
                   Portfolio: {
                       formatVersion: 2,
                       ExternalId: '12345',
                       Type: 'WatchlistbyAmount',
                       CurrencyId: 'ZAR',
                       BenchmarkId: 'CAZAF$$ASI_4123',
                       Name: 'Sample Portfolio Name',
                       Holding: []
                   }
               };


               $scope.GetClientDetails = function (ClientParam, BrokerCode) {
                   /*
    
                   //get Mapping Fund Star 
                   $scope.showLoading = true;
                   MorningStarService
                       .GetMornigStarFundMapping()
                       .success(function (data) {
                           $scope.FundSLAMapping = JSON.parse(data);
                           $scope.holding = $scope.FundSLAMapping[0];
                           $scope.showLoading = false;
                       })
                       .error(function (error) {
                           console.log(error);
                       });
    
                    */

                   //Get Client Details of the provided broker code                   
                   MorningStarService
                      .GetClientDetails(ClientParam, BrokerCode)
                      .success(function (data) {
                          $scope.ClientDetails = JSON.parse(data);
                          //console.log($scope.ClientDetails);                          
                      })
                      .error(function (error) {
                          console.log(error);
                      });
               };

               //Adding SLA Fund Information
               $scope.AddFundInformation = function (fundInfo) {
                   $scope.XRay.Portfolio.Holding.push({
                       Type: 'MSID',
                       Value: fundInfo.FundShareClassId,
                       Weight: fundInfo.Weight,
                       FundName: fundInfo.FundName
                   });
                   //$scope.GetFundHolding($scope.XRay.Portfolio.Holding);
                   $scope.GetTotalFund($scope.XRay.Portfolio.Holding);
                   $scope.holding = {};
               };

               //Creating dynamic Holdings based upon Policy Number
               $scope.GetFundHolding = function (HoldingInformation) {
                   if (HoldingInformation != undefined) {
                       var HoldingInfo = '<Holdings>\n';
                       for (var intCount = 0; intCount < HoldingInformation.length; intCount++) {
                           HoldingInfo += "<Holding><Identifier type=\"" + HoldingInformation[intCount].Type + "\">" + HoldingInformation[intCount].Value
                           + "</Identifier><Amount>" + HoldingInformation[intCount].Amount + "</Amount></Holding>";
                       }
                       HoldingInfo += '</Holdings>';
                       console.log(HoldingInfo);
                       return HoldingInfo;
                   } else {
                       return null;
                   }
               };



               //Clear the Obtained Records.
               $scope.Clear = function () {
                   $scope.XRay.Portfolio.Holding = [];
                   $scope.holding = {};
                   $scope.ClientPolicyDetails = [];
                   $scope.XRay.ClientDetail = undefined;
                   $scope.XRayReport = true;
                   $scope.XRay.ClientDetails.Info = '';
                   $scope.ClientDetails = [];
                   $scope.displayUserSearchOption = true;
               }


               $scope.XMLPreviewClose = function () {

               };

               $scope.View = function () {
                   $('#XMLPreview').modal('show');
               }

               $scope.removeRow = function (index) {
                   $scope.XRay.Portfolio.Holding.splice(index, 1);
               }

               //Calculation if fund total gets greater than 100
               $scope.GetTotalFund = function (HoldingInformation) {
                   var HoldingSum = 0;
                   for (var intCount = 0; intCount < HoldingInformation.length; intCount++) {
                       HoldingSum += parseFloat(HoldingInformation[intCount].Weight);
                   }
                   return HoldingSum;
               };

               //get Clien Policy Details
               $scope.GetClientPolicyDetails = function (ClientDetails) {
                   $scope.showLoading = $scope.XRayReport = true;
                   MorningStarService
                        .GetClientPolicyDetails(ClientDetails.ClientNumber)
                        .success(function (data) {
                            $scope.ClientPolicyDetails = JSON.parse(data);
                            $scope.showLoading = false;
                        })
                        .error(function (error) {
                            console.log(error);
                        });
               }

               $scope.getClientInformation = function (ev, ClientDetails) {
                   if (ClientDetails != undefined) {
                       if (ClientDetails.length >= ApplicationSetting.InputSearchUpto) {
                           if ($scope.ClientUserLoggedUser.length > 0) {

                               //Looking for Broker Code in Session API Array at Position Value 1                               
                               $scope.GetClientDetails(ClientDetails, $scope.ClientUserLoggedUser[1].Value);
                               $scope.displayUserSearchOption = true;
                           }

                       }
                       else {
                           $scope.ClientDetails = {};
                           $scope.displayUserSearchOption = true;
                       }
                   }

               }

               //get Client Fund Policy Detail Information
               $scope.GetClientFundPolicyDetails = function (ClientDetails, ClientPolicyDetail) {
                   $scope.showLoading = true;
                   MorningStarService
                        .GetClientFundPolicyDetails(ClientDetails.ClientNumber, ClientPolicyDetail.policynumber)
                        .success(function (data) {
                            $scope.ClientFundPolicyDetails = JSON.parse(data);
                            $scope.showLoading = false;
                            $scope.XRayReport = false;
                        })
                        .error(function (error) {
                            console.log(error);
                        });
               }



               $scope.setClientInformation = function (clientInfo) {
                   $scope.XRay.ClientDetails = clientInfo;
                   $scope.XRay.ClientDetails.Info = clientInfo.ClientFullName + " - " + clientInfo.ClientNumber;
                   $scope.displayUserSearchOption = false;
                   $scope.GetClientPolicyDetails(clientInfo);
               };

               $scope.getDynamicPotfolioInformation = function (__requiredParam, ClientFundPolicyDetails) {
                   if (ClientFundPolicyDetails != undefined) {
                       if (__requiredParam == 'DYJSON') {
                           var Holdings = [];
                           for (var intCount = 0; intCount < ClientFundPolicyDetails.length; intCount++) {
                               Holdings.push({
                                   'identifier': ClientFundPolicyDetails[intCount].Value,
                                   'identifierType': ClientFundPolicyDetails[intCount].Type.toLowerCase(),
                                   'amount': ClientFundPolicyDetails[intCount].Amount
                               });
                           }
                           return Holdings;
                       }
                       else if (__requiredParam == "ATSUM") {
                           var HoldingSum = 0;
                           for (var intCount = 0; intCount < ClientFundPolicyDetails.length; intCount++) {
                               HoldingSum += parseFloat(ClientFundPolicyDetails[intCount].Amount);
                           }
                           return HoldingSum;
                       }
                   }
               }

               $scope.GetXRayPortfolioFundInformation = function (ClientDetails, PortfolioNumber) {
                   $scope.showLoading = true;
                   MorningStarService
                        .GetClientFundPolicyDetails(ClientDetails.ClientNumber, PortfolioNumber.policynumber)
                        .success(function (data) {
                            $scope.ClientFundPolicyDetails = JSON.parse(data);
                            if ($scope.ClientFundPolicyDetails.length <= 0) {
                                $scope.View();
                            }
                            else {
                                var portfolio = {
                                    name: PortfolioNumber.policynumber,
                                    totalAmount: $scope.getDynamicPotfolioInformation("ATSUM", $scope.ClientFundPolicyDetails),
                                    currencyId: 'ZAR',
                                    holdings: $scope.getDynamicPotfolioInformation("DYJSON", $scope.ClientFundPolicyDetails),
                                    benchmark: {
                                        holdings: {
                                            identifier: 'CAZAF$$ASI_4123',
                                            identifierType: 'msid',
                                            Amount: 100
                                        }
                                    }
                                };
                                window.localStorage.setItem('portfolio', JSON.stringify(portfolio));
                            }
                            $scope.showLoading = false;
                            $scope.XRayReport = false;
                        })
                        .error(function (error) {
                            console.log(error);
                        });
               };

               $scope.Init = function () {
                   MorningStarService
                       .GetBrokerCodeFromSession()
                       .success(function (_result) {
                           $scope.ClientUserLoggedUser = _result;
                       })
                       .error(function (_error) {
                           console.log(_error);
                       });
               }

               $scope.Init();

           }]);


})();