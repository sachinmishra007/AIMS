(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else {
		var a = factory();
		for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];
	}
})(this, function() {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(1)], __WEBPACK_AMD_DEFINE_RESULT__ = function(loader) {
	    'use strict';
	    if (!window.morningstar) {
	        window.morningstar = {};
	    }
	    window.morningstar.loader = loader;
	    return morningstar.loader;
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(2), __webpack_require__(3), __webpack_require__(5), __webpack_require__(6), __webpack_require__(7), __webpack_require__(4)], __WEBPACK_AMD_DEFINE_RESULT__ = function(ajax, FileLoader, bundles, configurations, iframeManager, log) {
	    'use strict';
	
	    var morningstarNgApp = 'MorningstarApp',
	        loadedFiles = {},
	        _initObj,
	        _iframeComponents;
	    /**
	     * @initObj 
	     * @For example:
	     * {
	     *      appConfig: {
	     *          settings: {},
	     *          components: {
	     *              ecXray: {
	     *                   type: 'ecXray',
	     *                   version: '1.0.0',
	     *                   settings: {}
	     *              },
	     *              marketsHeatmap: {
	     *                   type: 'marketsComponentsHeatmap',
	     *                   version: '2.9.0',
	     *                   settings: {}
	     *              }
	     *          },
	     *          labels: {}
	     *      },
	     *      instid:'PATS',
	     *      apiTokens: {
	     *          marketsAPIToken: 'XXXXXXXXXXXXXXXXXXXXX'
	     *      },
	     *      angularOptions: {
	     *          bootstrap: false,
	     *          bootstrapElement: $('.angular_app_element')    
	     *      },
	     *      environment: 'prod' //qa, uat or prod,
	     *      bundles:{'ecXray':['//xxx.example.com/path/bundle.js','//xxx.example.com/path/bundle.css']},
	     *      customStyles: ['//xxx.example.com/path/overwrites-style.css']
	     * }
	     */
	
	    function load(initObj, callback) {
	        initObj.angularOptions = initObj.angularOptions || {};
	        initObj.environment = initObj.environment || 'prod';
	        callback = typeof callback === 'function' ? callback : function() {};
	        var loaderComponents = getComponentsToLoad(initObj.appConfig.components, initObj.iframeEnabled)
	        initObj.appConfig.components = loaderComponents.components;
	        _iframeComponents = loaderComponents.iframeComponents
	        _initObj = initObj;
	        
	        if(!initObj.configurationNamespace) {
	            log.warn('No configuration namespace provided');
	        }
	
	        if(initObj.configurationURL && !isURL(initObj.configurationURL)){
	            log.error('Configuration URL is not in the correct format');
	        }
	
	        initObj.configurationURL = isURL(initObj.configurationURL) ? initObj.configurationURL : configurations.getConfigurationURL(initObj.environment, initObj.configurationNamespace, initObj.instid);
	
	        if(initObj.configurationURL){
	            getConfiguration(initObj, function(initObj) {
	                getComponents(initObj, callback);
	            });
	        }else{
	            getComponents(initObj, callback);
	        }
	    }
	
	    /* get configuration from remote and linear merge with an exsisting configuraiton object */
	    function getConfiguration(initObj, callback) {
	        ajax({
	            type: 'get',
	            dataType: 'json',
	            url: initObj.configurationURL,
	            success: function(configuration) {
	                initObj.appConfig = merge(initObj.appConfig, configuration); 
	                callback(initObj);
	            },
	            error: function() {
	                log.warn('Can not read configuration');
	                //continue to excute the callback to check if the override bundles could be found.
	                callback(initObj, callback);
	            }
	        });
	    }
	
	    /*
	    get all components bundles related info from EC-bundles
	    use the data to implement the version like *, ~1.0.0 and ^1.0.0
	    use the DEFAULT version if the passed instid don't have special bundles 
	    */
	    function getComponents(initObj, callback) {
	        ajax({
	            type: 'get',
	            dataType: 'json',
	            url: bundles.getBasePath(initObj.environment) + "/components.json",
	            success: function(components) {
	                initObj._components = components;
	                cb(initObj, callback);
	            },
	            error: function() {
	                log.warn('Can not read the component.json file');
	                //continue to excute the callback to check if the override bundles could be found.
	                cb(initObj, callback);
	            }
	        });
	    }
	
	    function getComponentsToLoad(components, iframeEnabled) {
	        var loaderComponents = {
	            components: {},
	            iframeComponents: {}
	        };
	        if(iframeEnabled && iframeEnabled.length > 0) {
	            for(var componentName in components || {}) {
	                var component = components[componentName];
	                if(iframeEnabled.indexOf(componentName) > -1) {
	                    loaderComponents.iframeComponents[componentName] = component;
	                } else {
	                    loaderComponents.components[componentName] = component;
	                }
	            }
	        }
	        else {
	            loaderComponents.components = components;   
	        }
	        return loaderComponents;
	    }
	
	    function initComponent(component, componentSettings) {
	        if(_iframeComponents[component]) {
	            iframeManager.create(component, componentSettings, _initObj, _iframeComponents[component]);
	        }
	        else if (_initObj.appConfig.components[component]) {
	            morningstar.initComponent(component, componentSettings);
	        }
	        else {
	            log.error('Component: %s not found in the initObj.appConfig.components', component);
	        }
	    }
	
	    function cb(initObj, callback) {
	        initObj.dependencies = getBowerDependencies(initObj);
	        initObj._components = initObj._components || {};
	
	        //todo: replace to use SFS once it is ready
	        // loadWithSFS({
	        //     dependencies: dependencies
	        // }, function() {
	        //     loadSuccess(initObj.appConfig, callback);
	        // });
	
	        loadWithSelfCDN({
	            instid: initObj.instid,
	            components: initObj._components,
	            dependencies: initObj.dependencies,
	            bundleFiles: initObj.bundles || {},
	            env: initObj.environment
	        }, function() {
	            loadSuccess(initObj, callback);
	        });
	    }
	
	    function loadSuccess(initObj, callback) {
	        if(Object.keys(initObj.appConfig.components).length === 0) {
	            //Usecase when no components to load on the main container but all components must be loaded inside own iframe
	            if (typeof callback === 'function') {
	                callback(_initObj.appConfig);
	            }
	            return;
	        }
	        var bootstrap = initObj.angularOptions.bootstrap === false ? false : true;
	        var angular = window.angular;
	        if (angular && !bootstrap) {
	            var ngModules = getAngularModuleDependencies(initObj.dependencies);
	            if (ngModules.length > 0) {
	                angular.module(morningstarNgApp, ngModules);
	            }
	        }
	        loadCustomStyles(initObj);
	        setAPITokens(initObj);
	        morningstar.asterix.bootstrap.init({
	            appConfig: initObj.appConfig,
	            angularOptions: {
	                bootstrap: false
	            },
	            configOptions: {
	                instid: initObj.instid,
	                env: initObj.environment === 'prod' ? 'production' : initObj.environment
	            }
	        });
	
	        if (typeof callback === 'function') {
	            callback(_initObj.appConfig);
	        }
	
	        if (angular && bootstrap && morningstar.asterix.ng) {
	            angular.element(document).ready(function() {
	                var bootstrapElement = initObj.angularOptions.hasOwnProperty('bootstrapElement') && initObj.angularOptions.bootstrapElement 
	                                            ? initObj.angularOptions.bootstrapElement : document;
	                angular.bootstrap(bootstrapElement, morningstar.asterix.ng.getAngularModuleDependencies());
	            });
	        }
	    }
	
	    function getBowerDependencies(initObj) {
	        var appConfig = initObj.appConfig || {},
	            angularOptions = initObj.angularOptions,
	            validComponents = initObj._components,
	            instid = initObj.instid,
	            appComponents = appConfig.components || {},
	            dependencies = {};
	        for (var id in appComponents) {
	            var instanceConfig = appComponents[id],
	                component = camelToDashes(instanceConfig.type),
	                version = getVersion(instanceConfig.version, component, validComponents, instid);
	            if (component) {
	                if (!window.angular && !dependencies['angular'] && isECComponents(component)) {
	                    dependencies['angular'] = { version: angularOptions.version || '1.5.5' };
	                }
	                dependencies[component] = version;
	            }
	        }
	        return dependencies;
	    }
	
	    function getAngularModuleDependencies(components) {
	        var modules = [];
	        for (var component in components) {
	            if (isECComponents(component)) {
	                modules.push(dashesToCamel(component));
	            }
	        }
	        return modules;
	    }
	
	    //merge obj2 attributes with obj1
	    function merge(obj1, obj2) {
	        for (var attrname in obj2) { obj1[attrname] = obj2[attrname]; }
	        return obj1;
	    }
	
	    //check if a string is expressed as an URL (the protocol is mandatory)
	    function isURL(url) {
	        if(!url) {
	            return false;
	        }
	        var expression = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi;
	        var regex = new RegExp(expression);
	        return url.match(regex) !== null; 
	    }
	
	    function isECComponents(component) {
	        return /^ec-/.test(component);
	    }
	
	    function dashesToCamel(str) {
	        return str.replace(/-([a-z])/g, function(g) {
	            return g[1].toUpperCase();
	        });
	    }
	
	    function camelToDashes(str) {
	        return str.replace(/([A-Z])/g, "-$1").replace(/^-/, "").toLowerCase();
	    }
	
	    function loadWithSelfCDN(params, callback) {
	        var dependencyList = [],
	            newFileList = [];
	        for (var name in params.dependencies) {
	            var fileList;
	            var bundleFiles = params.bundleFiles[dashesToCamel(name)] || params.bundleFiles[camelToDashes(name)];
	            var version = params.dependencies[name].version;
	            //firstly use override bundles
	            //secondly use the client special bundles
	            //finally use the default version bundles
	            if (bundleFiles && bundleFiles.length) {
	                fileList = bundleFiles;
	            } else if (version) {
	                fileList = bundles.getBundleFiles(params.env, name, version, params.dependencies[name].instid);
	            } else {
	                fileList = [];
	                log.error('Can not find the bundle files for component: %s', name);
	            }
	            //make sure angular is in the first one of the load list
	            if (name === 'angular') {
	                dependencyList.unshift(fileList);
	            } else {
	                dependencyList.push(fileList);
	            }
	        }
	
	        //filter the load list with loaded list
	        for (var i = 0, l = dependencyList.length, fileList; i < l; i++) {
	            fileList = dependencyList[i];
	            for (var j = 0, jl = fileList.length, file; j < jl; j++) {
	                file = fileList[j];
	                if (loadedFiles[file] === true) {
	                    log.info('already loaded %s, skip', file);
	                } else {
	                    newFileList.push(file);
	                }
	            }
	        }
	
	        if (newFileList.length > 0) {
	            var fileLoader = new FileLoader({ fileList: newFileList });
	            fileLoader.load(function(list) {
	                for (var key in list) {
	                    loadedFiles[key] = list[key];
	                }
	                callback();
	            });
	        } else {
	            callback();
	        }
	    }
	
	    function setAPITokens(initObj) {
	        if (morningstar.asterix && morningstar.asterix.context && typeof morningstar.asterix.context.setToken === 'function') {
	            var tokens = initObj.apiTokens || {};
	            for (var tokenKey in tokens) {
	                morningstar.asterix.context.setToken(tokenKey, tokens[tokenKey]);
	            }
	        }
	    }
	
	    /**
	     *  @param avaibaleComponents
	     *  @for example:
	     *  {
	     *      "ec-example": {
	     *          "DEFAULT": [
	     *              "1.0.0"
	     *          ]
	     *      },
	     *      "markets-components-example": {
	     *          "DEFAULT": [
	     *              "1.0.0"
	     *          ]
	     *      },
	     *      "markets-components-heatmap": {
	     *          "DEFAULT": [
	     *              "2.11.0"
	     *          ],
	     *          "PATS": [
	     *              "2.11.0",
	     *              "2.11.1",
	     *              "2.12.0",
	     *              "3.0.0"
	     *          ]
	     *      }
	     *  }  
	     */
	
	    function getVersion(version, component, avaibaleComponents, instid) {
	        var componentVersions = avaibaleComponents[component];
	        if (!componentVersions) {
	            log.warn('Can not find specified component: %s', component);
	            return {};
	        }
	        var avaiableVersions = componentVersions[instid];
	        if (!avaiableVersions) {
	            log.info('Can not find specified component: %s for instid %s. Change to use DEFAULT.', component, instid);
	            instid = 'DEFAULT';
	            avaiableVersions = componentVersions[instid];
	        }
	        var versionObj,
	            temp,
	            ret;
	
	        if (/^~\d+\.\d+\.\d+/.test(version)) {
	            //if version is starting with ~, return the latest patch one.
	            versionObj = version.substring(1).split('\.');
	            ret = getFinalVersion(instid, avaiableVersions, function(v) {
	                temp = v.split('\.');
	                return temp[0] === versionObj[0] && temp[1] === versionObj[1] && temp[2] >= versionObj[2];
	            });
	        } else if (/^\^\d+\.\d+\.\d+/.test(version)) {
	            //if version is starting with ^, return the latest minor one.
	            versionObj = version.substring(1).split('\.');
	            ret = getFinalVersion(instid, avaiableVersions, function(v) {
	                var temp = v.split('\.');
	                return temp[0] === versionObj[0] && temp[1] >= versionObj[1];
	            });
	        } else if (version === '*') {
	            //if version is *, return the latest one.
	            ret = {
	                version: avaiableVersions[avaiableVersions.length - 1],
	                instid: instid
	            };
	        } else {
	            //if version is x.x.x, return the matched one.
	            ret = getFinalVersion(instid, avaiableVersions, function(v) {
	                return v === version;
	            });
	        }
	        if (!ret) {
	            ret = {};
	            log.warn('Can not find specified version %s for component: %s with instid: %s', version, component, instid);
	            log.info('Please use avaiable versions [%s] for component: %s with instid: %s', avaiableVersions.join(','), component, instid);
	        }
	        return ret;
	    }
	
	    function getFinalVersion(instid, avaiableVersions, filterFn) {
	        var validVersions = avaiableVersions.filter(filterFn);
	        if (validVersions.length) {
	            return {
	                version: validVersions[validVersions.length - 1],
	                instid: instid
	            };
	        } else {
	            return null;
	        }
	    }
	
	    //add ability to load client custom overwrite styles
	    function loadCustomStyles(initObj) {
	        var customStyles = initObj.customStyles || [];
	        if (customStyles.length) {
	            new FileLoader({ fileList: customStyles }).load();
	        }
	    }
	
	    /*function loadWithSFS(params, callback) {
	        brower.load({
	            dependencies: params.dependencies
	        }, function() {
	            callback();
	        });
	    }*/
	
	    // for testing to clear loadedFiles
	    function reset() {
	        loadedFiles = {};
	    }
	    return {
	        appName: morningstarNgApp,
	        load: load,
	        initComponent: initComponent,
	        getEnvironment: function() {
	            return _initObj.environment;
	        },
	        getInstid: function() {
	            return _initObj.instid;
	        },
	        getApiTokens: function() {
	            return _initObj.apiTokens;
	        },
	        reset: reset,
	        getInitObjForComponent: function(componentName) {
	            var initObjClone = $.extend(true, {}, _initObj);
	            var component = _iframeComponents[componentName];
	            if(component) {
	                initObjClone.iframeEnabled = [];
	                initObjClone.appConfig.components = {};
	                initObjClone.appConfig.components[componentName] = component;
	            }
	            return initObjClone;
	        }
	    };
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = function() {
	    'use strict';
	
	    function createXMLHttp() {
	        //If XMLHttpRequest is available then using it
	        if (typeof XMLHttpRequest !== undefined) {
	            return new XMLHttpRequest;
	            //if window.ActiveXObject is available than the user is using IE...so we have to create the newest version XMLHttp object
	        } else if (window.ActiveXObject) {
	            var ieXMLHttpVersions = ['MSXML2.XMLHttp.5.0', 'MSXML2.XMLHttp.4.0', 'MSXML2.XMLHttp.3.0', 'MSXML2.XMLHttp', 'Microsoft.XMLHttp'],
	                xmlHttp;
	            //In this array we are starting from the first element (newest version) and trying to create it. If there is an
	            //exception thrown we are handling it (and doing nothing ^^)
	            for (var i = 0; i < ieXMLHttpVersions.length; i++) {
	                try {
	                    xmlHttp = new ActiveXObject(ieXMLHttpVersions[i]);
	                    return xmlHttp;
	                } catch (e) {}
	            }
	        }
	    }
	
	    function ajax(options) {
	        var success = options.success || function() {},
	            error = options.error || function() {},
	            xmlHttp = createXMLHttp(),
	            options = options || {};
	
	        xmlHttp.open(options.type.toLowerCase(), options.url, true);
	        xmlHttp.send(null);
	        xmlHttp.onreadystatechange = function() {
	            if (xmlHttp.readyState === 4) {
	                if (xmlHttp.status === 200) {
	                    var response = xmlHttp.responseText;
	                    if (typeof response === 'string' && options.dataType.toLowerCase() === 'json') {
	                        response = JSON.parse(response);
	                    }
	                    success(response);
	                } else {
	                    error();
	                }
	            }
	        };
	    }
	
	    return ajax;
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__))

/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(4)], __WEBPACK_AMD_DEFINE_RESULT__ = function(log) {
	    'use strict';
	    var FileLoader = function(cfg) {
	        cfg = cfg || {};
	        this.fileList = cfg.fileList || [];
	        this.loadedJS = {};
	        this.loadedCSS = {};
	        this.jsList = [];
	        this.cssList = [];
	        this.callback = null;
	        this.jsReadyStatus = 0;
	        this.ready = false;
	        this.init();
	    };
	    FileLoader.prototype = {
	        init: function() {
	            //split the fileList to JSList and CSSList
	            var fileSize = this.fileList.length;
	            for (var i = 0; i < fileSize; i++) {
	                var url = this.fileList[i];
	                if (url.lastIndexOf('.js') === url.length - 3) {
	                    this.jsList.push(url);
	                } else if (url.lastIndexOf('.css') === url.length - 4) {
	                    this.cssList.push(url);
	                }
	            }
	
	        },
	        load: function(callback) {
	            this.callback = callback;
	            if (this.ready) {
	                this._executeLoadedCallback();
	            } else {
	                this.jsReadyStatus = 0;
	                this._load('CSS');
	                this._load('JS');
	            }
	        },
	        loadCSS: function(url, callback) {
	            var self = this;
	            var fileRef = document.createElement("link");
	            fileRef.setAttribute("rel", "stylesheet");
	            fileRef.setAttribute("type", "text/css");
	            fileRef.setAttribute("href", url);
	            if (typeof callback == 'function') {
	                fileRef.onload = fileRef.onreadystatechange = function() {
	                    if (!this.readyState //FF did not caontains readyState
	                        || this.readyState === 'loaded' || this.readyState === 'complete') {
	                        self._updateStatus(url, 'CSS');
	                        callback();
	                    }
	                };
	                fileRef.onerror = function() {
	                    log.debug('can not find the bundle js file: %s', url);
	                    document.getElementsByTagName("head")[0].removeChild(fileRef);
	                    self._updateStatus(url, 'CSS', false);
	                    callback();
	                };
	            }
	            document.getElementsByTagName("head")[0].appendChild(fileRef);
	        },
	        loadJS: function(url, callback) {
	            var self = this;
	            var fileRef = document.createElement('script');
	            fileRef.setAttribute("type", "text/javascript");
	            fileRef.setAttribute("src", url);
	            if (typeof callback === 'function') {
	                fileRef.onload = fileRef.onreadystatechange = function() {
	                    if (!this.readyState //FF did not caontains readyState
	                        || this.readyState == 'loaded' || this.readyState == 'complete') {
	                        self._updateStatus(url);
	                        callback();
	                    }
	                };
	                fileRef.onerror = function() {
	                    log.debug('can not find the bundle js file: %s', url);
	                    document.getElementsByTagName("head")[0].removeChild(fileRef);
	                    self._updateStatus(url, 'JS', false);
	                    callback();
	                };
	            }
	            document.getElementsByTagName("head")[0].appendChild(fileRef);
	        },
	        getLoadedFileList: function() {
	            return {
	                js: this.loadedJS,
	                css: this.loadedCSS
	            };
	        },
	        _executeLoadedCallback: function() {
	            this.ready = true;
	            if (typeof this.callback === 'function') {
	                var list = {};
	                for (var key in this.loadedJS) {
	                    list[key] = this.loadedJS[key];
	                }
	                for (var key in this.loadedCSS) {
	                    list[key] = this.loadedCSS[key];
	                }
	                this.callback(list);
	            }
	        },
	        _load: function(type, iteration) {
	            var self = this;
	            var items = [],
	                callFun = null;
	            if (type === 'JS') {
	                items = this.jsList;
	                callFun = function() {
	                    self.loadJS(items[iteration], function() {
	                        self._load(type, iteration + 1);
	                    })
	                }
	            } else if (type === 'CSS') {
	                items = this.cssList;
	                callFun = function() {
	                    self.loadCSS(items[iteration], function() {
	                        self._load(type, iteration + 1);
	                    });
	                }
	            }
	            if (!iteration) iteration = 0;
	            if (items[iteration] && typeof callFun === 'function') {
	                callFun();
	            }
	        },
	        _updateStatus: function(url, fileType, success) {
	            success = success === false ? false : true;
	            if (fileType == 'CSS') {
	                this.loadedCSS[url] = success;
	            } else {
	                this.loadedJS[url] = success;
	                this.jsReadyStatus += 1;
	                if (this.jsReadyStatus === this.jsList.length) {
	                    this.ready = true;
	                    this._executeLoadedCallback();
	                }
	            }
	        }
	    };
	
	    return FileLoader;
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function() {
	    'use strict';
	
	    var hasConsole = !!console;
	
	    return {
	        debug: hasConsole ? debug : function() {},
	        info: hasConsole ? info : function() {},
	        error: hasConsole ? error : function() {},
	        warn: hasConsole ? warn : function() {}
	    };
	
	    function debug() {
	        console.debug.apply(console, arguments);
	    }
	
	    function info() {
	        console.info.apply(console, arguments);
	    }
	
	    function error() {
	        console.error.apply(console, arguments);
	    }
	
	    function warn() {
	        console.warn.apply(console, arguments);
	    }
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function() {
	    'use strict';
	    var basePaths = {
	        "dev": "//localhost:1111/components",
	        "qa": "//qsstage.morningstar.com/components",
	        'uat': "//qsstage.morningstar.com/components",
	        "stage": "//qsstage.morningstar.com/components",
	        'prod': "//quotespeed.morningstar.com/components"
	    };
	
	    function getBundleFiles(env, component, version, instid) {
	        //todo: remove the instid, Hoever, we need a solution to solve the client special styles and dom
	        if (component === 'angular') {
	            return ['//ajax.googleapis.com/ajax/libs/angularjs/1.5.5/angular.min.js'];
	        }
	        var basePath = getBasePath(env),
	            filename = [basePath, component, version, instid, component].join('/');
	        return [filename + '-bundle.js', filename + '-bundle.css'];
	    }
	
	    function getBasePath(env) {
	        return basePaths[env] || basePaths['prod'];
	    }
	
	    function getLibraryBasePath(env) {
	        return getBasePath(env).replace('components', 'lib');
	    }
	
	    return {
	        getBasePath: getBasePath,
	        getBundleFiles: getBundleFiles,
	        getLibraryBasePath: getLibraryBasePath
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__))

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function() {
	    'use strict';
	    var protocol = 'http',
	        basePaths = {
	            'dev': '//localhost',
	            'qa': '//qsstage.morningstar.com',
	            'uat': '//qsstage.morningstar.com',
	            'stage': '//qsstage.morningstar.com',
	            'prod': '//quotespeed.morningstar.com'
	        },
	        endpoint = 'config.json',
	        resource = 'components/configurations';
	
	    function getConfigurationURL(env, configuration, instid) {
	        if (!configuration) {
	            return null;
	        }
	
	        configuration = configuration.replace(new RegExp('\\.', 'g'), '/');
	
	        var basePath = getBasePath(env),
	            URI = [
	                [basePath, resource, configuration].join('/'), endpoint
	            ].join('/');
	        return URI;
	    }
	
	    function getBasePath(env) {
	        return basePaths[env] || basePaths['prod'];
	    }
	
	    return {
	        getBasePath: getBasePath,
	        getConfigurationURL: getConfigurationURL
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__))

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(8), __webpack_require__(5), __webpack_require__(9)], __WEBPACK_AMD_DEFINE_RESULT__ = function(util, bundles, iframeHtml) {
	    'use strict';
	    var id_prefix = 'MORNINGSTAR_LOADER_IFRAME_';
	
	    function create(morningstarComponentId, componentSettings, initObj, component) {
	        var iframeId = getIframeId(morningstarComponentId);
	        var iframe = document.createElement('iframe'),
	            w = util.width(componentSettings.container) || 600,
	            h = util.height(componentSettings.container) || 400;
	        iframe.setAttribute("frameborder", "0", 0);
	        //iframe.setAttribute("scrolling", "no", 0);
	        iframe.width = w;
	        iframe.height = h;
	        iframe.id = iframeId;
	        componentSettings.container.appendChild(iframe);
	        iframe.contentWindow.document.open();
	        iframe.contentWindow.document.write(getIframeHtmlText(iframeHtml, initObj, iframeId, morningstarComponentId, componentSettings, component));
	        iframe.contentWindow.document.close();     
	    }
	
	    function getIframeId(id) {
	        return id_prefix + (id ? id : util.IdSeedProducer.getId());
	    }
	
	    function getIframeHtmlText(iframeHtml, initObj, iframeId, morningstarComponentId, componentSettings, component) {
	        var iframeHtmlText = iframeHtml.replace('{{IFRAME_ID}}', iframeId)
	        iframeHtmlText = iframeHtmlText.replace('{{INSTANCE_ID}}', morningstarComponentId);
	        iframeHtmlText = iframeHtmlText.replace('{{TITLE}}', morningstarComponentId);
	        iframeHtmlText = iframeHtmlText.replace('{{LIB_BASE_PATH}}', bundles.getLibraryBasePath(initObj.environment));
	        var languageIdForComponent = getLanguageId(initObj.appConfig, component);
	        if(languageIdForComponent) {
	            iframeHtmlText = iframeHtmlText.replace('{{POLYFILL_FEATURE}}', '?features=Intl.~locale.' + languageIdForComponent);  
	        }
	        if(componentSettings.iframeResources) {
	            if(componentSettings.iframeResources.inlineHtml) {
	                iframeHtmlText = iframeHtmlText.replace('{{HTML_TEMPLATE}}', componentSettings.iframeResources.inlineHtml);  
	            } else {
	                iframeHtmlText = iframeHtmlText.replace('{{HTML_TEMPLATE}}', '');  
	            }
	            if(componentSettings.iframeResources.componentConainer) {
	                iframeHtmlText = iframeHtmlText.replace('{{COMPONENT_CONTAINER}}', componentSettings.iframeResources.componentConainer);  
	            } else {
	                iframeHtmlText = iframeHtmlText.replace('{{COMPONENT_CONTAINER}}', '#component-container');
	            }
	            if(componentSettings.iframeResources.customStyles && componentSettings.iframeResources.customStyles.length > 0) { 
	                var styleIncludeTemplate = '<link rel="stylesheet" type="text/css" href="#SRC#">'
	                var styleIncludeTags = '';
	                componentSettings.iframeResources.customStyles.forEach(function(styleIncludeSrc) {
	                    styleIncludeTags += styleIncludeTemplate.replace('#SRC#', styleIncludeSrc);
	                }); 
	                if(styleIncludeTags) {
	                    iframeHtmlText = iframeHtmlText.replace('{{STYLE_INCLUDE_TAGS}}', styleIncludeTags);
	                }
	           }
	
	           if(componentSettings.iframeResources.customJavascript && componentSettings.iframeResources.customJavascript.length > 0) { 
	                var scriptIncludeTemplate = '<script src="#SRC#"></script>'
	                var scriptIncludeTags = '';
	                componentSettings.iframeResources.customJavascript.forEach(function(scriptIncludeSrc) {
	                    scriptIncludeTags += scriptIncludeTemplate.replace('#SRC#', scriptIncludeSrc);
	                }); 
	                if(scriptIncludeTags) {
	                    iframeHtmlText = iframeHtmlText.replace('{{SCRIPT_INCLUDE_TAGS}}', scriptIncludeTags);
	                }
	           }
	        } else {
	            iframeHtmlText = iframeHtmlText.replace('{{HTML_TEMPLATE}}', '');
	            iframeHtmlText = iframeHtmlText.replace('{{STYLE_INCLUDE_TAGS}}', '');
	            iframeHtmlText = iframeHtmlText.replace('{{SCRIPT_INCLUDE_TAGS}}', '');
	            iframeHtmlText = iframeHtmlText.replace('{{COMPONENT_CONTAINER}}', '#component-container');
	        }
	        return iframeHtmlText;
	    }
	
	    function getLanguageId(appConfig, component) {
	        var languageId;
	        if(component && component.settings && component.settings.languageId) {
	            languageId = component.settings.languageId;
	        }
	        if(!languageId && appConfig && appConfig.settings && appConfig.settings.languageId) {
	            languageId = appConfig.settings.languageId;
	        }
	        if(!languageId && morningstar.asterix.config.getBaseSettings().languageId) {
	            languageId = morningstar.asterix.config.getBaseSettings().languageId;
	        }
	        if(!languageId) {
	            languageId = 'en-US'
	        }
	        return languageId;
	    }
	
	    return {
	        create: create
	    }
	}.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;!(__WEBPACK_AMD_DEFINE_RESULT__ = function(observe) {
	    'use strict';
	    var IdSeedProducer = {
	        id: 0,
	        getId: function() {
	            return this.id++;
	        }
	    };
	
	    function getNameSpaces(scope, namespaces) {
	        if (namespaces.length === 0) {
	            return scope;
	        }
	        return getNameSpaces(scope[namespaces.shift()], namespaces);
	    }
	
	    function getScopeObject(scope, paths) {
	        var _field = paths.pop();
	        var _namespace = getNameSpaces(scope, paths);
	        if (_namespace) {
	            return _namespace[_field];
	        }
	        return null;
	    }
	
	    function width(element) {
	        return element.style.width ? parseInt(element.style.width, 10) : element.clientWidth;
	    }
	
	    function height(element) {
	        return element.style.height ? parseInt(element.style.height, 10) : element.clientHeight;
	    }
	
	    return {
	        IdSeedProducer: IdSeedProducer,
	        getScopeObject: getScopeObject,
	        width: width,
	        height: height
	    };
	}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));

/***/ }),
/* 9 */
/***/ (function(module, exports) {

	module.exports = "<!DOCTYPE html>\n<html>\n\n<head>\n    <meta charset=\"UTF-8\">\n    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n    <meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1\">\n    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\">\n    <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"red\">\n    <meta name=\"format-detection\" content=\"telephone=no\">\n    <title>Morningstar Components {{TITLE}}</title>\n    <script src=\"//cdnjs.cloudflare.com/ajax/libs/handlebars.js/4.0.5/handlebars.runtime.min.js\"></script>\n    <script src=\"//cdn.polyfill.io/v2/polyfill.min.js{{POLYFILL_FEATURE}}\"></script>\n    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js\"></script>\n    <script src=\"{{LIB_BASE_PATH}}/morningstar-components-loader.js\"></script>\n</head>\n<body>\n    {{STYLE_INCLUDE_TAGS}}\n    {{HTML_TEMPLATE}}\n    {{SCRIPT_INCLUDE_TAGS}}\n    <script>\n        var iframeId = '{{IFRAME_ID}}';\n        var instanceId = '{{INSTANCE_ID}}';\n        var componentContainerSelector = '{{COMPONENT_CONTAINER}}';\n\n        function getMorningstarLoader() {\n            var parentMorningstar = window.parent.morningstar;\n            if (parentMorningstar && parentMorningstar.loader) {\n                return parentMorningstar.loader;\n            } else {\n                log.error('Inside iframe, parent mstar loader cannot be laoded');\n            }\n        }\n\n        function init(initObj) {\n            morningstar.loader.load(initObj, function() {\n                morningstar.initComponent(instanceId, { container: $(componentContainerSelector)[0]});\n            });\n        }\n\n        $(document).ready(function() {\n            var componentContainer = $(componentContainerSelector)[0];\n            if(!componentContainer) {\n                componentContainer = document.createElement('div');\n                componentContainer.setAttribute(\"id\", 'component-container');\n                document.body.appendChild(componentContainer);\n                componentContainerSelector = '#component-container';\n            }\n            var loader = getMorningstarLoader();\n            if (loader && instanceId) {\n                init(loader.getInitObjForComponent(instanceId));\n            } else {\n                log.error('Inside iframe, parent mstar loader or component instance: %s not found.', instanceId);\n            }\n        });\n    </script>\n</body>\n\n</html>";

/***/ })
/******/ ])
});
;
//# sourceMappingURL=morningstar-components-loader.js.map