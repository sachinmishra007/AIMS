﻿$(document).ready(function () {

    $('#screener-container').ready(function () {

        var toolName = "FUNDSCREENER";
        $.ajax({
            type: 'POST',
            url: 'api/MorningStarComponent/GetMorningStarLoadingDetails/' + toolName,
            dataType: 'json',
            contentType: "application/json",
            success: function (result) {
                var _obtainedResult = result;
                var authUrlTemplate = _obtainedResult.AuthUrlTemplate;
                var authenticateAwsSso = function () {
                    return $.ajax(authUrlTemplate);
                };
                authenticateAwsSso().done(function (jsonData) {
                    var data = JSON.parse(jsonData);
                    if (data.attachment && data.attachment.SessionID) {
                        morningstar.loader.load({
                            instid: _obtainedResult.InstanceId,
                            appConfig: {},
                            apiTokens: {
                                marketsApiToken: data.attachment.SessionID
                            },
                            environment: _obtainedResult.Environment,
                            configurationNamespace: _obtainedResult.ConfigurationNamespace,
                            customStyles: [_obtainedResult.CustomStyles],
                        }, function (appConfig) {
                            var screener = morningstar.initComponent('ecScreener', {
                                container: document.getElementById('screener-container')
                            });

                        });

                    } else {
                        console.log('MarketsApiToken authentication failed');
                    }
                });
            },
            error: function (error) {
                console.log(error)
            }
        });
    });

});
