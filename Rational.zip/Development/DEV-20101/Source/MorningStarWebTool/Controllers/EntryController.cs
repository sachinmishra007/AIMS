﻿using MorningStarWebTool.SessionAPI;
using MorningStarWebTool.DataLayer.Class;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using MorningStarWebTool.Web.ActionFilters;

namespace MorningStarWebTool.Controllers
{
    [RoutePrefix("Entry")]
    [HandleError(ExceptionType = typeof(Exception), View = "Error")]
    public class EntryController : Controller
    {
        private static SessionVariable[] _variables = null;
        private static string ApplicationId = null;
        public EntryController()
        {

        }
        public ActionResult Index(string AppId)
        {
            try
            {
                ApplicationId = AppId;
                string _sessionKey = Request.QueryString["enterprise"];
                var SessionAPI = new SessionAPI.SessionServiceSoapClient();
                _variables = SessionAPI.GetSessionVariables(_sessionKey);
                if (_variables != null && _variables.Length > 0)
                {
                    //Forms Authentication using Username
                    FormsAuthentication.SetAuthCookie(_variables[1].Value, false);
                    return View();
                }
                else
                {
                    return RedirectToAction("UnauthorizedAccess");
                }
            }
            catch (Exception ecx)
            {
                throw ecx;
            }
        }

        [AuthorizeRoles]
        public ActionResult LandingPage()
        {
            return View();
        }

        [AuthorizeRoles]
        public ActionResult FundReport()
        {
            return View();
        }

        [AuthorizeRoles]
        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
            return View();
        }

        [AuthorizeRoles]
        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            return View();
        }

        [AuthorizeRoles]
        public ActionResult call_fundreport()
        {
            return View();
        }

        [AuthorizeRoles]
        public ActionResult call_xrayreport()
        {
            return View();
        }

        [AuthorizeRoles]
        public ActionResult ECLoader_FundScreener()
        {
            return View();
        }

        [AuthorizeRoles]
        public ActionResult ECLoader_XRay()
        {
            return View();
        }

        [AuthorizeRoles]
        public ActionResult FundScreener()
        {
            return View();
        }

        [AuthorizeRoles]
        public ActionResult UserInput()
        {
            return View();
        }

        [AuthorizeRoles]
        public ActionResult UserXrayReportInput()
        {
            return View();
        }

        [HttpGet]
        [AuthorizeRoles]
        [AcceptVerbs(HttpVerbs.Get)]
        public ActionResult GetBrokerCodeFormSession()
        {
            return Json(_variables, JsonRequestBehavior.AllowGet);

        }

        public ActionResult UnauthorizedAccess()
        {
            if (ApplicationId != null || ApplicationId == "AI" || ApplicationId == string.Empty)
            {
                ViewBag.LoginUrl = System.Configuration.ConfigurationManager.AppSettings["AI"].ToString();
            }
            else
            {
                ViewBag.LoginUrl = System.Configuration.ConfigurationManager.AppSettings["EI"].ToString();
            }
            return View();
        }

        [HttpPost]
        public ActionResult UserApplicationClosed()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName, String.Empty)
            {
                Expires = DateTime.Now.AddYears(-1)
            });

            Response.Cookies.Add(new HttpCookie("ASP.NET_SessionId", "")
            {
                Expires = DateTime.Now.AddYears(-1)
            });
            return new EmptyResult();
        }
    }
}