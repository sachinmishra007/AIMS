﻿using MorningStarWebTool.Web.MediaFormatter;
using System.Security.Principal;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.ModelBinding.Binders;

namespace MorningStarWebTool
{
    public static class WebApiConfig
    {
        public class PrincipalApiModelBinder : IModelBinder
        {
            public bool BindModel(System.Web.Http.Controllers.HttpActionContext actionContext, ModelBindingContext bindingContext)
            {
                if (bindingContext.ModelType != typeof(IPrincipal))
                    return false;

                bindingContext.Model = actionContext.ControllerContext.RequestContext.Principal;

                return true;
            }
        }
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services
            config.Services.Insert(typeof(ModelBinderProvider), 0, new SimpleModelBinderProvider(typeof(IPrincipal), new PrincipalApiModelBinder()));

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{action}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //Adding the Custom Media Type Formatter
            config.Formatters.Add(new CustomMediaTypeFormatter());
        }
    }
}
