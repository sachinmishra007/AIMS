﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.IO;
using System.Collections;

namespace XRGAutomationApplication.DataAccessLayer
{
    class ConnectionClass
    {
        public DataSet xrgds = new DataSet();

        public string ConnectionString = null;

        public string ProcessFilePath = @"C:\WIMI-BP-Automation\";

        public OleDbCommand command = null;

        public OleDbDataAdapter adpater = null;

        public OleDbConnection conn = null;

        public ConnectionClass(string lsFilePath)
        {

            // System.Diagnostics.Process.Start(FilePath);



        }

        public void GetPolicyBusinessName()
        {
            ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + ProcessFilePath + "ControlFile.xls" + ";" + "Extended Properties='Excel 8.0;HDR=YES;'";
            if (xrgds.Tables.Contains("dtControlFile"))
            {
                xrgds.Tables.Remove("dtControlFile");
                xrgds.Tables.Add(ReadExcelFile("Control File", ConnectionString, "dtControlFile"));
            }
            else
            {
                xrgds.Tables.Add(ReadExcelFile("Control File", ConnectionString, "dtControlFile"));
            }
        }

        public void LoadExcelFileData(string lsFilePath)
        {
            try
            {
                if (lsFilePath != string.Empty)
                {
                    ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + lsFilePath + ";" + "Extended Properties='Excel 8.0;HDR=YES;'";

                    //ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + lsFilePath + ";Extended Properties=Excel 12.0;";

                    if (xrgds.Tables.Contains("dtListObjects"))
                    {
                        xrgds.Tables.Remove("dtListObjects");
                        xrgds.Tables.Add(ReadExcelFile("List Objects", lsFilePath, "dtListObjects"));
                    }
                    else
                    {
                        xrgds.Tables.Add(ReadExcelFile("List Objects", lsFilePath, "dtListObjects"));
                    }


                    if (xrgds.Tables.Contains("dtSetSequence"))
                    {
                        xrgds.Tables.Remove("dtSetSequence");
                        xrgds.Tables.Add(ReadExcelFile("Set Sequence", lsFilePath, "dtSetSequence"));
                    }
                    else
                    {
                        xrgds.Tables.Add(ReadExcelFile("Set Sequence", lsFilePath, "dtSetSequence"));
                    }

                    if (xrgds.Tables.Contains("dtPreProcessing"))
                    {
                        xrgds.Tables.Remove("dtPreProcessing");
                        xrgds.Tables.Add(ReadExcelFile("PreProcessing", lsFilePath, "dtPreProcessing"));
                    }
                    else
                    {
                        xrgds.Tables.Add(ReadExcelFile("PreProcessing", lsFilePath, "dtPreProcessing"));
                    }
                    
                    //ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + ProcessFilePath + ";" + "Extended Properties='Excel 8.0;HDR=YES;'";
                    //ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ProcessFilePath + "Automation_Process_Flow.xlsx" + ";Extended Properties=Excel 12.0;";
                    //xrgds.Tables.Add(ReadExcelFile("ProcessInfo", ConnectionString, "dtProcessInfo"));
                }
                else
                {
                    ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + ProcessFilePath + "ControlFile.xls" + ";" + "Extended Properties='Excel 8.0;HDR=YES;'";
                    if (xrgds.Tables.Contains("dtControlFile"))
                    {
                        xrgds.Tables.Remove("dtControlFile");
                        xrgds.Tables.Add(ReadExcelFile("Control File", ConnectionString, "dtControlFile"));
                    }
                    else
                    {
                        xrgds.Tables.Add(ReadExcelFile("Control File", ConnectionString, "dtControlFile"));
                    }


                    //ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ProcessFilePath + "ControlFile.xlsx" + ";Extended Properties=Excel 12.0;";
                    ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + ProcessFilePath + "TemplateFile.xls" + ";" + "Extended Properties='Excel 8.0;HDR=YES;'";
                    if (xrgds.Tables.Contains("dtTemplateDefn"))
                    {
                        xrgds.Tables.Remove("dtTemplateDefn");
                        xrgds.Tables.Remove("dtTemplateHdr");
                        xrgds.Tables.Add(ReadExcelFile("Template Defn", ConnectionString, "dtTemplateDefn"));
                        xrgds.Tables.Add(ReadExcelFile("Template Hdr", ConnectionString, "dtTemplateHdr"));
                    }
                    else
                    {
                        xrgds.Tables.Add(ReadExcelFile("Template Defn", ConnectionString, "dtTemplateDefn"));
                        xrgds.Tables.Add(ReadExcelFile("Template Hdr", ConnectionString, "dtTemplateHdr"));
                    }
                    //ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + ProcessFilePath + "TemplateFile.xlsx" + ";Extended Properties=Excel 12.0;";

                }
            }
            catch (Exception ex)
            {
            }
        }

        public string[] GetCommands(string StrValue, char charValue = '|')
        {
            return StrValue.Split(charValue);
        }

        public void SplitFunction(string FieldName, string TableName)
        {

            IEnumerable<DataRow> productsQuery = from product in xrgds.Tables[TableName].AsEnumerable()
                                                 select product;
            IEnumerable<DataRow> largeProducts = productsQuery.Where(p => p.Field<string>(FieldName).Contains("|"));
            foreach (DataRow product in largeProducts)
            {
                // Console.WriteLine(product.Field<string>("Name"));
                string value = product[FieldName].ToString();
                string[] a = GetCommands(value);
            }
        }

        public DataSet GetAllExcelSheetData(string FilePath)
        {
            try
            {

                //xrgds.Tables.Add(ReadExcelFile("List Objects", FilePath, "dtListObjects"));
                //xrgds.Tables.Add(ReadExcelFile("Set Sequence", FilePath, "dtSetSequence"));
                //xrgds.Tables.Add(ReadExcelFile("Template Defn", FilePath, "dtTemplateDefn"));
                //xrgds.Tables.Add(ReadExcelFile("Template Hdr", FilePath, "dtTemplateHdr"));
                //ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + FilePath + ";Extended Properties=Excel 12.0;";
                ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FilePath + ";" + "Extended Properties='Excel 8.0;HDR=YES;'";
                if (xrgds.Tables.Contains("dtInputFile"))
                {
                    xrgds.Tables.Remove("dtInputFile");
                    xrgds.Tables.Add(ReadExcelFile("InputFile", FilePath, "dtInputFile"));
                }
                else
                {
                    xrgds.Tables.Add(ReadExcelFile("InputFile", FilePath, "dtInputFile"));
                }


                // xrgds.Tables.Add(ReadExcelFile("LoginDetails", FilePath, "dtLoginDetails"));
                //SplitFunction("Action Key Words", "dtControlFile");
                //SplitFunction("Validations", "dtListObjects");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message + " " + ex.InnerException.ToString());
            }
            return xrgds;
        }

        private DataTable ReadExcelFile(string sheetName, string path, string TableName)
        {
            try
            {
                using (conn = new OleDbConnection())
                {
                    DataTable dt = new DataTable(TableName);
                    conn.ConnectionString = ConnectionString;
                    conn.Open();
                    using (command = new OleDbCommand())
                    {
                        command.CommandText = "Select * from [" + sheetName + "$]";
                        command.Connection = conn;
                        using (adpater = new OleDbDataAdapter())
                        {
                            adpater.SelectCommand = command;
                            adpater.Fill(dt);
                            return dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("\nSheet Data :" + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        /*  public int UpdateValidationResult(ValidationDetails[] Result)
          {
              try
              {
                  bool IsAllValid = Result.All((c) => c.Status == true);
                  using (conn = new OleDbConnection())
                  {
                      if (conn.State == ConnectionState.Open)
                      {
                          conn.Close();
                      }
                      conn.ConnectionString = ConnectionString;
                      conn.Open();
                      using (command = new OleDbCommand())
                      {
                          command.CommandText = "Update [InputFile$] set ValidationResult=" + (IsAllValid == true ? "1" : "0") + " where " + Result[0].FieldName + "='" + Result[0].FieldValue + "'";
                          command.Connection = conn;
                          command.ExecuteNonQuery();
                      }
                  }
              }
              catch (Exception ex)
              {
                  throw new Exception("\nUpdate Validation Result :" + ex.Message);
              }
              finally
              {
                  conn.Close();
              }
              return 0;
          }
          */

        public int UpdateValidationResult(ValidationDetails Result)
        {
            try
            {
                using (conn = new OleDbConnection())
                {
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                    conn.ConnectionString = ConnectionString;
                    conn.Open();
                    using (command = new OleDbCommand())
                    {
                        command.CommandText = @"Update [InputFile$] set ValidationResult=" + (Result.Status == true ? "1" : "0")
                                             + ",Validation_Error='" + Result.Reason + "' where " + Result.FieldName + "='" + Result.FieldValue + "'";
                        command.Connection = conn;
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("\nUpdate Validation Result :" + ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return 0;
        }

        public int InsertInvalidResult(string FileName)
        {
            try
            {
                using (conn = new OleDbConnection())
                {
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                    conn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + FileName + ";" + "Extended Properties='Excel 8.0;HDR=YES;'";
                    conn.Open();
                    using (command = new OleDbCommand())
                    {
                        //string dd = invdata[1].ToString();
                        command.CommandText = @"delete from [InputFile$]";
                        command.Connection = conn;
                        command.ExecuteNonQuery();
                    }


                    using (command = new OleDbCommand())
                    {
                        //string dd = invdata[1].ToString();
                        //command.CommandText = @"Update [InputFile$] set ValidationResult=" + (Result.Status == true ? "1" : "0")
                        //                     + ",Validation_Error='" + Result.Reason + "' where " + Result.FieldName + "='" + Result.FieldValue + "'";
                        command.Connection = conn;
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("\nUpdate Validation Result :" + ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return 0;
        }

    }
}
