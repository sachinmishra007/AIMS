﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace XRGAutomationApplication
{
    class ValidationDetails
    {
        public string FieldName { get; set; }
        public string ValidationName { get; set; }
        public string FieldValue { get; set; }
        public bool Status { get; set; }        
        public string Reason { get; set; }
    }
}
