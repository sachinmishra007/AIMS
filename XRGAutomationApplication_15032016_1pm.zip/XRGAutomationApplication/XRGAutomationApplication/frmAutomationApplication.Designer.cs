﻿namespace XRGAutomationApplication
{
    partial class frmAutomationApplication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtLogDetails = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // rchtxtLogDetails
            // 
            this.rchtxtLogDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rchtxtLogDetails.Location = new System.Drawing.Point(0, 0);
            this.rchtxtLogDetails.Name = "rchtxtLogDetails";
            this.rchtxtLogDetails.Size = new System.Drawing.Size(965, 462);
            this.rchtxtLogDetails.TabIndex = 0;
            this.rchtxtLogDetails.Text = "";
            // 
            // frmAutomationApplication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 462);
            this.Controls.Add(this.rchtxtLogDetails);
            this.Name = "frmAutomationApplication";
            this.Text = "XRG Automation Application";
            this.Load += new System.EventHandler(this.frmAutomationApplication_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtLogDetails;
    }
}