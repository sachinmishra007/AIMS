﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Collections;
using XLS = Microsoft.Office.Interop.Excel;
using System.Diagnostics;
using XRGAutomationApplication.DataAccessLayer;
using System.Text.RegularExpressions;
using System.IO;

namespace XRGAutomationApplication
{
    public partial class frmAutomationApplication : Form
    {
        public string exergyAppPath = string.Empty;

        public Boolean IsUserLoggedIn = false;

        // Pinvoke declaration for ShowWindow
        private const int SW_SHOWMAXIMIZED = 3;
        private const short SWP_NOMOVE = 0X2;
        private const short SWP_NOSIZE = 1;
        private const short SWP_NOZORDER = 0X4;
        private const int SWP_SHOWWINDOW = 0x0040;
        //Caps Lock Keys
        private const int KEYEVENTF_EXTENDEDKEY = 0x1;
        private const int KEYEVENTF_KEYUP = 0x2;

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        public static extern int SetForegroundWindow(IntPtr point);

        [DllImport("user32.dll", EntryPoint = "SetWindowPos")]
        public static extern IntPtr SetWindowPos(IntPtr hWnd, int hWndInsertAfter, int x, int Y, int cx, int cy, int wFlags);

        [DllImport("user32.dll")]
        static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", SetLastError = true)]
        static extern bool GetWindowRect(IntPtr hWnd, out Rectangle lpRect);

        [DllImport("user32.dll")]
        static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);


        [DllImport("user32.dll")]
        static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        #region // Mouse events

        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint cButtons, uint dwExtraInfo);

        private const int MOUSEEVENTF_LEFTDOWN = 0x02;
        private const int MOUSEEVENTF_LEFTUP = 0x04;
        private const int MOUSEEVENTF_RIGHTDOWN = 0x08;
        private const int MOUSEEVENTF_RIGHTUP = 0x10;

        #endregion


        ConnectionClass cls = null;
        ArrayList operation = new ArrayList();
        XLS.Application myapp = null;
        XLS.Workbook wb = null;
        XLS.Worksheet sheet = null;
        Process p;
        IntPtr h;

        public struct InputKeys
        {
            public string ActionName;
            public int Times;
        }

        public struct ResultforRow
        {
            public string ColumnName;
            public bool Result;
        }

        public List<String> Processfiles = new List<String>();
        public List<String> DirectoriesNames = new List<String>();
        public List<String> InputFiles = new List<String>();

        public void GetInputFiles(string ProcessFileName, int FileCount)
        {

            try
            {
                InputFiles.Clear();
                if (ProcessFileName.Contains("ProcessID-" + (FileCount + 1) + ".xls"))
                {
                    foreach (string d in Directory.GetFiles(cls.ProcessFilePath + @"InputFile\ProcessID-" + (FileCount + 1)))
                    {
                        InputFiles.Add(d);
                    }
                }
            }
            catch (Exception ex)
            {

            }

        }

        private void GetDirectoryforStrutures(string sDir)
        {
            try
            {
                foreach (string d in Directory.GetDirectories(sDir))
                {
                    DirectoriesNames.Add(d);
                    if (d.Contains("PolicyNewBusiness"))
                    {
                        foreach (string f in Directory.GetFiles(d))
                        {
                            Processfiles.Add(f);
                        }
                    }

                }
                //GetInputFiles();
                //DirSearch(d);
            }
            catch (System.Exception excpt)
            {
                MessageBox.Show(excpt.Message);
            }
        }

        public frmAutomationApplication()
        {
            //DisableCapsKey();
            InitializeComponent();
            try
            {
                string FilePath = string.Empty;
                bool IsProcessStarted = false;
                bool IsLoginData = false;
                cls = new ConnectionClass("");
                cls.LoadExcelFileData("");
                GetDirectoryforStrutures(cls.ProcessFilePath);
                for (int FileCount = 0; FileCount < Processfiles.Count; FileCount++)
                {
                    FilePath = Processfiles[FileCount];
                    GetInputFiles(FilePath, FileCount);
                    for (int inpCount = 0; inpCount < InputFiles.Count; inpCount++)
                    {
                        cls.LoadExcelFileData(FilePath);
                        cls.GetAllExcelSheetData(InputFiles[inpCount].ToString());
                        CheckforValidation();
                        cls.GetAllExcelSheetData(InputFiles[inpCount].ToString());
                        /*Checking for the Validation of the Files*/
                        var checkRows = from dt in cls.xrgds.Tables["dtInputFile"].AsEnumerable()
                                        where dt.Field<object>("ValidationResult").Equals("0") == true
                                        select dt;
                        if (checkRows.ToList().Count() == 0)
                        {
                            richTextBox1.Text += "\n\n\n File :" + InputFiles[inpCount].ToString();
                            //Code

                            #region <=================== Auromation Execution Code =====================================>
                            if (IsProcessStarted == false)
                            {
                                exergyAppPath = @"C:\Exergy\SDT.Exergy.exe";
                                p = Process.Start(exergyAppPath);
                                p.WaitForInputIdle();
                                h = p.MainWindowHandle;
                                SetForegroundWindow(h);
                                IsProcessStarted = true;
                            }


                            for (int seqCount = 0; seqCount < cls.xrgds.Tables["dtInputFile"].Rows.Count; seqCount++)
                            {
                                richTextBox1.Text += "\n\n -Record :" + seqCount.ToString() + " , IsUserLoggedIn: " + IsUserLoggedIn.ToString();
                                //
                                #region // Call Sequence
                                foreach (DataRow dr in cls.xrgds.Tables["dtSetSequence"].Rows)
                                {
                                    string CurrTemplate = dr["Curr# Template"].ToString();
                                    string CurrObject = dr["Curr# Object"].ToString();
                                    string Operator = dr["Operator"].ToString();
                                    string Value = dr["Value"].ToString();
                                    string ActionKeyWords = dr["Action - Key Words"].ToString();
                                    string NextTemplate = dr["Next Template"].ToString();
                                    string NextObject = dr["Next# Object"].ToString();
                                    string Result = string.Empty;
                                    string ExecNextSequence = string.Empty;
                                    string[] action;
                                    InputKeys[] result;
                                    string FieldName = string.Empty;
                                    if (ActionKeyWords.Trim() != "" && CurrTemplate.Trim() == "")
                                    {
                                        if (IsUserLoggedIn && ActionKeyWords.ToLower().Contains("|esc"))
                                        {
                                            goto EscapeSequence;
                                        }
                                        if (ActionKeyWords.Contains("|"))
                                        {
                                            action = cls.GetCommands(ActionKeyWords);
                                            //result = GetInputValue("dtControlFile", action);
                                            //FieldName = GetListObjectDetails(CurrObject, "dtListObjects");
                                        }
                                        else
                                        {
                                            action = cls.GetCommands(ActionKeyWords);
                                            //result = GetInputValue("dtControlFile", action);
                                            //FieldName = GetListObjectDetails(CurrObject, "dtListObjects");
                                        }
                                        result = GetInputValue("dtControlFile", action);
                                        FieldName = GetListObjectDetails(CurrObject, "dtListObjects");
                                        string value = string.Empty;
                                        string NewValue = string.Empty;

                                        if (GetDataTypeofObject(CurrObject, "dtListObjects") == true)
                                        {
                                            value = FieldName;// GetTableDetails(FieldName, "dtListObjects");
                                            IsLoginData = true;
                                        }
                                        else
                                        {
                                            if (IsLoginData == true)
                                            {
                                                value = GetTableDetails(FieldName, "dtInputFile", seqCount);
                                            }
                                            else
                                            {
                                                value = GetTableDetails(FieldName, "dtListObjects");
                                            }
                                        }
                                        NewValue = CaseConverstion(value);
                                        if (NewValue != "")
                                        {
                                            System.Threading.Thread.Sleep(1000);
                                            SendKeys.SendWait(NewValue);
                                        }

                                        string CompareString = string.Empty;
                                        string[] BackTrackCommands = null;
                                        p.WaitForInputIdle();
                                        string Title = GetActiveWindowTitle();


                                        for (int i = 0; i < result.Length; i++)
                                        {
                                            if (action[i].ToString().Contains("MOUSE"))
                                            {
                                                HandleMouseEvent(action[i].ToString());
                                            }
                                            else if (action[i].StartsWith("CHECK"))
                                            {
                                                BackTrackCommands = action[i].Split('!');
                                                //0= > For Checking the Value of First Index If it contains "CHECK(" then Replcate with Empty String
                                                CompareString = BackTrackCommands[0].Replace("CHECK(", "").Replace(")", "").Trim();
                                                BackTrackCommands[BackTrackCommands.Length - 1] = BackTrackCommands[BackTrackCommands.Length - 1].Replace(")", "").Trim();
                                            }
                                            else
                                            {
                                                if (action[i].ToString() == "REPOSITION")
                                                {
                                                    //IsReposition = true;
                                                    RepositionWindow(GetForegroundWindow());
                                                }
                                                if (result[i].ActionName != "")
                                                {
                                                    //SendKey(result[i], 1000);
                                                    Result += GetSendKey(result[i]);
                                                }
                                            }
                                        }
                                        if (Title != null && BackTrackCommands != null)
                                        {
                                            if (CompareString.ToUpper() == Title.ToUpper())
                                            {
                                                //throw new Exception("CHECK FAILED");
                                                InputKeys[] BackTrack = GetInputValue("dtControlFile", BackTrackCommands);
                                                for (int i = 0; i < BackTrack.Length; i++)
                                                {
                                                    if (BackTrack[i].ActionName != "" && BackTrack[i].ActionName != null)
                                                    {
                                                        Result += GetSendKey(BackTrack[i]);
                                                    }
                                                }
                                                SendKey(Result, 100); Result = "";
                                                goto ENDNegativeScenario;
                                            }
                                        }


                                        SendKey(Result, 2000);
                                        //if (IsReposition)
                                        //    RepositionWindow(GetForegroundWindow());
                                        richTextBox1.Text += "\nSequence:" + CurrObject + " , ActionKeyword:" + ActionKeyWords + " , Action:" + Result;

                                    //To handle ESC action keyword
                                    EscapeSequence: Console.WriteLine("");
                                    }
                                    else if (CurrTemplate != "")
                                    {
                                        var TemplateDef = from tempdef in cls.xrgds.Tables["dtTemplateDefn"].AsEnumerable()
                                                          where tempdef.Field<string>("Template") == CurrTemplate
                                                          select new
                                                          {
                                                              TemplateName = tempdef.Field<string>("Template"),
                                                              CurrSequence = tempdef.Field<string>("Curr# Sequence"),
                                                              CurrSequenceDataType = tempdef.Field<string>("Curr# Sequence Data Type"),
                                                              Operator = tempdef.Field<string>("Operator"),
                                                              Value = tempdef.Field<string>("Value"),
                                                              ActionKeyWords = tempdef.Field<string>("ActionKeyWords"),
                                                              NextSequence = tempdef.Field<string>("Next# Sequence")
                                                          };
                                        foreach (var item in TemplateDef)
                                        {
                                            if (ExecNextSequence == "" || ExecNextSequence == item.CurrSequence)
                                            {
                                                if (item.ActionKeyWords.Contains("|"))
                                                {
                                                    action = cls.GetCommands(item.ActionKeyWords);
                                                    //result = GetInputValue("dtControlFile", action);
                                                    //FieldName = GetListObjectDetails(item.CurrSequence, "dtListObjects");
                                                }
                                                else
                                                {
                                                    action = cls.GetCommands(item.ActionKeyWords);
                                                    //result = GetInputValue("dtControlFile", action);
                                                    //FieldName = GetListObjectDetails(item.CurrSequence, "dtListObjects");
                                                }
                                                result = GetInputValue("dtControlFile", action);
                                                FieldName = GetListObjectDetails(item.CurrSequence, "dtListObjects");

                                                //if (FieldName != "")
                                                //{
                                                string value = GetTableDetails(FieldName, "dtInputFile", seqCount);
                                                if (item.Operator != null && item.Value != null && item.NextSequence != null)
                                                {
                                                    if (item.Operator.ToString() == "=")
                                                    {
                                                        if (value == item.Value.ToString())
                                                        {
                                                            ExecNextSequence = item.NextSequence;
                                                        }
                                                    }
                                                }
                                                // string NewValue = CaseConverstion(value);
                                                if (value != "")
                                                {
                                                    System.Threading.Thread.Sleep(1000);
                                                    SendKeys.SendWait(value);
                                                }
                                                string CompareString = string.Empty;
                                                string[] BackTrackCommands = null;
                                                p.WaitForInputIdle();
                                                string Title = GetActiveWindowTitle();
                                                for (int i = 0; i < result.Length; i++)
                                                {
                                                    if (action[i].ToString().Contains("MOUSE"))
                                                    {
                                                        HandleMouseEvent(action[i].ToString());
                                                    }
                                                    else if (action[i].StartsWith("CHECK"))
                                                    {
                                                        BackTrackCommands = action[i].Split('!');
                                                        //0= > For Checking the Value of First Index If it contains "CHECK(" then Replcate with Empty String
                                                        CompareString = BackTrackCommands[0].Replace("CHECK(", "").Replace(")", "").Trim();
                                                        BackTrackCommands[BackTrackCommands.Length - 1] = BackTrackCommands[BackTrackCommands.Length - 1].Replace(")", "").Trim();
                                                    }
                                                    if (result[i].ActionName != "" && result[i].ActionName != null)
                                                    {
                                                        Result += GetSendKey(result[i]);
                                                    }
                                                }
                                                if (Title != null && BackTrackCommands != null)
                                                {
                                                    if (CompareString.ToUpper() == Title.ToUpper())
                                                    {
                                                        //throw new Exception("CHECK FAILED");
                                                        InputKeys[] BackTrack = GetInputValue("dtControlFile", BackTrackCommands);
                                                        for (int i = 0; i < BackTrack.Length; i++)
                                                        {
                                                            if (BackTrack[i].ActionName != "" && BackTrack[i].ActionName != null)
                                                            {
                                                                Result += GetSendKey(BackTrack[i]);
                                                            }
                                                        }
                                                        SendKey(Result, 100); Result = "";
                                                        goto ENDNegativeScenario;
                                                    }
                                                }
                                                //
                                                // Execute Concatenated Events 
                                                SendKey(Result, 100);
                                                //
                                                richTextBox1.Text += "\nTemplate :" + CurrTemplate + " , Sequence:" + CurrObject + " , ActionKeyword:" + ActionKeyWords + " , Action:" + Result;
                                                Result = "";
                                            }
                                            // }
                                        }
                                        ExecNextSequence = "";
                                    }
                                }
                            #endregion //Call Sequence

                            // To handle Negative scenario
                            ENDNegativeScenario: Console.WriteLine("");

                                // Set value to indicate user logged in
                                IsUserLoggedIn = true;
                            }
                            #endregion
                            
                            FileInfo info = new FileInfo(InputFiles[inpCount]);
                            string Patha = Path.GetDirectoryName(InputFiles[inpCount]);
                            string PathToMove = Patha + @"\Complete\" + info.Name.Replace(".", "_" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".");
                            info.MoveTo(PathToMove);
                        }
                        else
                        {

                            string DirectoryPath = string.Empty;
                            string PathToMove = string.Empty;
                            FileInfo FileInvalid = new FileInfo(InputFiles[inpCount]);
                            DirectoryPath = Path.GetDirectoryName(InputFiles[inpCount]);
                            PathToMove = DirectoryPath + @"\Failed\" + FileInvalid.Name.Replace(".", "_" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".");
                            FileInvalid.CopyTo(PathToMove);


                            Microsoft.Office.Interop.Excel.Application oXL;
                            Microsoft.Office.Interop.Excel._Workbook oWB;
                            Microsoft.Office.Interop.Excel._Worksheet oSheet;
                            Microsoft.Office.Interop.Excel.Range oRng;
                            object misvalue = System.Reflection.Missing.Value;
                            //Start Excel and get Application object.
                            oXL = new Microsoft.Office.Interop.Excel.Application();
                            oXL.Visible = false;
                            oXL.DisplayAlerts = false;
                            //Get a new workbook.
                            oWB = (Microsoft.Office.Interop.Excel._Workbook)(oXL.Workbooks.Add(""));
                            oSheet = (Microsoft.Office.Interop.Excel._Worksheet)oWB.ActiveSheet;
                            for (int dtInColCount = 0; dtInColCount < cls.xrgds.Tables["dtInputFile"].Columns.Count; dtInColCount++)
                            {
                                oSheet.Cells[1, dtInColCount + 1] = cls.xrgds.Tables["dtInputFile"].Columns[dtInColCount].ColumnName.Replace("#", ".");
                            }

                            #region <=============== TO Make Excel Column header Bold ==========================>
                            //Format A1:D1 as bold, vertical alignment = center.
                            //oSheet.get_Range("A1", "" + ((char)(65 + dtInputtotColumCount)).ToString() + "1").Font.Bold = true;
                            //oSheet.get_Range("A1", "" + ((char)(65 + dtInputtotColumCount)).ToString() + "1").VerticalAlignment
                            //= Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                            #endregion

                            DataTable dtInvalidRecords = checkRows.CopyToDataTable<DataRow>();
                            int dtInputtotRowsCount = dtInvalidRecords.Rows.Count;
                            int dtInputtotColumCount = cls.xrgds.Tables["dtInputFile"].Columns.Count;
                            string[,] XlinvalidRecords = new string[checkRows.ToList().Count(), dtInputtotColumCount];
                            string strGetRangeValue = string.Empty;


                            for (int liRow = 0; liRow < dtInvalidRecords.Rows.Count; liRow++)
                            {
                                for (int liCol = 0; liCol < dtInputtotColumCount; liCol++)
                                {
                                    XlinvalidRecords[liRow, liCol] = Convert.ToString(dtInvalidRecords.Rows[liRow][liCol]).Trim();

                                }
                            }

                            if (dtInputtotColumCount == 26)
                            {
                                strGetRangeValue = ((char)(64 + dtInputtotColumCount)).ToString() + "" + (dtInputtotRowsCount + 1);
                                oSheet.get_Range("A1", "" + ((char)(64 + dtInputtotColumCount)).ToString() + "1").Font.Bold = true;
                            }
                            else if (dtInputtotColumCount >= 26)
                            {
                                //dtInputtotColumCount-1 : for #N/A Condition
                                //Where (dtInputtotColumCount-1)-26)) AZ3 Condition
                                strGetRangeValue = "A" + ((char)(65 + (dtInputtotColumCount - 1) - 26)).ToString() + "" + (dtInputtotRowsCount + 1);
                                oSheet.get_Range("A1", "" + ((char)(65 + (dtInputtotColumCount - 1) - 26)).ToString() + "1").Font.Bold = true;
                            }
                            else if (dtInputtotColumCount < 26)
                            {
                                strGetRangeValue = ((char)(65 + dtInputtotColumCount - 1)).ToString() + "" + (dtInputtotRowsCount + 1);
                                oSheet.get_Range("A1", "" + ((char)(65 + dtInputtotColumCount)).ToString() + "1").Font.Bold = true;
                            }

                            //Fill A2:B6 with an array of values (First and Last Names).
                            oSheet.get_Range("A2", strGetRangeValue).Value2 = XlinvalidRecords;
                            ////AutoFit columns A:D.
                            oRng = oSheet.get_Range("A1", "D" + dtInputtotColumCount);
                            oRng.EntireColumn.AutoFit();

                            oXL.Visible = false;
                            oXL.UserControl = false;

                            oWB.SaveAs(PathToMove, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing,
                                Type.Missing, Type.Missing, XLS.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing,
                        Type.Missing, Type.Missing);
                            oWB.Close(false, Type.Missing, Type.Missing);
                            oXL.Quit();
                            if (oXL != null)
                            {
                                Process[] pProcess;
                                pProcess = System.Diagnostics.Process.GetProcessesByName("Excel");
                                pProcess[0].Kill();
                            }
                            //cls.InsertInvalidResult(PathToMove);

                            System.Threading.Thread.Sleep(3000);
                            FileInfo info = new FileInfo(InputFiles[inpCount]);
                            DirectoryPath = Path.GetDirectoryName(InputFiles[inpCount]);
                            PathToMove = DirectoryPath + @"\Failed\" + info.Name.Replace(".", "_" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".");
                            info.MoveTo(PathToMove);
                            //throw new Exception("File has Errors");
                        }

                        #region <================== Old Code Passing Send Keys ====================>

                        #region // read from EXCEL - START
                        //myapp = new XLS.Application();
                        //wb = myapp.Workbooks.Open(fileName);
                        //sheet = (XLS.Worksheet)wb.Worksheets.get_Item("Config");//Read the Config Sheet Data
                        //operation.Add(CellNextData(sheet, "0"));
                        //operation.Add(CellNextData(sheet, "1"));
                        //operation.Add(CellNextData(sheet, "2"));
                        #endregion
                        ////Start With Step 0 from Config Sheet(Initial Path)
                        //exergyAppPath = operation[0].ToString();
                        //for (int i = 1; i < operation.Count; i++)
                        //{
                        //    //// check sheet exist or not
                        //    //Start With Step 1 from Config Sheet
                        //    if (operation[i].ToString() == "DoLogin")
                        //    {
                        //        LoginDetails(operation[i].ToString());
                        //    }
                        //    //Start With Step 2 from Config Sheet
                        //    else if (operation[i].ToString() == "CreatePolicy")
                        //    {
                        //        CreatePolicy(operation[i].ToString());
                        //    }
                        //}
                        ////XLS.Range rngdata = (XLS.Range)sheet.Cells[2, 2];

                        #endregion
                    }
                    //FileCount++;                   
                }
            }
            catch (Exception e)
            {
                richTextBox1.Text += "\n--------\n ERROR: " + e.Message.ToString() + "\n--------\n STACK TRACE:" + e.StackTrace.ToString();
                return;
                //throw new Exception(e.Message + " - " + e.InnerException.ToString());
            }
            finally
            {
                sheet = null;
                wb = null;
                myapp = null;
            }
        }

        public string GetActiveWindowTitle()
        {
            const int nChars = 256;
            StringBuilder Buff = new StringBuilder(nChars);
            IntPtr handle = GetForegroundWindow();
            if (GetWindowText(handle, Buff, nChars) > 0)
            {
                return Buff.ToString().Trim();
            }
            return null;
        }

        public InputKeys[] GetInputValue(string dtName, string[] input)
        {
            InputKeys[] result = new InputKeys[input.Length];
            for (int i = 0; i < input.Length; i++)
            {
                foreach (DataRow dr in cls.xrgds.Tables[dtName].Rows)
                {
                    string[] ActionValue = input[i].ToString().Split('-');
                    string a1 = dr[2].ToString();

                    if (ActionValue[0].ToString() == "RETURN")
                    {
                        //Environment.Exit(0);
                        //Returns the Input to Operating System Successful Termination
                        throw new Exception("RETURN");
                    }
                    else if (dr[2].ToString() == ActionValue[0].ToString())
                    {
                        result[i].ActionName = dr["Action"].ToString();
                        if (ActionValue.Length > 1)
                        {
                            result[i].Times = Convert.ToInt32(ActionValue[ActionValue.Length - 1]);
                        }
                        else
                        {
                            result[i].Times = 1;
                        }
                        break;
                    }
                }
                if (input[i].Length == 1)
                {
                    result[i].ActionName = input[i].ToString();
                    result[i].Times = 1;
                }
            }
            return result;

        }

        public void DisableCapsKey()
        {
            if (Control.IsKeyLocked(Keys.CapsLock))
            {
                Console.WriteLine("Caps Lock key is ON.  We'll turn it off");
                keybd_event(0x14, 0x45, KEYEVENTF_EXTENDEDKEY, (UIntPtr)0);
                keybd_event(0x14, 0x45, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, (UIntPtr)0);
            }
            else
            {
                Console.WriteLine("Caps Lock key is OFF");
            }
        }

        public string GetSendKey(InputKeys Keys)
        {
            string Value = string.Empty;
            for (int i = 0; i < Keys.Times; i++)
            {
                Value += Keys.ActionName;
            }
            return Value;
        }

        public void SendKey(string Value, int Timeout)
        {
            System.Threading.Thread.Sleep(Timeout);
            SendKeys.SendWait(Value);
        }

        public bool GetDataTypeofObject(string ObjectLabel, string TbName)
        {
            var details = from dttype in cls.xrgds.Tables[TbName].AsEnumerable()
                          where dttype.Field<string>("Object Label").Equals(ObjectLabel) == true
                          && dttype.Field<string>("Data Type").Equals("Data") == true
                          select new
                          {
                              ObjectLabel = dttype.Field<string>("Object Label"),
                              DataType = dttype.Field<string>("Data Type"),
                              MandatoryinAppln = dttype.Field<string>("Mandatory in Appln"),
                              ColumnMappingfromInputFile = dttype.Field<string>("Column Mapping from Input File"),
                              Validations = dttype.Field<string>("Validations")
                          };
            if (details.ToList().Count() >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }

            #region <=============== Implementation of Same Logic using for loop ================>
            //bool Result = false;
            //foreach (DataRow dr in cls.xrgds.Tables[TbName].Rows)
            //{
            //    if (dr["Object Label"].ToString() == ObjectLabel && dr["Data Type"].ToString() == "Data")
            //    {
            //        Result = true;
            //        break;
            //    }
            //}
            //return Result;
            #endregion
        }

        public string GetListObjectDetails(string ObjectLabel, string TbName)
        {
            var details = from dttype in cls.xrgds.Tables[TbName].AsEnumerable()
                          where dttype.Field<string>("Object Label").Equals(ObjectLabel) == true
                          select new
                          {
                              ColumnMappingfromInputFile = dttype.Field<string>("Column Mapping from Input File")
                          };
            return (details.FirstOrDefault().ColumnMappingfromInputFile == null ? "" : details.FirstOrDefault().ColumnMappingfromInputFile);


            #region <=============== Implementation of Same Logic using for loop ================>
            //string Result = "";
            //foreach (DataRow dr in cls.xrgds.Tables[TbName].Rows)
            //{
            //    if (dr["Object Label"].ToString() == ObjectLabel)
            //    {
            //        Result = dr["Column Mapping from Input File"].ToString();
            //        break;
            //    }
            //}
            //return Result;
            #endregion
        }

        public string GetTableDetails(string ColumnName, string TbName, int RowPosition = 0)
        {
            string Value = "";
            if (ColumnName != "")
            {
                DataRow dr = cls.xrgds.Tables[TbName].Rows[RowPosition];
                Value = dr[ColumnName].ToString();
                //break;
            }
            return Value;
        }

        public string CaseConverstion(string Value)
        {
            string NewValue = "";
            foreach (char ch in Value.ToCharArray())
            {
                if (Char.IsUpper(ch) == true)
                {
                    NewValue += "+" + Char.ToLower(ch).ToString();
                }
                else
                {
                    NewValue += ch.ToString();
                }
            }
            return NewValue;
        }

        public void HandleMouseEvent(string Value)
        {
            //string r = string.Empty;
            int x = 0;
            int y = 0;
            int Count = 0;
            Boolean IsLeft = false;
            Boolean IsRight = false;
            //if (Value.Contains("-R"))
            //{
            //    r = Value.Replace("MOUSE-R(", "").Replace(")","");
            //}
            //if (Value.Contains("-L"))
            //{
            //    r = Value.Replace("MOUSE-L(", "").Replace(")", "");
            //}
            Value = Value.Replace("MOUSE(", "").Replace(")", "");
            GetCoordinates(Value, out x, out y, out Count, out IsLeft, out IsRight);
            DoMouseClick(x, y, IsLeft, IsRight, Count);
        }

        private void GetCoordinates(string r, out int x, out int y, out int Count, out Boolean IsLeft, out Boolean IsRight)
        {
            x = 0; y = 0; Count = 0; IsLeft = false; IsRight = false;
            string[] Coordinates = r.Split(',');

            if (Coordinates.Length > 3)
            {
                if (Coordinates[0].ToString().Trim() == "L")
                    IsLeft = true;
                else if (Coordinates[0].ToString().Trim() == "R")
                    IsRight = true;
                x = Convert.ToInt16(Coordinates[1].ToString());
                y = Convert.ToInt16(Coordinates[2].ToString());
                Count = Convert.ToInt16(Coordinates[3].ToString());
            }
        }

        public bool IsMinLength(string ValidationRule, string ValueToCompare)
        {
            try
            {
                if (ValueToCompare.Length >= Convert.ToInt32(ValidationRule.Substring(ValidationRule.IndexOf(" ") + 1).Trim()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Min Length :" + ex.Message.ToString());
            }
        }

        public bool IsMaxLength(string ValidationRule, string ValueToCompare)
        {
            try
            {
                if (ValueToCompare.Length <= Convert.ToInt32(ValidationRule.Substring(ValidationRule.IndexOf(" ") + 1).Trim()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                throw new Exception("Max Length :" + e.Message);
            }
        }

        public bool IsOnlyCharacter(string ValueToCompare)
        {
            bool Result = false;
            foreach (char ch in ValueToCompare.ToCharArray())
            {
                if (Char.IsLetter(ch))
                {
                    Result = true;
                }
                else
                {
                    Result = false;
                    break;
                }
            }
            return Result;
        }

        public bool IsOnlyDigit(string ValueToCompare)
        {
            bool Result = false;
            foreach (char ch in ValueToCompare.ToCharArray())
            {
                if (Char.IsNumber(ch))
                {
                    Result = true;
                }
                else
                {
                    Result = false;
                    break;
                }
            }
            return Result;
        }

        public bool IsAlphaNumeric(string ValueToCompare)
        {
            Regex pattern = new Regex(@"^[a-zA-Z0-9\s]+$");
            if (ValueToCompare != null && ValueToCompare != "")
            {
                return pattern.IsMatch(ValueToCompare);
            }
            return true;
        }

        public bool IsDate(string strDate)
        {
            DateTime OutDate;
            if (DateTime.TryParse(strDate, out OutDate))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool IsNumeric(string strInput)
        {
            int i = 0;
            return strInput.ToCharArray().All(c => int.TryParse(c.ToString(), out i));
        }

        public bool IsDuplicate(string ColumnName, string TableName)
        {
            var inputfile = from records in cls.xrgds.Tables[TableName].AsEnumerable()
                            group records by records.Field<object>(ColumnName) into grouped
                            where grouped.Count() > 1
                            select grouped.Key;
            return (inputfile.ToList().Count() >= 1 ? false : true);
        }

        public bool IsEmpty(string strValue)
        {
            if (strValue == string.Empty)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        #region <=========== Old Logic for Implemenation of Validation ==================>
        /*public void CheckforValidation()
          {
              string[] ValidationMethod = null;
              var listObject = from listobj in cls.xrgds.Tables["dtListObjects"].AsEnumerable()
                               where listobj.Field<object>("Column Mapping from Input File") != null
                               && listobj.Field<object>("Validations") != null
                               && listobj.Field<string>("Data Type").Equals("Data") == false
                               select new
                               {
                                   ProcessID = listobj.Field<string>("Process ID"),
                                   Template = listobj.Field<string>("Template"),
                                   ObjectLabel = listobj.Field<string>("Object Label"),
                                   DataType = listobj.Field<string>("Data Type"),
                                   MandatoryInAppln = listobj.Field<string>("Mandatory in Appln"),
                                   Comments = listobj.Field<string>("Comments"),
                                   ColumnMappingfromInputFile = listobj.Field<string>("Column Mapping from Input File"),
                                   Validations = listobj.Field<string>("Validations")
                               };


              foreach (var lstobj in listObject)
              {
                  ValidationMethod = lstobj.Validations.Split('|');
                  ValidationDetails[] details = new ValidationDetails[ValidationMethod.Length];
                  var Inputdata = from input in cls.xrgds.Tables["dtInputFile"].AsEnumerable()
                                  where lstobj.DataType != null && lstobj.DataType != "Data"
                                  select new { SearchByID = input.Field<object>(lstobj.ColumnMappingfromInputFile) };

                  foreach (var inpdt in Inputdata)
                  {
                      for (int i = 0; i < ValidationMethod.Length; i++)
                      {
                          bool Result = false;
                          if (ValidationMethod[i].Contains("MaxLength"))
                          {
                              Result = IsMaxLength(ValidationMethod[i], inpdt.SearchByID.ToString());
                          }
                          else if (ValidationMethod[i].Contains("MinLength"))
                          {
                              Result = IsMinLength(ValidationMethod[i], inpdt.SearchByID.ToString());
                          }
                          else if (ValidationMethod[i].Contains("AlphaNumeric"))
                          {
                              Result = IsAlphaNumeric(inpdt.SearchByID.ToString());
                          }
                          else if (ValidationMethod[i].Contains("OnlyCharacter"))
                          {
                              Result = IsOnlyCharacter(inpdt.SearchByID.ToString());
                          }
                          details[i] = new ValidationDetails()
                          {
                              FieldName = lstobj.ColumnMappingfromInputFile,
                              FieldValue = inpdt.SearchByID.ToString(),
                              ValidationName = ValidationMethod[i],
                              Status = Result
                          };
                      }
                      cls.UpdateValidationResult(details);
                  }
              }


          }
          */
        #endregion

        public void CheckforValidation()
        {
            string strValidationResult = string.Empty;
            string[] ValidationMethod = null;
            for (int i = 0; i < cls.xrgds.Tables["dtInputFile"].Rows.Count; i++)
            {
                DataRow dr = cls.xrgds.Tables["dtInputFile"].Rows[i];
                ResultforRow[] StructResRows = new ResultforRow[cls.xrgds.Tables["dtInputFile"].Columns.Count];
                string ColumnName = string.Empty;
                //This will skip last column because two of them are ValidationResult and Reason
                for (int liColumn = 0; liColumn < cls.xrgds.Tables["dtInputFile"].Columns.Count - 2; liColumn++)
                {
                    ColumnName = cls.xrgds.Tables["dtInputFile"].Columns[liColumn].ColumnName.ToString();
                    var lstObject = from listobj in cls.xrgds.Tables["dtListObjects"].AsEnumerable()
                                    where listobj.Field<object>("Column Mapping from Input File") != null
                                    && listobj.Field<object>("Validations") != null
                                    && listobj.Field<string>("Data Type").Equals("Data") == false
                                    && listobj.Field<string>("Column Mapping from Input File").Equals(ColumnName) == true
                                    select new
                                    {
                                        ProcessID = listobj.Field<string>("Process ID"),
                                        Template = listobj.Field<string>("Template"),
                                        ObjectLabel = listobj.Field<string>("Object Label"),
                                        DataType = listobj.Field<string>("Data Type"),
                                        MandatoryInAppln = listobj.Field<string>("Mandatory in Appln"),
                                        Comments = listobj.Field<string>("Comments"),
                                        ColumnMappingfromInputFile = listobj.Field<string>("Column Mapping from Input File"),
                                        Validations = listobj.Field<string>("Validations")
                                    };
                    if (lstObject.ToList().Count > 0)
                    {
                        foreach (var item in lstObject)
                        {
                            ValidationMethod = item.Validations.Split('|');
                            ValidationDetails[] details = new ValidationDetails[ValidationMethod.Length];
                            for (int icount = 0; icount < ValidationMethod.Length; icount++)
                            {
                                bool Result = false;
                                if (ValidationMethod[icount].ToLower().Contains("maxlength"))
                                {
                                    Result = IsMaxLength(ValidationMethod[icount], dr[ColumnName].ToString());
                                }
                                else if (ValidationMethod[icount].ToLower().Contains("minlength"))
                                {
                                    Result = IsMinLength(ValidationMethod[icount], dr[ColumnName].ToString());
                                }
                                else if (ValidationMethod[icount].ToLower().Contains("alphanumeric"))
                                {
                                    Result = IsAlphaNumeric(dr[ColumnName].ToString());
                                }
                                else if (ValidationMethod[icount].ToLower().Contains("onlycharacter"))
                                {
                                    Result = IsOnlyCharacter(dr[ColumnName].ToString());
                                }
                                else if (ValidationMethod[icount].ToLower().Contains("isdate"))
                                {
                                    Result = IsDate(dr[ColumnName].ToString());
                                }
                                else if (ValidationMethod[icount].ToLower().Contains("isnumeric"))
                                {
                                    Result = IsNumeric(dr[ColumnName].ToString());
                                }
                                else if (ValidationMethod[icount].ToLower().Contains("isduplicate"))
                                {
                                    Result = IsDuplicate(dr[ColumnName].ToString(), "dtInputFile");
                                }
                                else if (ValidationMethod[icount].ToLower().Contains("isempty"))
                                {
                                    Result = IsEmpty(dr[ColumnName].ToString());
                                }
                                details[icount] = new ValidationDetails()
                                {
                                    FieldName = ColumnName,
                                    FieldValue = dr[ColumnName].ToString(),
                                    ValidationName = ValidationMethod[icount],
                                    Status = Result
                                };
                                if (Result == false)
                                {
                                    if (strValidationResult.Contains(ColumnName + ":") == false)
                                    {
                                        strValidationResult += "\n" + ColumnName + ":";
                                    }
                                    strValidationResult += ValidationMethod[icount] + ",";
                                }
                            }
                            StructResRows[liColumn].ColumnName = ColumnName;
                            StructResRows[liColumn].Result = (details.All(c => c.Status == true));
                            //if (StructResRows[liColumn].Result == true)
                            //{
                            //    strValidationResult += "VALID";
                            //}
                        }
                    }
                    else
                    {
                        StructResRows[liColumn].ColumnName = ColumnName;
                        StructResRows[liColumn].Result = true;
                        //strValidationResult += "N/A";
                    }

                    #region <=========== Old Logic for Implemenation of Validation ==================>
                    //var listObject = from listobj in cls.xrgds.Tables["dtListObjects"].AsEnumerable()
                    //                 where listobj.Field<object>("Column Mapping from Input File") != null
                    //                 && listobj.Field<object>("Validations") != null
                    //                 && listobj.Field<string>("Data Type").Equals("Data") == false
                    //                 select new
                    //                 {
                    //                     ProcessID = listobj.Field<string>("Process ID"),
                    //                     Template = listobj.Field<string>("Template"),
                    //                     ObjectLabel = listobj.Field<string>("Object Label"),
                    //                     DataType = listobj.Field<string>("Data Type"),
                    //                     MandatoryInAppln = listobj.Field<string>("Mandatory in Appln"),
                    //                     Comments = listobj.Field<string>("Comments"),
                    //                     ColumnMappingfromInputFile = listobj.Field<string>("Column Mapping from Input File"),
                    //                     Validations = listobj.Field<string>("Validations")
                    //                 };


                    //foreach (var lstobj in listObject)
                    //{

                    //    ValidationMethod = lstobj.Validations.Split('|');
                    //    ValidationDetails[] details = new ValidationDetails[ValidationMethod.Length];
                    //    var Inputdata = from input in cls.xrgds.Tables["dtInputFile"].AsEnumerable()
                    //                    where lstobj.DataType != null && lstobj.DataType != "Data"
                    //                    select new { SearchByID = input.Field<string>(lstobj.ColumnMappingfromInputFile) };
                    //    foreach (var inpdt in Inputdata)
                    //    {
                    //        for (int i = 0; i < ValidationMethod.Length; i++)
                    //        {
                    //            bool Result = false;
                    //            if (ValidationMethod[i].Contains("MaxLength"))
                    //            {
                    //                Result = IsMaxLength(ValidationMethod[i], inpdt.SearchByID);
                    //            }
                    //            else if (ValidationMethod[i].Contains("AlphaNeumeric"))
                    //            {
                    //                Result = IsAlphaNumeric(ValidationMethod[i]);
                    //            }
                    //            else if (ValidationMethod[i].Contains("OnlyCharacter"))
                    //            {
                    //                Result = IsOnlyCharacter(ValidationMethod[i]);
                    //            }
                    //            details[i] = new ValidationDetails()
                    //            {
                    //                FieldName = lstobj.ColumnMappingfromInputFile,
                    //                FieldValue = inpdt.SearchByID,
                    //                ValidationName = ValidationMethod[i],
                    //                Status = Result
                    //            };
                    //        }
                    //        cls.UpdateValidationResult(details);
                    //    }

                    //}
                    #endregion
                }
                bool result = StructResRows.Where(c => c.ColumnName != null).All(c => c.Result == true);
                cls.UpdateValidationResult(new ValidationDetails()
                {
                    FieldName = cls.xrgds.Tables["dtInputFile"].Columns[1].ColumnName.ToString(),
                    FieldValue = dr[1].ToString(),
                    Status = result,
                    Reason = strValidationResult,
                    ValidationName = string.Empty
                });
                strValidationResult = string.Empty;
            }
        }

        public void OneTimePressKeys(string KeyName, int Timeout = 1000)
        {
            KeyName = "{" + KeyName + "}";
            System.Threading.Thread.Sleep(Timeout);
            SendKeys.SendWait(KeyName);
        }

        public void LEFT(int NumberOfLeft = 1, int Timeout = 1000)
        {
            string Left = "";
            for (int i = 0; i < NumberOfLeft; i++)
            {
                Left += "{LEFT}";
            }
            System.Threading.Thread.Sleep(Timeout);
            SendKeys.SendWait(Left);
        }

        public void RIGHT(int NumberOfRight = 1, int Timeout = 1000)
        {
            string Right = "";
            for (int i = 0; i < NumberOfRight; i++)
            {
                Right += "{RIGHT}";
            }
            System.Threading.Thread.Sleep(Timeout);
            SendKeys.SendWait(Right);
        }

        public void DOWN(int NumberOfDown = 1, int Timeout = 1000)
        {
            string Downs = "";
            for (int i = 0; i < NumberOfDown; i++)
            {
                Downs += "{DOWN}";
            }
            System.Threading.Thread.Sleep(Timeout);
            SendKeys.SendWait(Downs);
        }

        public void UP(int NumberOfUp = 1, int Timeout = 1000)
        {
            string Ups = "";
            for (int i = 0; i < NumberOfUp; i++)
            {
                Ups += "{UP}";
            }
            System.Threading.Thread.Sleep(Timeout);
            SendKeys.SendWait(Ups);
        }

        public void TAB(int NumberOfTabs = 1, int Timeout = 1000)
        {
            string Tabs = "";
            for (int i = 0; i < NumberOfTabs; i++)
            {
                Tabs += "{TAB}";
            }
            System.Threading.Thread.Sleep(Timeout);
            SendKeys.SendWait(Tabs);
        }

        public void ENTER(int NumberOfEnter = 1, int Timeout = 1000)
        {
            string Enter = "";
            for (int i = 0; i < NumberOfEnter; i++)
            {
                Enter += "{ENTER}";
            }
            System.Threading.Thread.Sleep(Timeout);
            SendKeys.SendWait(Enter);
        }

        public void SPACE(int NumberOfSpace = 1, int Timeout = 1000)
        {
            string Space = "";
            for (int i = 0; i < NumberOfSpace; i++)
            {
                Space += " ";
            }
            System.Threading.Thread.Sleep(Timeout);
            SendKeys.SendWait(Space);
        }

        public void CompoundArgument(string KeyType, string Key, int Timeout)
        {
            string CompoundKey = "";
            KeyType = KeyType.ToUpper();
            if (KeyType == "CTRL")
            {
                CompoundKey = "^";
            }
            else if (KeyType == "SHIFT")
            {
                CompoundKey = "+";
            }
            else if (KeyType == "ALT")
            {
                CompoundKey = "%";
            }
            CompoundKey += Key;
            SendKeys.SendWait(CompoundKey);
            System.Threading.Thread.Sleep(Timeout);
        }

        public bool SheetExists(string SheetName)
        {
            // Keeping track
            bool found = false;
            // Loop through all worksheets in the workbook
            foreach (XLS.Worksheet sheet in wb.Sheets)
            {
                // Check the name of the current sheet
                if (sheet.Name == SheetName)
                {
                    found = true;
                    break; // Exit the loop now
                }
            }

            if (found)
            {
                //XLS.Worksheet mySheet = wb.Sheets["Example"];
                sheet = (XLS.Worksheet)wb.Sheets[SheetName];
                return (found = true);
            }
            else
            {
                return found;
            }

        }

        public string CellNextData(XLS.Worksheet sheet, string ParamTagName)
        {
            string CellValue = "";
            try
            {
                XLS.Range Range_Number, ReadSheet;
                Range_Number = sheet.UsedRange.Find(ParamTagName);
                if (Range_Number != null)
                {
                    ReadSheet = sheet.Cells;
                    int n_c = Range_Number.Column;
                    int n_r = Range_Number.Row;
                    var number = ((XLS.Range)ReadSheet[n_r, n_c + 1]).Value;
                    CellValue = (string)number;
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message + " - " + e.InnerException.ToString());
            }
            return CellValue;
        }

        public string CellBelowData(XLS.Worksheet sheet, string ParamTagName)
        {
            string CellValue = "";
            try
            {
                XLS.Range Range_Number, ReadSheet;
                Range_Number = sheet.UsedRange.Find(ParamTagName);
                ReadSheet = sheet.Cells;
                int n_c = Range_Number.Column;
                int n_r = Range_Number.Row;
                var number = ((XLS.Range)ReadSheet[n_r + 1, n_c]).Value;
                CellValue = "" + number;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message + " - " + e.InnerException.ToString());
            }
            return CellValue;
        }
        //Login Details
        public void LoginDetails(string SheetName)
        {
            try
            {
                string lblUsername, lblPassword;
                sheet = (XLS.Worksheet)wb.Worksheets.get_Item("DoLogin");
                lblUsername = CellBelowData(sheet, "Username");
                lblPassword = CellBelowData(sheet, "Password");
                p = Process.Start(exergyAppPath);
                p.WaitForInputIdle();
                h = p.MainWindowHandle;
                SetForegroundWindow(h);
                // input Password
                System.Threading.Thread.Sleep(3000);
                //SendKeys.SendWait("+{TAB}");
                SendKeys.SendWait(lblPassword); //"+password1"
                                                //return;
                                                //
                                                //press enter --------------------------------------- ERROR HANDLING
                                                //System.Threading.Thread.Sleep(1000);
                                                //SendKeys.SendWait("{ENTER}");


                ENTER();
                //
                //error screen --------------------------------------- ERROR HANDLING
                //System.Threading.Thread.Sleep(1000);
                //SendKeys.SendWait(" ");

                SPACE();

                //error details screen
                //System.Threading.Thread.Sleep(2000);
                //SendKeys.SendWait("{TAB}");

                TAB(1, 2000);
                //System.Threading.Thread.Sleep(500);
                //SendKeys.SendWait("{ENTER}");
                ENTER(1, 500);
                System.Threading.Thread.Sleep(2000);
                //
                // wait for application to load & set it to foreground
                p.WaitForInputIdle();
                //
                // Maximize Window
                ShowWindow(p.MainWindowHandle, SW_SHOWMAXIMIZED);
                //
                p.WaitForInputIdle();
                System.Threading.Thread.Sleep(2000);
            }
            catch (Exception e)
            {
                throw new Exception(e.Message + " " + e.InnerException.ToString());
            }
        }
        //Read Current Window's Left,Top,Right,Bottom values 
        public void RepositionWindow(IntPtr ReposPtr)
        {
            try
            {
                SendKeys.SendWait("% m");
                System.Threading.Thread.Sleep(1000);
                int x = Cursor.Position.X;
                int y = Cursor.Position.Y;
                SendKeys.SendWait("{UP}");
                System.Threading.Thread.Sleep(500);
                Rectangle rect = new Rectangle();
                //GetWindowRect(p.MainWindowHandle, out rect);
                GetWindowRect(ReposPtr, out rect);
                int xWidth = (rect.Width - rect.X) / 2;
                DoMouseClick(xWidth, 0, true, false, 1); //285
            }
            catch (Exception e)
            {
                throw new Exception(e.Message + " " + e.InnerException.ToString());
            }
        }
        //Create Plocy 
        public void CreatePolicy(string SheetName)
        {
            try
            {
                sheet = (XLS.Worksheet)wb.Worksheets.get_Item("CreatePolicy");
                string lsAdvSearchCriteria = CellBelowData(sheet, "Adv_Search_Criteria");
                string lsRSAId = CellBelowData(sheet, "RSA_Id");
                string lsPolicyContractOption = CellBelowData(sheet, "Contract_Option");
                string lsAmount = CellBelowData(sheet, "Amount");
                string lsAgentSiteCode1 = CellBelowData(sheet, "Agent_Site_Code");
                string lsEmpCode1 = CellBelowData(sheet, "Emp_Code");

                #region // old code
                //string lsAgentSiteCode2;
                //string lsEmpCode2;

                //XLS.Range rngAdvSearchCriteria = (XLS.Range)sheet.Cells[5, 2];
                //lsAdvSearchCriteria = Convert.ToString(rngAdvSearchCriteria.Value2);

                //XLS.Range rngRSAId = (XLS.Range)sheet.Cells[6, 2];
                //lsRSAId = Convert.ToString(rngRSAId.Value2);

                //XLS.Range rngPolicyContractOption = (XLS.Range)sheet.Cells[7, 2];
                //lsPolicyContractOption = Convert.ToString(rngPolicyContractOption.Value2);

                //XLS.Range rngAmount = (XLS.Range)sheet.Cells[8, 2];
                //lsAmount = Convert.ToString(rngAmount.Value2);

                //XLS.Range rngAgentSiteCode1 = (XLS.Range)sheet.Cells[9, 2];
                //lsAgentSiteCode1 = Convert.ToString(rngAgentSiteCode1.Value2);

                //XLS.Range rngEmpCode1 = (XLS.Range)sheet.Cells[10, 2];
                //lsEmpCode1 = Convert.ToString(rngEmpCode1.Value2);

                //XLS.Range rngAgentSiteCode2 = (XLS.Range)sheet.Cells[11, 2];
                //lsAgentSiteCode2 = Convert.ToString(rngAgentSiteCode2.Value2);

                //XLS.Range rngEmpCode2 = (XLS.Range)sheet.Cells[12, 2];
                //lsEmpCode2 = Convert.ToString(rngEmpCode2.Value2);

                // // read from EXCEL - END

                //Process p = Process.Start(exergyAppPath);
                //p.WaitForInputIdle();
                //IntPtr h = p.MainWindowHandle;
                //SetForegroundWindow(h);
                ////return;

                //// input Password
                //System.Threading.Thread.Sleep(5000);
                ////SendKeys.SendWait("+{TAB}");
                //SendKeys.SendWait(lsPassword); //"+password1"
                ////return;
                ////
                ////press enter --------------------------------------- ERROR HANDLING
                //System.Threading.Thread.Sleep(1000);
                //SendKeys.SendWait("{ENTER}");
                ////
                ////error screen --------------------------------------- ERROR HANDLING
                //System.Threading.Thread.Sleep(1000);
                //SendKeys.SendWait(" ");
                ////
                ////error details screen
                //System.Threading.Thread.Sleep(2000);
                //SendKeys.SendWait("{TAB}");
                //System.Threading.Thread.Sleep(500);
                //SendKeys.SendWait("{ENTER}");
                //System.Threading.Thread.Sleep(2000);
                ////
                //// wait for application to load & set it to foreground
                //p.WaitForInputIdle();
                ////
                //// Maximize Window
                //ShowWindow(p.MainWindowHandle, SW_SHOWMAXIMIZED);
                ////
                //p.WaitForInputIdle();
                //System.Threading.Thread.Sleep(2000);
                ////
                #endregion


                // New Policy: Ctrl+P
                //SendKeys.SendWait("^p");
                //System.Threading.Thread.Sleep(1000);


                CompoundArgument("Ctrl", "p", 1000);

                //
                // Client Search: Adv Search
                p.WaitForInputIdle();
                //SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}");
                //System.Threading.Thread.Sleep(1000);
                TAB(4, 1000);


                // click Adv search button
                //SendKeys.SendWait(" ");
                //System.Threading.Thread.Sleep(1000);
                SPACE(1, 1000);

                //
                p.WaitForInputIdle();
                //9 TAB
                //SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}");
                //System.Threading.Thread.Sleep(500);
                TAB(9, 500);

                //
                // Advanced search criteria - ID: RSA 
                SendKeys.SendWait(lsAdvSearchCriteria);
                System.Threading.Thread.Sleep(1000);


                //
                //TAB
                //SendKeys.SendWait("{TAB}");
                //System.Threading.Thread.Sleep(500);

                TAB(1, 500);
                // SA ID: 0509235712080
                SendKeys.SendWait(lsRSAId);
                System.Threading.Thread.Sleep(500);


                // ENTER
                //SendKeys.SendWait("{ENTER}");
                //System.Threading.Thread.Sleep(1000);

                ENTER();
                // ALT + T
                //SendKeys.SendWait("%t");
                //System.Threading.Thread.Sleep(500);
                CompoundArgument("ALT", "t", 500);

                // ALT + N
                //SendKeys.SendWait("%n");
                //System.Threading.Thread.Sleep(500);

                CompoundArgument("ALT", "n", 500);


                //
                // Reposition Policy Structure Popup
                RepositionWindow(GetForegroundWindow());
                //
                // ALT + P
                //SendKeys.SendWait("%p");
                //System.Threading.Thread.Sleep(500);
                CompoundArgument("ALT", "p", 500);


                // 3 DOWN 

                //SendKeys.SendWait("{DOWN}{DOWN}{DOWN}");
                //System.Threading.Thread.Sleep(500);

                DOWN(3, 500);

                // ENTER
                //SendKeys.SendWait("{ENTER}");
                //System.Threading.Thread.Sleep(500);

                ENTER(1, 500);

                //5 TAB
                //SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}{TAB}");
                //System.Threading.Thread.Sleep(1000);
                //Respostion the Add Contract Window

                TAB(5, 1000);
                RepositionWindow(GetForegroundWindow());
                System.Threading.Thread.Sleep(1000);


                //Select Contact Type from Excel Sheet

                OneTimePressKeys("F4", 1000);
                //SendKeys.SendWait("{F4}");
                //System.Threading.Thread.Sleep(1000);


                string ContractType = CellBelowData(sheet, "Contract_Type");
                SendKeys.SendWait(ContractType);//Contract Type
                System.Threading.Thread.Sleep(1000);


                #region <===== Old code to handle Menu ======>
                //DoMouseClick(510, 325, true, false, 1);
                //System.Threading.Thread.Sleep(1000);
                //DoMouseClick(510, 400, true, false, 1);
                //System.Threading.Thread.Sleep(1000);
                #endregion

                // TAB
                //SendKeys.SendWait("{TAB}");
                //System.Threading.Thread.Sleep(1000);

                TAB();
                //
                // O >> Contract Option: Option 1
                SendKeys.SendWait(lsPolicyContractOption);
                System.Threading.Thread.Sleep(1000);
                //
                // ALT + O >> OK Button click
                //SendKeys.SendWait("%o");
                //System.Threading.Thread.Sleep(500);

                CompoundArgument("ALT", "o", 500);
                //SendKeys.SendWait("%o");
                //System.Threading.Thread.Sleep(500);

                CompoundArgument("ALT", "o", 500);

                //
                //ERROR >> ALT + E --------------------------------------- ERROR HANDLING
                //SendKeys.SendWait("%e");
                //System.Threading.Thread.Sleep(1000);
                //
                CompoundArgument("ALT", "e", 500);

                // For Component Tab Cursor                
                // SendKeys.SendWait("{TAB}");
                // System.Threading.Thread.Sleep(500);
                TAB();
                //SendKeys.SendWait("{DOWN}");
                //System.Threading.Thread.Sleep(500);
                DOWN();
                //// Applied Contract: Flexi Funeral Click                
                RepositionWindow(GetForegroundWindow());
                System.Threading.Thread.Sleep(3000);
                //
                //ERROR >> ALT + E --------------------------------------- ERROR HANDLING
                //SendKeys.SendWait("%e");
                //System.Threading.Thread.Sleep(1000);
                CompoundArgument("ALT", "e", 500);

                #region // Component Tab - START
                //


                // CTRL TAB >> Components tab
                TAB(12, 1000);
                RIGHT(2, 1000);
                return;
                //DoMouseClick(270, 100, true, false, 1); //440, 100
                //System.Threading.Thread.Sleep(1000);


                //
                // 3 TAB 
                //SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}");
                //System.Threading.Thread.Sleep(500);
                TAB(4, 500);
                //
                // 1000 >> Cover field
                SendKeys.SendWait(lsAmount); //"1000"
                System.Threading.Thread.Sleep(1000);
                //


                #region // for add new component - START
                //// 4 TAB >> New Component
                ////SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}");
                ////System.Threading.Thread.Sleep(500);
                //DoMouseClick(1082, 365, true, false, 1); //980, 460
                //p.WaitForInputIdle();
                ////
                //// 1 DOWN >> Life Assured
                //SendKeys.SendWait("{DOWN}");
                //System.Threading.Thread.Sleep(500);
                ////
                //// 2 TAB 
                //SendKeys.SendWait("{TAB}{TAB}");
                //System.Threading.Thread.Sleep(500);
                ////
                //// 5 DOWN
                //SendKeys.SendWait("{DOWN}{DOWN}{DOWN}{DOWN}{DOWN}{DOWN}{DOWN}");
                //System.Threading.Thread.Sleep(500);
                ////
                //// TAB
                //SendKeys.SendWait("{TAB}");
                //System.Threading.Thread.Sleep(500);
                ////
                //// 10000
                //SendKeys.SendWait(lsAmount); //"10000"
                //System.Threading.Thread.Sleep(500);
                ////
                //// ALT + O
                //SendKeys.SendWait("%o");
                //System.Threading.Thread.Sleep(500);
                ////
                ////ERROR >> ALT + E --------------------------------------- ERROR HANDLING
                //SendKeys.SendWait("%e");
                //System.Threading.Thread.Sleep(1000);
                #endregion // for add new component - END
                //
                #endregion // Component Tab - END
                //
                #region // Payments Tab - START
                // 570,150 >> Payments Tab
                DoMouseClick(340, 100, true, false, 1);
                System.Threading.Thread.Sleep(1000);


                ////
                //// 1050, 300 >> Payment Source - Select
                //DoMouseClick(1000, 250, true, false, 1);
                //System.Threading.Thread.Sleep(1000);
                ////
                //// ALT + T
                //SendKeys.SendWait("%t");
                //System.Threading.Thread.Sleep(500);
                ////
                // 500, 240 >> Payment Info

                DoMouseClick(280, 190, true, false, 1);
                System.Threading.Thread.Sleep(1000);
                //
                // 750,265 >> Source of Funds
                DoMouseClick(580, 220, true, false, 1);
                System.Threading.Thread.Sleep(1000);
                //
                // 1 DOWN
                SendKeys.SendWait("{DOWN}{DOWN}");
                System.Threading.Thread.Sleep(500);
                //
                // 850,265 >> Source of Funds >> ADD Button
                DoMouseClick(800, 220, true, false, 2);
                System.Threading.Thread.Sleep(1000);
                //
                #endregion // Payments Tab - END
                //
                #region // Commission Tab - START
                //
                // 620,100 >> Commission Tab


                DoMouseClick(520, 100, true, false, 1);
                System.Threading.Thread.Sleep(1000);
                //
                // 450,210 >> Select policy in left box
                DoMouseClick(450, 210, true, false, 1);
                System.Threading.Thread.Sleep(1000);
                //
                // 1135,170 >> Create New Owner
                DoMouseClick(1135, 170, true, false, 1);
                System.Threading.Thread.Sleep(1000);
                //
                // 1 TAB >> Search Level Code
                SendKeys.SendWait("{TAB}");
                System.Threading.Thread.Sleep(500);
                //
                // 1 SPACE >> Click Search Level Code
                SendKeys.SendWait(" ");
                System.Threading.Thread.Sleep(500);
                //
                // ALT + S >> Search button
                SendKeys.SendWait("%s");
                System.Threading.Thread.Sleep(1000);
                //
                // 570,510 >> SEARCH GRID
                DoMouseClick(570, 510, true, false, 1);
                System.Threading.Thread.Sleep(1000);
                //
                // ALT + T
                SendKeys.SendWait("%t");
                System.Threading.Thread.Sleep(1000);
                //
                // ALT + A
                SendKeys.SendWait("%a");
                System.Threading.Thread.Sleep(1000);
                //
                #endregion // Commission Tab - END
                //
                // 5 Right Clicks >> Tab Arrow
                DoMouseClick(990, 100, true, false, 7);
                System.Threading.Thread.Sleep(1000);
                //
                #region // CASA Tab - START
                //
                // 1 Right Click >> CASA Tab
                DoMouseClick(900, 100, true, false, 1);
                System.Threading.Thread.Sleep(1000);
                //
                p.WaitForInputIdle();
                //
                // ALT + R >> Request Primary Screening
                SendKeys.SendWait("%r");
                System.Threading.Thread.Sleep(1000);
                //
                // 9 TAB >> GRID Agent Site Code 1 field
                SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}");
                System.Threading.Thread.Sleep(500);
                //
                // 7776 >> Agent Site Code 1
                SendKeys.SendWait(lsAgentSiteCode1); //"7776"
                System.Threading.Thread.Sleep(1000);
                //
                // 3 TAB
                SendKeys.SendWait("{TAB}{TAB}");
                System.Threading.Thread.Sleep(500);
                //
                // 4321 >> Employee Code 1
                SendKeys.SendWait(lsEmpCode1); //"4321"
                System.Threading.Thread.Sleep(1000);
                //
                #region // old code
                //// 5 TAB >> GRID Agent Site Code 2 field
                //SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}{TAB}");
                //System.Threading.Thread.Sleep(500);
                ////
                //// 8392 >> Agent Site Code 2
                //SendKeys.SendWait(lsAgentSiteCode2); //"8392"
                //System.Threading.Thread.Sleep(500);
                ////
                //// 3 TAB
                //SendKeys.SendWait("{TAB}{TAB}");
                //System.Threading.Thread.Sleep(500);
                ////
                //// 5678 >> Employee Code 2
                //SendKeys.SendWait(lsEmpCode2); //"5678"
                //System.Threading.Thread.Sleep(500);
                #endregion
                //
                #endregion // CASA Tab - END
                //


                p.WaitForInputIdle();
                //
                // ALT CV >> Verify for Accept
                SendKeys.SendWait("%cv");
                System.Threading.Thread.Sleep(500);
                //
                //ERROR >> ALT + E --------------------------------------- ERROR HANDLING
                SendKeys.SendWait("%e");
                System.Threading.Thread.Sleep(500);
                //
                // SPACE
                SendKeys.SendWait(" ");
                System.Threading.Thread.Sleep(500);
                //
                // ALT CN >> Verify for Accept
                SendKeys.SendWait("%cn");
                System.Threading.Thread.Sleep(1000);

                return;
                //
                //// ALT P >> Process
                //SendKeys.SendWait("%p");
                //System.Threading.Thread.Sleep(500);
                //
                // SPACE
                SendKeys.SendWait(" ");
                System.Threading.Thread.Sleep(500);
                //
            }
            catch (Exception e)
            {
                throw new Exception(e.Message + " - " + e.InnerException.ToString());
            }
        }
        //Function to move cursor & click
        public void DoMouseClick(int X, int Y, bool isLeftClick, bool isRightClick, int iCount)
        {
            this.Cursor = new Cursor(Cursor.Current.Handle);
            Cursor.Position = new Point(X, Y);
            for (int i = 1; i <= iCount; i++)
            {
                if (isLeftClick)
                {
                    mouse_event(MOUSEEVENTF_LEFTDOWN, (uint)X, (uint)Y, 0, 0);
                    mouse_event(MOUSEEVENTF_LEFTUP, (uint)X, (uint)Y, 0, 0);
                }
                if (isRightClick)
                {
                    mouse_event(MOUSEEVENTF_RIGHTDOWN, (uint)X, (uint)Y, 0, 0);
                    mouse_event(MOUSEEVENTF_RIGHTUP, (uint)X, (uint)Y, 0, 0);
                }
            }
            this.Cursor = null;
        }

        private void frmAutomationApplication_Load(object sender, EventArgs e)
        {
            richTextBox1.Visible = true;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
