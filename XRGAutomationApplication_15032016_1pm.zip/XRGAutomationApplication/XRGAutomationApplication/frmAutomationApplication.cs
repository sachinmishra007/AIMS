﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using XRGAutomationApplication.DataAccessLayer;
using XLS = Microsoft.Office.Interop.Excel;

namespace XRGAutomationApplication
{
    public partial class frmAutomationApplication : Form
    {

        #region // Global declarations

        public string glExergyAppPath = string.Empty;
        public Boolean gbIsUserLoggedIn = false;
        public string InitialDirectoryName = string.Empty;
        ConnectionClass clsConnection = null;
        ArrayList alOperation = new ArrayList();
        //XLS.Application myapp = null;
        XLS.Workbook xlsWorkbook = null;
        XLS.Worksheet xlsSheet = null;
        Process goProcess;
        IntPtr gptrHandler;
        Process goTempProcess;
        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        public struct InputKeys
        {
            public string ActionName;
            public int Times;
        }

        public struct ResultforRow
        {
            public string ColumnName;
            public bool Result;
        }

        public List<String> Processfiles = new List<String>();
        public List<String> DirectoriesNames = new List<String>();
        public List<String> InputFiles = new List<String>();

        #endregion

        #region // Pinvoke declaration for ShowWindow

        private const int SW_SHOWMAXIMIZED = 3;
        private const short SWP_NOMOVE = 0X2;
        private const short SWP_NOSIZE = 1;
        private const short SWP_NOZORDER = 0X4;
        private const int SWP_SHOWWINDOW = 0x0040;

        #endregion

        #region // Keyboard events

        //Caps Lock Keys
        private const int KEYEVENTF_EXTENDEDKEY = 0x1;
        private const int KEYEVENTF_KEYUP = 0x2;

        [DllImport("user32.dll")]
        static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

        #endregion

        #region // Window events

        [DllImport("user32.dll")]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        public static extern int SetForegroundWindow(IntPtr point);

        [DllImport("user32.dll", EntryPoint = "SetWindowPos")]
        public static extern IntPtr SetWindowPos(IntPtr hWnd, int hWndInsertAfter, int x, int Y, int cx, int cy, int wFlags);

        [DllImport("user32.dll")]
        static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll", SetLastError = true)]
        static extern bool GetWindowRect(IntPtr hWnd, out Rectangle lpRect);

        [DllImport("user32.dll")]
        static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);


        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern IntPtr SetFocus(HandleRef hWnd);

        #endregion

        #region // Mouse events

        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.StdCall)]
        public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint cButtons, uint dwExtraInfo);

        private const int MOUSEEVENTF_LEFTDOWN = 0x02;
        private const int MOUSEEVENTF_LEFTUP = 0x04;
        private const int MOUSEEVENTF_RIGHTDOWN = 0x08;
        private const int MOUSEEVENTF_RIGHTUP = 0x10;

        #endregion

        // Load Event
        private void frmAutomationApplication_Load(object sender, EventArgs e)
        {
            rchtxtLogDetails.Visible = true;
        }

        public frmAutomationApplication()
        {
            string lsFilePath = string.Empty;
            bool IsProcessStarted = false;
            bool IsNegativeScenario = false;
            bool IsPreProcessed = false;
            int lnPreProcessorTemplateCount = 0;

            //// To switch off Caps Lock Key
            DisableCapsKey();



            InitializeComponent();

            try
            {
                clsConnection = new ConnectionClass("");
                clsConnection.LoadExcelFileData("");
                GetDirectoryforStrutures(clsConnection.ProcessFilePath);
                string lsProcessIdName = string.Empty;
                for (int FileCount = 0; FileCount < Processfiles.Count; FileCount++)
                {
                    lsProcessIdName = (new FileInfo(Processfiles[FileCount])).Name;
                    lsProcessIdName = (
                                    lsProcessIdName.ToLower().Contains(".xls".ToLower()) == true ? lsProcessIdName.Replace(".xls", "") :
                                    lsProcessIdName.ToLower().Contains(".xlsx".ToLower()) == true ? lsProcessIdName.Replace(".xlsx", "") : ""
                                    );
                    lsFilePath = Processfiles[FileCount];
                    GetInputFiles(lsFilePath, FileCount);
                    for (int inpCount = 0; inpCount < InputFiles.Count; inpCount++)
                    {
                        clsConnection.LoadExcelFileData(lsFilePath);
                        clsConnection.GetAllExcelSheetData(InputFiles[inpCount].ToString());
                        CheckforValidation();
                        clsConnection.GetAllExcelSheetData(InputFiles[inpCount].ToString());

                        /*Checking for the Validation of the Files*/
                        var checkRows = from dt in clsConnection.xrgds.Tables["dtInputFile"].AsEnumerable()
                                        where dt.Field<object>("ValidationResult").Equals("0") == true
                                        select dt;
                        if (checkRows.ToList().Count() == 0)
                        {
                            LogDetails("\n\n\n File :" + InputFiles[inpCount].ToString());

                            #region // Sequence Template Execution - START

                            #region // Start Application Process - START
                            if (IsProcessStarted == false)
                            {
                                try
                                {
                                    goTempProcess = new Process()
                                    {
                                        StartInfo = new ProcessStartInfo()
                                        {
                                            CreateNoWindow = true,
                                            WindowStyle = ProcessWindowStyle.Minimized,
                                            FileName = "notepad.exe"
                                        }
                                    };
                                    goTempProcess.Start();

                                    //glExergyAppPath = @"C:\Exergy\SDT.Exergy.exe";
                                    glExergyAppPath = (from ApplicationFilePath in clsConnection.xrgds.Tables["dtControlFile"].AsEnumerable()
                                                       select new
                                                       {
                                                           ApplicationPath = ApplicationFilePath.Field<object>("Application Path") != null ?
                                                           ApplicationFilePath.Field<string>("Application Path") : string.Empty
                                                       }).ToList()[0].ApplicationPath;
                                    goProcess = Process.Start(glExergyAppPath);
                                    goProcess.WaitForInputIdle();
                                    gptrHandler = goProcess.MainWindowHandle;
                                    SetForegroundWindow(gptrHandler);
                                    IsProcessStarted = true;




                                }
                                catch (Exception foException)
                                {
                                    throw new Exception("Please provide valid Application Path in ControlFile.xls");
                                }
                            }
                            #endregion // Start Application Process - END

                            #region // Execute PreProcessing Template Sequences - START
                            if (!IsPreProcessed)
                            {
                                for (int liPreProcessorTemplateCount = 0; liPreProcessorTemplateCount < clsConnection.xrgds.Tables["dtPreProcessing"].Rows.Count; liPreProcessorTemplateCount++)
                                {
                                    IsPreProcessed = true;
                                    string PreProcessTemplate = clsConnection.xrgds.Tables["dtPreProcessing"].Rows[lnPreProcessorTemplateCount]["Template"].ToString();
                                    ExecuteTemplateSequence(PreProcessTemplate, 0, out IsNegativeScenario);
                                    if (IsNegativeScenario)
                                    {
                                        IsPreProcessed = false;
                                        return;
                                    }
                                }
                                //
                                // Set value to indicate user logged in
                                gbIsUserLoggedIn = true;
                            }
                            #endregion // Execute PreProcessing Template Sequences - END

                            for (int liInputCount = 0; liInputCount < clsConnection.xrgds.Tables["dtInputFile"].Rows.Count; liInputCount++)
                            {
                                LogDetails("\n\n -Record :" + liInputCount.ToString() + " , IsUserLoggedIn: " + gbIsUserLoggedIn.ToString());
                                //
                                IsNegativeScenario = false;
                                //
                                #region // Call Sequence - START
                                string lsExecuteNextTemplate = string.Empty;
                                string lsExecuteNextObject = string.Empty;
                                //
                                foreach (DataRow dr in clsConnection.xrgds.Tables["dtSetSequence"].Rows)
                                {
                                    string CurrTemplate = dr["Curr# Template"].ToString().Trim();
                                    string CurrObject = dr["Curr# Object"].ToString().Trim();
                                    string Operator = dr["Operator"].ToString().Trim();
                                    string OperatorValue = dr["Value"].ToString().Trim();
                                    string ActionKeyWords = dr["Action - Key Words"].ToString().Trim();
                                    string NextTemplate = dr["Next Template"].ToString().Trim();
                                    string NextObject = dr["Next# Object"].ToString().Trim();
                                    string Result = string.Empty;
                                    string ExecNextSequence = string.Empty;
                                    string[] action;
                                    InputKeys[] result;
                                    string lsFieldName = string.Empty; // List Object field name
                                    //
                                    if (lsExecuteNextObject.Trim() == string.Empty || lsExecuteNextObject.ToLower().Trim() == CurrObject.ToLower().Trim())
                                    {
                                        if (lsExecuteNextTemplate.Trim() == string.Empty || lsExecuteNextTemplate.ToLower().Trim() == CurrTemplate.ToLower().Trim())
                                        {
                                            // Clear next template value when current sequence value is same
                                            if (lsExecuteNextTemplate.ToLower().Trim() == CurrTemplate.ToLower().Trim())
                                            {
                                                lsExecuteNextTemplate = string.Empty;
                                            }
                                            //
                                            // Check for Template
                                            if (ActionKeyWords.Trim() != string.Empty && CurrTemplate.Trim() == string.Empty)
                                            {
                                                // Clear next sequence value when current sequence value is same
                                                if (lsExecuteNextObject.ToLower().Trim() == CurrObject.ToLower().Trim())
                                                {
                                                    lsExecuteNextObject = string.Empty;
                                                }

                                                //
                                                //if (gbIsUserLoggedIn && ActionKeyWords.ToLower().Contains("|esc"))
                                                //{
                                                //    goto EscapeSequence;
                                                //}
                                                if (ActionKeyWords.Contains("|"))
                                                {
                                                    action = clsConnection.GetCommands(ActionKeyWords);
                                                }
                                                else
                                                {
                                                    action = clsConnection.GetCommands(ActionKeyWords);
                                                }
                                                result = GetInputValue("dtControlFile", action);
                                                lsFieldName = GetListObjectDetails(CurrObject, "dtListObjects");
                                                string lsFieldNameValue = string.Empty;
                                                string lsCaseSensetiveValue = string.Empty;

                                                if (GetDataTypeofObject(CurrObject, "dtListObjects") == true)
                                                {
                                                    lsFieldNameValue = lsFieldName;
                                                }
                                                else
                                                {
                                                    lsFieldNameValue = GetTableDetails(lsFieldName, "dtInputFile", liInputCount);
                                                }

                                                //lsFieldNameValue = "TEST";
                                                #region // Check for Operator & Value columns - START
                                                if (Operator != null && OperatorValue != null && (NextTemplate != null || NextObject != null))
                                                {
                                                    if (Operator.Trim() != string.Empty && OperatorValue.Trim() != string.Empty
                                                    && (NextTemplate.Trim() != string.Empty || NextObject.Trim() != string.Empty))
                                                    {
                                                        if (Operator.Trim() == "=")
                                                        {
                                                            if (lsFieldNameValue.ToLower().Trim() == OperatorValue.ToLower().Trim())
                                                            {
                                                                if (NextTemplate.Trim() != string.Empty)
                                                                    lsExecuteNextTemplate = NextTemplate.Trim();
                                                                else if (NextObject.Trim() != string.Empty)
                                                                    lsExecuteNextObject = NextObject.Trim();
                                                            }
                                                        }
                                                        else if (Operator.Trim() == "<>")
                                                        {
                                                            if (lsFieldNameValue.ToLower().Trim() != OperatorValue.ToLower().Trim())
                                                            {
                                                                if (NextTemplate.Trim() != string.Empty)
                                                                    lsExecuteNextTemplate = NextTemplate.Trim();
                                                                else if (NextObject.Trim() != string.Empty)
                                                                    lsExecuteNextObject = NextObject.Trim();
                                                            }
                                                        }
                                                        else if (Operator.Trim() == "<")
                                                        {
                                                            if (Convert.ToInt16(lsFieldNameValue.Trim()) < Convert.ToInt16(OperatorValue.Trim()))
                                                            {
                                                                if (NextTemplate.Trim() != string.Empty)
                                                                    lsExecuteNextTemplate = NextTemplate.Trim();
                                                                else if (NextObject.Trim() != string.Empty)
                                                                    lsExecuteNextObject = NextObject.Trim();
                                                            }
                                                        }
                                                        else if (Operator.Trim() == ">")
                                                        {
                                                            if (Convert.ToInt16(lsFieldNameValue.Trim()) > Convert.ToInt16(OperatorValue.Trim()))
                                                            {
                                                                if (NextTemplate.Trim() != string.Empty)
                                                                    lsExecuteNextTemplate = NextTemplate.Trim();
                                                                else if (NextObject.Trim() != string.Empty)
                                                                    lsExecuteNextObject = NextObject.Trim();
                                                            }
                                                        }
                                                        else if (Operator.Trim().ToLower() == "like")
                                                        {
                                                            // LIKE condition Check >> Eg. // INDIA  >> INDIAN
                                                            if (OperatorValue.Trim().ToLower().Contains(lsFieldNameValue.Trim().ToLower()))
                                                            {
                                                                if (NextTemplate.Trim() != string.Empty)
                                                                    lsExecuteNextTemplate = NextTemplate.Trim();
                                                                else if (NextObject.Trim() != string.Empty)
                                                                    lsExecuteNextObject = NextObject.Trim();
                                                            }
                                                        }
                                                        else if (Operator.Trim().ToLower() == "in")
                                                        {
                                                            // IN condition Check >> Eg. // ,a, >> ,a,b,c,
                                                            string lsOperatorValue = "," + OperatorValue.ToLower().Trim() + ",";
                                                            if (lsOperatorValue.Contains("," + lsFieldNameValue.ToLower().Trim() + ","))
                                                            {
                                                                if (NextTemplate.Trim() != string.Empty)
                                                                    lsExecuteNextTemplate = NextTemplate.Trim();
                                                                else if (NextObject.Trim() != string.Empty)
                                                                    lsExecuteNextObject = NextObject.Trim();
                                                            }
                                                        }
                                                    }
                                                }
                                                #endregion // Check for Operator & Value columns - END

                                                lsCaseSensetiveValue = CaseConverstion(lsFieldNameValue);
                                                if (lsCaseSensetiveValue != "")
                                                {
                                                    System.Threading.Thread.Sleep(1000);
                                                    SendKeys.SendWait(lsCaseSensetiveValue);
                                                }
                                                //
                                                // Get Popup Window Title
                                                goProcess.WaitForInputIdle();
                                                string lsWindowTitle = GetActiveWindowTitle();
                                                //
                                                string lsCompareString = string.Empty;
                                                string[] lsaBackTrackCommands = null;
                                                //
                                                for (int i = 0; i < result.Length; i++)
                                                {
                                                    if (action[i].ToUpper().Contains("MOUSE"))
                                                    {
                                                        HandleMouseEvent(action[i].ToString());
                                                    }
                                                    else if (action[i].ToUpper().Contains("CHECK"))
                                                    {
                                                        lsaBackTrackCommands = action[i].Split('!');
                                                        //0= > For Checking the Value of First Index If it contains "CHECK(" then Replcate with Empty String
                                                        lsCompareString = lsaBackTrackCommands[0].ToUpper().Replace("CHECK(", "").Replace(")", "").Trim();
                                                        lsaBackTrackCommands[lsaBackTrackCommands.Length - 1] = lsaBackTrackCommands[lsaBackTrackCommands.Length - 1].Replace(")", "").Trim();
                                                    }
                                                    else
                                                    {
                                                        if (action[i].ToUpper().Trim() == "REPOSITION")
                                                        {
                                                            RepositionWindow(GetForegroundWindow());
                                                        }
                                                        if (result[i].ActionName != "")
                                                        {
                                                            Result += GetSendKey(result[i]);
                                                        }
                                                    }
                                                }
                                                if (lsWindowTitle != null && lsaBackTrackCommands != null)
                                                {
                                                    if (lsCompareString.ToUpper().Trim() == lsWindowTitle.ToUpper().Trim())
                                                    {
                                                        //throw new Exception("CHECK FAILED");
                                                        InputKeys[] BackTrack = GetInputValue("dtControlFile", lsaBackTrackCommands);
                                                        for (int i = 0; i < BackTrack.Length; i++)
                                                        {
                                                            if (BackTrack[i].ActionName != "" && BackTrack[i].ActionName != null)
                                                            {
                                                                Result += GetSendKey(BackTrack[i]);
                                                            }
                                                        }
                                                        SendKey(Result, 100);
                                                        Result = "";
                                                        goto ENDNegativeScenario;
                                                    }
                                                }

                                                SendKey(Result, 200);

                                                // Create Log 
                                                LogDetails("\nSequence:" + CurrObject + " , ActionKeyword:" + ActionKeyWords + " , Action:" + Result);

                                                //To handle ESC action keyword
                                            EscapeSequence: Console.WriteLine("");
                                            }
                                            else if (CurrTemplate != "")
                                            {
                                                ExecuteTemplateSequence(CurrTemplate, liInputCount, out IsNegativeScenario);
                                                if (IsNegativeScenario)
                                                    goto ENDNegativeScenario;
                                            }
                                        }
                                    }
                                }
                                #endregion // Call Sequence - END
                            // 
                            // To handle Negative scenario
                            ENDNegativeScenario: Console.WriteLine("");
                            }
                            #endregion // Sequence Template Execution - END

                            FileInfo info = new FileInfo(InputFiles[inpCount]);
                            string lsInputPath = Path.GetDirectoryName(InputFiles[inpCount]);
                            string lsPathToMove = lsInputPath + @"\Complete\" + info.Name.Replace(".", "_" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".");
                            info.MoveTo(lsPathToMove);
                        }
                        else
                        {

                            //Get The Information about ###      COPY_TO_ERROR_FILE   ######

                            var ColumnIdentiferName = from identifername in clsConnection.xrgds.Tables["dtListObjects"].AsEnumerable()
                                                      where identifername.Field<object>("Comments") != null &&
                                                      identifername.Field<string>("Comments").Trim().ToUpper() == "COPY_TO_ERROR_FILE"
                                                      select new
                                                      {
                                                          ColumnMappingfromInputFile = identifername.Field<object>("Column Mapping from Input File") != null ?
                                                          identifername.Field<string>("Column Mapping from Input File") : ""
                                                      };
                            //if (ColumnIdentiferName.ToList().Count == 1)
                            //{
                            // Create Failed Files Containing Error Records Only
                            string lsDirectoryPath = string.Empty;
                            string lsPathToMove = string.Empty;
                            FileInfo FileInvalid = new FileInfo(InputFiles[inpCount]);
                            lsDirectoryPath = Path.GetDirectoryName(InputFiles[inpCount]);
                            lsPathToMove = lsDirectoryPath + @"\Failed\" + FileInvalid.Name.Replace(".", "_Error_" + InitialDirectoryName + "_" + lsProcessIdName + "_" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".");
                            FileInvalid.CopyTo(lsPathToMove);


                            XLS.Application loXlsApplication;
                            XLS._Workbook loXlsWorkbook;
                            XLS._Worksheet loXlsSheet;
                            XLS.Range loXlsRange;
                            object misvalue = System.Reflection.Missing.Value;
                            //Start Excel and get Application object.
                            loXlsApplication = new Microsoft.Office.Interop.Excel.Application();
                            loXlsApplication.Visible = false;
                            loXlsApplication.DisplayAlerts = false;

                            //Get a new workbook.
                            loXlsWorkbook = (Microsoft.Office.Interop.Excel._Workbook)(loXlsApplication.Workbooks.Add(""));
                            loXlsSheet = (Microsoft.Office.Interop.Excel._Worksheet)loXlsWorkbook.ActiveSheet;

                            loXlsSheet.Cells[1, 1] = "ERROR_IDENTIFIER";
                            loXlsSheet.Cells[1, 2] = "ERROR_DESCRIPTION";

                            //for (int dtInColCount = 0; dtInColCount < clsConnection.xrgds.Tables["dtInputFile"].Columns.Count; dtInColCount++)
                            //{
                            //    loXlsSheet.Cells[1, dtInColCount + 1] = clsConnection.xrgds.Tables["dtInputFile"].Columns[dtInColCount].ColumnName.Replace("#", ".");
                            //}

                            #region <=============== To Make Excel Column header Bold ==========================>
                            //Format A1:D1 as bold, vertical alignment = center.
                            //loXlsSheet.get_Range("A1", "" + ((char)(65 + dtInputtotColumCount)).ToString() + "1").Font.Bold = true;
                            //loXlsSheet.get_Range("A1", "" + ((char)(65 + dtInputtotColumCount)).ToString() + "1").VerticalAlignment
                            //= Microsoft.Office.Interop.Excel.XlVAlign.xlVAlignCenter;
                            #endregion


                            DataTable dtInvalidRecords = checkRows.CopyToDataTable<DataRow>();
                            int dtInputtotRowsCount = dtInvalidRecords.Rows.Count;
                            //Imnplement for Only two Column thats Error_Identifier and Error_Description
                            int dtInputtotColumCount = 2;// clsConnection.xrgds.Tables["dtInputFile"].Columns.Count;  
                            string[,] XlinvalidRecords = new string[checkRows.ToList().Count(), dtInputtotColumCount];
                            string strGetRangeValue = string.Empty;
                            int liColumnCount = 0;
                            for (int liRow = 0; liRow < dtInvalidRecords.Rows.Count; liRow++)
                            {
                                liColumnCount = 0;
                                for (int liCol = 0; liCol < clsConnection.xrgds.Tables["dtInputFile"].Columns.Count; liCol++)
                                {
                                    if (dtInvalidRecords.Columns[liCol].ColumnName.ToString().ToLower().Trim() == ColumnIdentiferName.ToList()[0].ColumnMappingfromInputFile.Trim().ToLower()
                                        || dtInvalidRecords.Columns[liCol].ColumnName.ToString().ToLower().Trim() == "validation_error")
                                    {
                                        XlinvalidRecords[liRow, liColumnCount] = Convert.ToString(dtInvalidRecords.Rows[liRow][liCol]).Trim();
                                        liColumnCount++;
                                    }
                                }
                            }

                            if (dtInputtotColumCount == 26)
                            {
                                strGetRangeValue = ((char)(64 + dtInputtotColumCount)).ToString() + "" + (dtInputtotRowsCount + 1);
                                loXlsSheet.get_Range("A1", "" + ((char)(64 + dtInputtotColumCount)).ToString() + "1").Font.Bold = true;
                            }
                            else if (dtInputtotColumCount >= 26)
                            {
                                //dtInputtotColumCount-1 : for #N/A Condition
                                //Where (dtInputtotColumCount-1)-26)) AZ3 Condition
                                strGetRangeValue = "A" + ((char)(65 + (dtInputtotColumCount - 1) - 26)).ToString() + "" + (dtInputtotRowsCount + 1);
                                loXlsSheet.get_Range("A1", "" + ((char)(65 + (dtInputtotColumCount - 1) - 26)).ToString() + "1").Font.Bold = true;
                            }
                            else if (dtInputtotColumCount < 26)
                            {
                                strGetRangeValue = ((char)(65 + dtInputtotColumCount - 1)).ToString() + "" + (dtInputtotRowsCount + 1);
                                loXlsSheet.get_Range("A1", "" + ((char)(65 + dtInputtotColumCount)).ToString() + "1").Font.Bold = true;
                            }

                            //Fill A2:B6 with an array of values (First and Last Names).
                            loXlsSheet.get_Range("A2", strGetRangeValue).Value2 = XlinvalidRecords;
                            ////AutoFit columns A:D.
                            loXlsRange = loXlsSheet.get_Range("A1", "D" + dtInputtotColumCount);
                            loXlsRange.EntireColumn.AutoFit();

                            loXlsApplication.Visible = false;
                            loXlsApplication.UserControl = false;

                            loXlsWorkbook.SaveAs(lsPathToMove, Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing,
                                Type.Missing, Type.Missing, XLS.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing,
                                Type.Missing, Type.Missing);
                            loXlsWorkbook.Close(false, Type.Missing, Type.Missing);
                            loXlsApplication.Quit();
                            if (loXlsApplication != null)
                            {
                                Process[] pProcess;
                                pProcess = System.Diagnostics.Process.GetProcessesByName("Excel");
                                pProcess[0].Kill();
                            }
                            //
                            System.Threading.Thread.Sleep(2000);
                            //
                            FileInfo info = new FileInfo(InputFiles[inpCount]);
                            lsDirectoryPath = Path.GetDirectoryName(InputFiles[inpCount]);
                            lsPathToMove = lsDirectoryPath + @"\Failed\" + info.Name.Replace(".", "_" + DateTime.Now.ToString("ddMMyyyyhhmmss") + ".");
                            info.MoveTo(lsPathToMove);
                            //}
                        }
                    }
                }
            }
            catch (Exception e)
            {
                LogDetails("\n--------\n ERROR: " + e.Message.ToString() + "\n--------\n STACK TRACE:" + e.StackTrace.ToString());
                return;
                //throw new Exception(e.Message + " - " + e.InnerException.ToString());
            }
            finally
            {
                xlsSheet = null;
                xlsWorkbook = null;
                //myapp = null;
            }
        }

        // Function to execute template sequences
        private void ExecuteTemplateSequence(string CurrTemplate, int liInputCount, out Boolean lbIsNegativeScenario)
        {
            lbIsNegativeScenario = false;
            string lsResult = string.Empty;
            string lsExecNextSequence = string.Empty;
            string lsFieldName = string.Empty;
            string lsRecordValue = string.Empty;
            string[] action;
            InputKeys[] result;

            var TemplateDef = from tempdef in clsConnection.xrgds.Tables["dtTemplateDefn"].AsEnumerable()
                              where tempdef.Field<string>("Template") == CurrTemplate
                              select new
                              {
                                  TemplateName = tempdef.Field<object>("Template") != null ? tempdef.Field<string>("Template") : "",
                                  CurrSequence = tempdef.Field<object>("Curr# Sequence") != null ? tempdef.Field<string>("Curr# Sequence") : "",
                                  CurrSequenceDataType = tempdef.Field<object>("Curr# Sequence Data Type") != null ? tempdef.Field<string>("Curr# Sequence Data Type") : "",
                                  Operator = tempdef.Field<object>("Operator") != null ? tempdef.Field<string>("Operator") : "",
                                  Value = tempdef.Field<object>("Value") != null ? tempdef.Field<string>("Value") : "",
                                  ActionKeyWords = tempdef.Field<object>("ActionKeyWords") != null ? tempdef.Field<string>("ActionKeyWords") : "",
                                  NextSequence = tempdef.Field<object>("Next# Sequence") != null ? tempdef.Field<string>("Next# Sequence") : ""
                              };
            foreach (var templateSeqItem in TemplateDef)
            {
                if (lsExecNextSequence.Trim() == string.Empty || lsExecNextSequence.ToLower().Trim() == templateSeqItem.CurrSequence.ToLower().Trim())
                {
                    if (templateSeqItem.ActionKeyWords.Contains("|"))
                    {
                        action = clsConnection.GetCommands(templateSeqItem.ActionKeyWords);
                    }
                    else
                    {
                        action = clsConnection.GetCommands(templateSeqItem.ActionKeyWords);
                    }
                    result = GetInputValue("dtControlFile", action);
                    lsFieldName = GetListObjectDetails(templateSeqItem.CurrSequence, "dtListObjects").Trim();
                    //
                    lsRecordValue = string.Empty;
                    if (GetDataTypeofObject(templateSeqItem.CurrSequence, "dtListObjects") == true)
                    {
                        lsRecordValue = lsFieldName.Trim();
                    }
                    else
                    {
                        lsRecordValue = GetTableDetails(lsFieldName, "dtInputFile", liInputCount).Trim();
                    }
                    if (templateSeqItem.Operator != null && templateSeqItem.Value != null && templateSeqItem.NextSequence != null)
                    {
                        if (templateSeqItem.Operator.Trim() == "=")
                        {
                            if (lsRecordValue.ToLower().Trim() == templateSeqItem.Value.ToLower().Trim())
                            {
                                lsExecNextSequence = templateSeqItem.NextSequence.Trim();
                            }
                        }
                        else if (templateSeqItem.Operator.Trim() == "<>")
                        {
                            if (lsRecordValue.ToLower().Trim() != templateSeqItem.Value.ToLower().Trim())
                            {
                                lsExecNextSequence = templateSeqItem.NextSequence.Trim();
                            }
                        }
                        else if (templateSeqItem.Operator.Trim() == "<")
                        {
                            if (Convert.ToInt16(lsRecordValue.Trim()) < Convert.ToInt16(templateSeqItem.Value.Trim()))
                            {
                                lsExecNextSequence = templateSeqItem.NextSequence.Trim();
                            }
                        }
                        else if (templateSeqItem.Operator.Trim() == ">")
                        {
                            if (Convert.ToInt16(lsRecordValue.Trim()) > Convert.ToInt16(templateSeqItem.Value.Trim()))
                            {
                                lsExecNextSequence = templateSeqItem.NextSequence.Trim();
                            }
                        }
                        else if (templateSeqItem.Operator.Trim().ToLower() == "like")
                        {
                            // LIKE condition Check >> Eg. // INDIA  >> INDIAN
                            if (templateSeqItem.Value.Trim().ToLower().Contains(lsRecordValue.Trim().ToLower()))
                            {
                                lsExecNextSequence = templateSeqItem.NextSequence.Trim();
                            }
                        }
                        else if (templateSeqItem.Operator.Trim().ToLower() == "in")
                        {
                            // IN condition Check >> Eg. // ,a, >> ,a,b,c,
                            string lsOperatorValue = "," + templateSeqItem.Value.ToLower().Trim() + ",";
                            if (lsOperatorValue.Contains("," + lsRecordValue.ToLower().Trim() + ","))
                            {
                                lsExecNextSequence = templateSeqItem.NextSequence.Trim();
                            }
                        }
                    }

                    lsRecordValue = CaseConverstion(lsRecordValue);
                    if (lsRecordValue.Trim() != "")
                    {
                        System.Threading.Thread.Sleep(1000);
                        SendKeys.SendWait(lsRecordValue);
                    }

                    string lsCompareString = string.Empty;
                    string[] BackTrackCommands = null;
                    //
                    // Get popup window title
                    goProcess.WaitForInputIdle();
                    string Title = GetActiveWindowTitle();
                    //
                    for (int i = 0; i < result.Length; i++)
                    {
                        if (action[i].ToUpper().Contains("MOUSE"))
                        {
                            HandleMouseEvent(action[i].ToString());
                        }
                        else if (action[i].ToUpper().Contains("CHECK"))
                        {
                            BackTrackCommands = action[i].Split('!');
                            //0= > For Checking the Value of First Index If it contains "CHECK(" then Replcate with Empty String
                            lsCompareString = BackTrackCommands[0].ToUpper().Replace("CHECK(", "").Replace(")", "").Trim();
                            BackTrackCommands[BackTrackCommands.Length - 1] = BackTrackCommands[BackTrackCommands.Length - 1].Replace(")", "").Trim();
                        }
                        if (result[i].ActionName != "" && result[i].ActionName != null)
                        {
                            lsResult += GetSendKey(result[i]);
                        }
                    }
                    if (Title != null && BackTrackCommands != null)
                    {
                        if (lsCompareString.ToUpper().Trim() == Title.ToUpper().Trim())
                        {
                            //throw new Exception("CHECK FAILED");
                            InputKeys[] BackTrack = GetInputValue("dtControlFile", BackTrackCommands);
                            for (int i = 0; i < BackTrack.Length; i++)
                            {
                                if (BackTrack[i].ActionName != "" && BackTrack[i].ActionName != null)
                                {
                                    lsResult += GetSendKey(BackTrack[i]);
                                }
                            }
                            SendKey(lsResult, 100);
                            lsResult = "";

                            //To handle goto ENDNegativeScenario;
                            lbIsNegativeScenario = true;
                            return;
                        }
                    }





                    ///14032016-08-21
                    ///
                    //this.Activate();
                    //this.Focus();
                    //SetFocus(new HandleRef(null, gptrHandler));
                    //ShowWindow(gptrHandler, SW_RESTORE);

                    ///


                    //
                    // Execute Concatenated Events 
                    if (gbIsUserLoggedIn)
                    {
                        SendKey(lsResult, 200);
                        if (!goTempProcess.HasExited)
                            goTempProcess.Kill();
                    }
                    else
                        SendKey(lsResult, 1500);
                    //
                    LogDetails("\nTemplate :" + CurrTemplate + " , Sequence:" + templateSeqItem.CurrSequence + " , ActionKeyword:" + templateSeqItem.ActionKeyWords + " , Action:" + lsResult);
                    //
                    lsResult = "";
                }
            }
            lsExecNextSequence = "";
        }

        // Log details on window form
        private void LogDetails(string lsLogMessage)
        {
            rchtxtLogDetails.Text += lsLogMessage;
        }

        public void GetInputFiles(string ProcessFileName, int FileCount)
        {
            try
            {
                InputFiles.Clear();
                if (ProcessFileName.Contains("ProcessID-" + (FileCount + 1) + ".xls"))
                {
                    foreach (string d in Directory.GetFiles(clsConnection.ProcessFilePath + @"InputFile\ProcessID-" + (FileCount + 1)))
                    {
                        InputFiles.Add(d);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void GetDirectoryforStrutures(string lsDir)
        {
            try
            {
                //Get the inital Policy Name Folder
                clsConnection.GetPolicyBusinessName();
                var ColumnName = from processname in clsConnection.xrgds.Tables["dtControlFile"].AsEnumerable()
                                 select new
                                 {
                                     ProcessFolderName = processname.Field<object>("Process Folder Name") != null ? processname.Field<string>("Process Folder Name") : ""
                                 };
                InitialDirectoryName = ColumnName.Take(1).ToList()[0].ProcessFolderName;
                foreach (string lsdirectoryName in Directory.GetDirectories(lsDir))
                {

                    DirectoriesNames.Add(lsdirectoryName);
                    if (lsdirectoryName.Contains(InitialDirectoryName))
                    {
                        foreach (string lsFileName in Directory.GetFiles(lsdirectoryName))
                        {
                            Processfiles.Add(lsFileName);
                        }
                    }
                }
            }
            catch (Exception exException)
            {
                throw new Exception(exException.Message.Trim());
            }
        }

        public string GetActiveWindowTitle()
        {
            const int nChars = 256;
            StringBuilder Buff = new StringBuilder(nChars);
            IntPtr handle = GetForegroundWindow();
            if (GetWindowText(handle, Buff, nChars) > 0)
            {
                return Buff.ToString().Trim();
            }
            return null;
        }

        public InputKeys[] GetInputValue(string dtName, string[] input)
        {
            InputKeys[] result = new InputKeys[input.Length];
            for (int i = 0; i < input.Length; i++)
            {
                foreach (DataRow dr in clsConnection.xrgds.Tables[dtName].Rows)
                {
                    string[] ActionValue = input[i].ToString().Split('-');
                    string a1 = dr[2].ToString();

                    if (ActionValue[0].ToString() == "RETURN")
                    {
                        //Environment.Exit(0);
                        //Returns the Input to Operating System Successful Termination
                        throw new Exception("RETURN");
                    }
                    else if (dr[2].ToString() == ActionValue[0].ToString())
                    {
                        result[i].ActionName = dr["Action"].ToString();
                        if (ActionValue.Length > 1)
                        {
                            result[i].Times = Convert.ToInt32(ActionValue[ActionValue.Length - 1]);
                        }
                        else
                        {
                            result[i].Times = 1;
                        }
                        break;
                    }
                }
                if (input[i].Length == 1)
                {
                    result[i].ActionName = input[i].ToString();
                    result[i].Times = 1;
                }
            }
            return result;

        }

        // To keep Caps Lock key Off
        public void DisableCapsKey()
        {
            if (Control.IsKeyLocked(Keys.CapsLock))
            {
                //Console.WriteLine("Caps Lock key is ON.  We'll turn it off");
                keybd_event(0x14, 0x45, KEYEVENTF_EXTENDEDKEY, (UIntPtr)0);
                keybd_event(0x14, 0x45, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, (UIntPtr)0);
                SendKeys.SendWait("{CAPSLOCK}");
            }
            else
            {
                Console.WriteLine("Caps Lock key is OFF");
            }
        }

        public string GetSendKey(InputKeys Keys)
        {
            string Value = string.Empty;
            for (int i = 0; i < Keys.Times; i++)
            {
                Value += Keys.ActionName;
            }
            return Value;
        }

        public void SendKey(string Value, int Timeout)
        {
            System.Threading.Thread.Sleep(Timeout);
            SendKeys.SendWait(Value);
        }

        public bool GetDataTypeofObject(string ObjectLabel, string TbName)
        {
            var details = from dttype in clsConnection.xrgds.Tables[TbName].AsEnumerable()
                          where dttype.Field<string>("Object Label").Equals(ObjectLabel) == true
                          && dttype.Field<string>("Data Type").Equals("Data") == true
                          select new
                          {
                              ObjectLabel = dttype.Field<string>("Object Label"),
                              DataType = dttype.Field<string>("Data Type"),
                              MandatoryinAppln = dttype.Field<string>("Mandatory in Appln"),
                              ColumnMappingfromInputFile = dttype.Field<string>("Column Mapping from Input File"),
                              Validations = dttype.Field<string>("Validations")
                          };
            if (details.ToList().Count() >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }

            #region <=============== Implementation of Same Logic using for loop ================>
            //bool Result = false;
            //foreach (DataRow dr in clsConnection.xrgds.Tables[TbName].Rows)
            //{
            //    if (dr["Object Label"].ToString() == ObjectLabel && dr["Data Type"].ToString() == "Data")
            //    {
            //        Result = true;
            //        break;
            //    }
            //}
            //return Result;
            #endregion
        }

        public string GetListObjectDetails(string ObjectLabel, string TbName)
        {
            var details = from dttype in clsConnection.xrgds.Tables[TbName].AsEnumerable()
                          where dttype.Field<string>("Object Label").Equals(ObjectLabel) == true
                          select new
                          {
                              ColumnMappingfromInputFile = dttype.Field<string>("Column Mapping from Input File")
                          };
            return (details.FirstOrDefault().ColumnMappingfromInputFile == null ? "" : details.FirstOrDefault().ColumnMappingfromInputFile);


            #region <=============== Implementation of Same Logic using for loop ================>
            //string Result = "";
            //foreach (DataRow dr in clsConnection.xrgds.Tables[TbName].Rows)
            //{
            //    if (dr["Object Label"].ToString() == ObjectLabel)
            //    {
            //        Result = dr["Column Mapping from Input File"].ToString();
            //        break;
            //    }
            //}
            //return Result;
            #endregion
        }

        public string GetTableDetails(string ColumnName, string TbName, int RowPosition = 0)
        {
            string Value = string.Empty;
            if (ColumnName != "")
            {
                DataRow dr = clsConnection.xrgds.Tables[TbName].Rows[RowPosition];
                Value = dr[ColumnName].ToString();
                //break;
            }
            return Value;
        }

        public string CaseConverstion(string Value)
        {
            string NewValue = "";
            foreach (char ch in Value.ToCharArray())
            {
                if (Char.IsUpper(ch) == true)
                {
                    NewValue += "+" + Char.ToLower(ch).ToString();
                }
                else
                {
                    NewValue += ch.ToString();
                }
            }
            return NewValue;
        }

        public void HandleMouseEvent(string Value)
        {
            //string r = string.Empty;
            int x = 0;
            int y = 0;
            int Count = 0;
            Boolean IsLeft = false;
            Boolean IsRight = false;
            //if (Value.Contains("-R"))
            //{
            //    r = Value.Replace("MOUSE-R(", "").Replace(")","");
            //}
            //if (Value.Contains("-L"))
            //{
            //    r = Value.Replace("MOUSE-L(", "").Replace(")", "");
            //}
            Value = Value.Replace("MOUSE(", "").Replace(")", "");
            GetCoordinates(Value, out x, out y, out Count, out IsLeft, out IsRight);
            DoMouseClick(x, y, IsLeft, IsRight, Count);
        }

        private void GetCoordinates(string r, out int x, out int y, out int Count, out Boolean IsLeft, out Boolean IsRight)
        {
            x = 0; y = 0; Count = 0; IsLeft = false; IsRight = false;
            string[] Coordinates = r.Split(',');

            if (Coordinates.Length > 3)
            {
                if (Coordinates[0].ToString().Trim() == "L")
                    IsLeft = true;
                else if (Coordinates[0].ToString().Trim() == "R")
                    IsRight = true;
                x = Convert.ToInt16(Coordinates[1].ToString());
                y = Convert.ToInt16(Coordinates[2].ToString());
                Count = Convert.ToInt16(Coordinates[3].ToString());
            }
        }

        public bool IsMinLength(string ValidationRule, string ValueToCompare)
        {
            try
            {
                if (ValueToCompare.Length >= Convert.ToInt32(ValidationRule.Substring(ValidationRule.IndexOf(",") + 1).Trim()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Min Length :" + ex.Message.ToString());
            }
        }

        public bool IsMaxLength(string ValidationRule, string ValueToCompare)
        {
            try
            {
                if (ValueToCompare.Length <= Convert.ToInt32(ValidationRule.Substring(ValidationRule.IndexOf(",") + 1).Trim()))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception e)
            {
                throw new Exception("Max Length :" + e.Message);
            }
        }

        public bool IsOnlyCharacter(string ValueToCompare)
        {
            bool Result = false;
            foreach (char ch in ValueToCompare.ToCharArray())
            {
                if (Char.IsLetter(ch))
                {
                    Result = true;
                }
                else
                {
                    Result = false;
                    break;
                }
            }
            return Result;
        }

        public bool IsOnlyDigit(string ValueToCompare)
        {
            bool Result = false;
            foreach (char ch in ValueToCompare.ToCharArray())
            {
                if (Char.IsNumber(ch))
                {
                    Result = true;
                }
                else
                {
                    Result = false;
                    break;
                }
            }
            return Result;
        }

        public bool IsAlphaNumeric(string ValueToCompare)
        {
            Regex pattern = new Regex(@"^[a-zA-Z0-9\s]+$");
            if (ValueToCompare != null && ValueToCompare != "")
            {
                return pattern.IsMatch(ValueToCompare);
            }
            return true;
        }

        public bool DATE_FORMAT(string strPatterntoCheck, string strDate)
        {
            DateTime OutDate;
            if (strPatterntoCheck.Contains(','))
            {
                if (DateTime.TryParseExact(strDate, strPatterntoCheck.Replace("DATE_FORMAT,", "").Trim(), null, System.Globalization.DateTimeStyles.None, out OutDate) == true)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {

                if (DateTime.TryParse(strDate, out OutDate))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool IsNumeric(string strInput)
        {
            int i = 0;
            return strInput.ToCharArray().All(c => int.TryParse(c.ToString(), out i));
        }

        public bool IsUnique(string ColumnName, string TableName)
        {
            var inputfile = from records in clsConnection.xrgds.Tables[TableName].AsEnumerable()
                            group records by records.Field<object>(ColumnName) into grouped
                            where grouped.Count() > 1
                            select grouped.Key;
            return (inputfile.ToList().Count() >= 1 ? false : true);
        }

        public bool IsEmpty(string strValue)
        {
            if (strValue.Trim() == string.Empty)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public bool ValidationForField(string strCheckValue, string strRegularExpression)
        {
            return Regex.IsMatch(strCheckValue, strRegularExpression);
        }

        public void CheckforValidation()
        {
            //string IsMinLength = @"^.{0,8}$";
            string lrOnlyCharacter = @"/^[a-zA-Z\s]+$/";
            string lrOnlyDigit = @"/^[0-9\s]+$/";
            string lrAlphaNumeric = @"^[a-zA-Z0-9]+$";
            string lrNumeric = @"^(?:(?:[+\-]?\$?)|(?:\$?[+\-]?))?(?:(?:\d{1,3}(?:(?:,\d{3})|(?:\d))*(?:\.(?:\d*|\d+[eE][+\-]\d+))?)|(?:\.\d+(?:[eE][+\-]\d+)?))$";
            //
            string strValidationResult = string.Empty;
            string[] ValidationMethod = null;
            //
            try
            {

                for (int i = 0; i < clsConnection.xrgds.Tables["dtInputFile"].Rows.Count; i++)
                {
                    DataRow drInputFile = clsConnection.xrgds.Tables["dtInputFile"].Rows[i];
                    ResultforRow[] StructResRows = new ResultforRow[clsConnection.xrgds.Tables["dtInputFile"].Columns.Count];
                    string ColumnName = string.Empty;
                    //
                    //This will skip last column because two of them are ValidationResult and Validation_Error
                    for (int liColumn = 0; liColumn < clsConnection.xrgds.Tables["dtInputFile"].Columns.Count - 2; liColumn++)
                    {
                        ColumnName = clsConnection.xrgds.Tables["dtInputFile"].Columns[liColumn].ColumnName.ToString();
                        var lstObject = from listobj in clsConnection.xrgds.Tables["dtListObjects"].AsEnumerable()
                                        where listobj.Field<object>("Column Mapping from Input File") != null
                                        && (listobj.Field<object>("Validations") != null || listobj.Field<string>("Mandatory in Appln").Trim().ToLower().Equals("yes"))
                                        && listobj.Field<string>("Data Type").Equals("Data") == false
                                        && listobj.Field<string>("Column Mapping from Input File").Equals(ColumnName) == true
                                        select new
                                        {
                                            ProcessID = listobj.Field<string>("Process ID"),
                                            Template = listobj.Field<string>("Template"),
                                            ObjectLabel = listobj.Field<string>("Object Label"),
                                            DataType = listobj.Field<string>("Data Type"),
                                            MandatoryInAppln = listobj.Field<string>("Mandatory in Appln"),
                                            Comments = listobj.Field<string>("Comments"),
                                            ColumnMappingfromInputFile = listobj.Field<string>("Column Mapping from Input File"),
                                            Validations = listobj.Field<object>("Validations") != null ? listobj.Field<string>("Validations") : ""
                                        };
                        if (lstObject.ToList().Count > 0)
                        {
                            foreach (var item in lstObject)
                            {
                                string lsColumnValue = drInputFile[ColumnName].ToString().Trim();
                                ValidationDetails[] laValDetails = null;
                                //
                                #region // Check for Validations column - START
                                if (!string.IsNullOrEmpty(item.Validations.Trim()))
                                {
                                    ValidationMethod = item.Validations.Trim().Split('|');
                                    laValDetails = new ValidationDetails[ValidationMethod.Length];
                                    for (int icount = 0; icount < ValidationMethod.Length; icount++)
                                    {
                                        bool lbIsValid = false;
                                        if (ValidationMethod[icount].ToLower().Contains("max_length"))
                                        {
                                            lbIsValid = IsMaxLength(ValidationMethod[icount], lsColumnValue);
                                        }
                                        else if (ValidationMethod[icount].ToLower().Contains("min_length"))
                                        {
                                            lbIsValid = IsMinLength(ValidationMethod[icount], lsColumnValue);
                                        }
                                        else if (ValidationMethod[icount].ToLower().Contains("alpha_numeric"))
                                        {
                                            //Result = IsAlphaNumeric(dr[ColumnName].ToString());
                                            lbIsValid = ValidationForField(lsColumnValue, lrAlphaNumeric);
                                        }
                                        else if (ValidationMethod[icount].ToLower().Contains("only_character"))
                                        {
                                            //Result = IsOnlyCharacter(dr[ColumnName].ToString());
                                            lbIsValid = ValidationForField(lsColumnValue, lrOnlyCharacter);
                                        }
                                        else if (ValidationMethod[icount].ToLower().Contains("date_format"))
                                        {
                                            lbIsValid = DATE_FORMAT(ValidationMethod[icount].Trim(), lsColumnValue);
                                        }
                                        else if (ValidationMethod[icount].ToLower().Contains("isnumeric"))
                                        {
                                            //Result = IsNumeric(dr[ColumnName].ToString());
                                            lbIsValid = ValidationForField(lsColumnValue, lrNumeric);
                                        }
                                        else if (ValidationMethod[icount].ToLower().Contains("isunique"))
                                        {
                                            lbIsValid = IsUnique(lsColumnValue, "dtInputFile");
                                        }
                                        else if (ValidationMethod[icount].ToLower().Contains("isempty"))
                                        {
                                            lbIsValid = IsEmpty(lsColumnValue);
                                        }
                                        laValDetails[icount] = new ValidationDetails()
                                        {
                                            FieldName = ColumnName,
                                            FieldValue = lsColumnValue,
                                            ValidationName = ValidationMethod[icount],
                                            Status = lbIsValid
                                        };
                                        if (!lbIsValid)
                                        {
                                            string lsErrorFieldName = ColumnName + " field failed in validations: ";
                                            if (!strValidationResult.ToLower().Contains(lsErrorFieldName.ToLower()))
                                            {
                                                strValidationResult += "\n" + lsErrorFieldName;
                                            }
                                            strValidationResult += ValidationMethod[icount] + "; ";
                                        }
                                    }
                                }
                                #endregion // Check for Validations column - START
                                //
                                #region // Check for Mandatory in Appln column - START
                                bool lbMandatoryInAppln = item.MandatoryInAppln.Trim().ToLower() == "yes" ? true : false;
                                if (lbMandatoryInAppln)
                                {
                                    if (string.IsNullOrEmpty(lsColumnValue.Trim()))
                                        strValidationResult += "\n" + ColumnName + " is Mandatory field but does not have a value.";
                                }
                                #endregion // Check for Mandatory in Appln column - END
                                //
                                StructResRows[liColumn].ColumnName = ColumnName;
                                StructResRows[liColumn].Result = laValDetails != null ? (laValDetails.All(c => c.Status == true)) : true;
                            }
                        }
                        else
                        {
                            StructResRows[liColumn].ColumnName = ColumnName;
                            StructResRows[liColumn].Result = true;
                        }

                        #region <=========== Old Logic for Implemenation of Validation ==================>
                        //var listObject = from listobj in clsConnection.xrgds.Tables["dtListObjects"].AsEnumerable()
                        //                 where listobj.Field<object>("Column Mapping from Input File") != null
                        //                 && listobj.Field<object>("Validations") != null
                        //                 && listobj.Field<string>("Data Type").Equals("Data") == false
                        //                 select new
                        //                 {
                        //                     ProcessID = listobj.Field<string>("Process ID"),
                        //                     Template = listobj.Field<string>("Template"),
                        //                     ObjectLabel = listobj.Field<string>("Object Label"),
                        //                     DataType = listobj.Field<string>("Data Type"),
                        //                     MandatoryInAppln = listobj.Field<string>("Mandatory in Appln"),
                        //                     Comments = listobj.Field<string>("Comments"),
                        //                     ColumnMappingfromInputFile = listobj.Field<string>("Column Mapping from Input File"),
                        //                     Validations = listobj.Field<string>("Validations")
                        //                 };


                        //foreach (var lstobj in listObject)
                        //{

                        //    ValidationMethod = lstobj.Validations.Split('|');
                        //    ValidationDetails[] details = new ValidationDetails[ValidationMethod.Length];
                        //    var Inputdata = from input in clsConnection.xrgds.Tables["dtInputFile"].AsEnumerable()
                        //                    where lstobj.DataType != null && lstobj.DataType != "Data"
                        //                    select new { SearchByID = input.Field<string>(lstobj.ColumnMappingfromInputFile) };
                        //    foreach (var inpdt in Inputdata)
                        //    {
                        //        for (int i = 0; i < ValidationMethod.Length; i++)
                        //        {
                        //            bool Result = false;
                        //            if (ValidationMethod[i].Contains("MaxLength"))
                        //            {
                        //                Result = IsMaxLength(ValidationMethod[i], inpdt.SearchByID);
                        //            }
                        //            else if (ValidationMethod[i].Contains("AlphaNeumeric"))
                        //            {
                        //                Result = IsAlphaNumeric(ValidationMethod[i]);
                        //            }
                        //            else if (ValidationMethod[i].Contains("OnlyCharacter"))
                        //            {
                        //                Result = IsOnlyCharacter(ValidationMethod[i]);
                        //            }
                        //            details[i] = new ValidationDetails()
                        //            {
                        //                FieldName = lstobj.ColumnMappingfromInputFile,
                        //                FieldValue = inpdt.SearchByID,
                        //                ValidationName = ValidationMethod[i],
                        //                Status = Result
                        //            };
                        //        }
                        //        clsConnection.UpdateValidationResult(details);
                        //    }

                        //}
                        #endregion
                    }
                    bool result = StructResRows.Where(c => c.ColumnName != null).All(c => c.Result == true);
                    string lsPrimaryKeyFieldName = (from identifername in clsConnection.xrgds.Tables["dtListObjects"].AsEnumerable()
                                                    where identifername.Field<object>("Comments") != null &&
                                                    identifername.Field<string>("Comments").Trim().ToUpper() == "COPY_TO_ERROR_FILE"
                                                    select new
                                                    {
                                                        ColumnMappingfromInputFile = identifername.Field<object>("Column Mapping from Input File") != null ?
                                                        identifername.Field<string>("Column Mapping from Input File") : ""
                                                    }).ToList()[0].ColumnMappingfromInputFile.ToString().Trim();
                    clsConnection.UpdateValidationResult(new ValidationDetails()
                    {
                        FieldName = lsPrimaryKeyFieldName,
                        FieldValue = drInputFile[lsPrimaryKeyFieldName].ToString(),
                        Status = result,
                        Reason = strValidationResult,
                        ValidationName = string.Empty
                    });
                    strValidationResult = string.Empty;
                }
            }
            catch (Exception)
            {
            }
        }

        //Read Current Window's Left,Top,Right,Bottom values 
        public void RepositionWindow(IntPtr ReposPtr)
        {
            try
            {
                SendKeys.SendWait("% m");
                System.Threading.Thread.Sleep(1000);
                int x = Cursor.Position.X;
                int y = Cursor.Position.Y;
                SendKeys.SendWait("{UP}");
                System.Threading.Thread.Sleep(500);
                Rectangle rect = new Rectangle();
                //GetWindowRect(p.MainWindowHandle, out rect);
                GetWindowRect(ReposPtr, out rect);
                int xWidth = (rect.Width - rect.X) / 2;
                DoMouseClick(xWidth, 0, true, false, 1); //285
            }
            catch (Exception e)
            {
                throw new Exception(e.Message + " " + e.InnerException.ToString());
            }
        }

        //Function to move cursor & click
        public void DoMouseClick(int X, int Y, bool isLeftClick, bool isRightClick, int iCount)
        {
            this.Cursor = new Cursor(Cursor.Current.Handle);
            Cursor.Position = new Point(X, Y);
            for (int i = 1; i <= iCount; i++)
            {
                if (isLeftClick)
                {
                    mouse_event(MOUSEEVENTF_LEFTDOWN, (uint)X, (uint)Y, 0, 0);
                    mouse_event(MOUSEEVENTF_LEFTUP, (uint)X, (uint)Y, 0, 0);
                }
                if (isRightClick)
                {
                    mouse_event(MOUSEEVENTF_RIGHTDOWN, (uint)X, (uint)Y, 0, 0);
                    mouse_event(MOUSEEVENTF_RIGHTUP, (uint)X, (uint)Y, 0, 0);
                }
            }
            this.Cursor = null;
        }

        #region // Method definition for Single Key Events
        //public void OneTimePressKeys(string KeyName, int Timeout = 1000)
        //{
        //    KeyName = "{" + KeyName + "}";
        //    System.Threading.Thread.Sleep(Timeout);
        //    SendKeys.SendWait(KeyName);
        //}

        //public void LEFT(int NumberOfLeft = 1, int Timeout = 1000)
        //{
        //    string Left = "";
        //    for (int i = 0; i < NumberOfLeft; i++)
        //    {
        //        Left += "{LEFT}";
        //    }
        //    System.Threading.Thread.Sleep(Timeout);
        //    SendKeys.SendWait(Left);
        //}

        //public void RIGHT(int NumberOfRight = 1, int Timeout = 1000)
        //{
        //    string Right = "";
        //    for (int i = 0; i < NumberOfRight; i++)
        //    {
        //        Right += "{RIGHT}";
        //    }
        //    System.Threading.Thread.Sleep(Timeout);
        //    SendKeys.SendWait(Right);
        //}

        //public void DOWN(int NumberOfDown = 1, int Timeout = 1000)
        //{
        //    string Downs = "";
        //    for (int i = 0; i < NumberOfDown; i++)
        //    {
        //        Downs += "{DOWN}";
        //    }
        //    System.Threading.Thread.Sleep(Timeout);
        //    SendKeys.SendWait(Downs);
        //}

        //public void UP(int NumberOfUp = 1, int Timeout = 1000)
        //{
        //    string Ups = "";
        //    for (int i = 0; i < NumberOfUp; i++)
        //    {
        //        Ups += "{UP}";
        //    }
        //    System.Threading.Thread.Sleep(Timeout);
        //    SendKeys.SendWait(Ups);
        //}

        //public void TAB(int NumberOfTabs = 1, int Timeout = 1000)
        //{
        //    string Tabs = "";
        //    for (int i = 0; i < NumberOfTabs; i++)
        //    {
        //        Tabs += "{TAB}";
        //    }
        //    System.Threading.Thread.Sleep(Timeout);
        //    SendKeys.SendWait(Tabs);
        //}

        //public void ENTER(int NumberOfEnter = 1, int Timeout = 1000)
        //{
        //    string Enter = "";
        //    for (int i = 0; i < NumberOfEnter; i++)
        //    {
        //        Enter += "{ENTER}";
        //    }
        //    System.Threading.Thread.Sleep(Timeout);
        //    SendKeys.SendWait(Enter);
        //}

        //public void SPACE(int NumberOfSpace = 1, int Timeout = 1000)
        //{
        //    string Space = "";
        //    for (int i = 0; i < NumberOfSpace; i++)
        //    {
        //        Space += " ";
        //    }
        //    System.Threading.Thread.Sleep(Timeout);
        //    SendKeys.SendWait(Space);
        //}

        //public void CompoundArgument(string KeyType, string Key, int Timeout)
        //{
        //    string CompoundKey = "";
        //    KeyType = KeyType.ToUpper();
        //    if (KeyType == "CTRL")
        //    {
        //        CompoundKey = "^";
        //    }
        //    else if (KeyType == "SHIFT")
        //    {
        //        CompoundKey = "+";
        //    }
        //    else if (KeyType == "ALT")
        //    {
        //        CompoundKey = "%";
        //    }
        //    CompoundKey += Key;
        //    SendKeys.SendWait(CompoundKey);
        //    System.Threading.Thread.Sleep(Timeout);
        //}



        //Create Policy 
        //public void CreatePolicy(string SheetName)
        //{
        //    try
        //    {
        //        xlsSheet = (XLS.Worksheet)xlsWorkbook.Worksheets.get_Item("CreatePolicy");
        //        string lsAdvSearchCriteria = CellBelowData(xlsSheet, "Adv_Search_Criteria");
        //        string lsRSAId = CellBelowData(xlsSheet, "RSA_Id");
        //        string lsPolicyContractOption = CellBelowData(xlsSheet, "Contract_Option");
        //        string lsAmount = CellBelowData(xlsSheet, "Amount");
        //        string lsAgentSiteCode1 = CellBelowData(xlsSheet, "Agent_Site_Code");
        //        string lsEmpCode1 = CellBelowData(xlsSheet, "Emp_Code");

        //        #region // old code
        //        //string lsAgentSiteCode2;
        //        //string lsEmpCode2;

        //        //XLS.Range rngAdvSearchCriteria = (XLS.Range)sheet.Cells[5, 2];
        //        //lsAdvSearchCriteria = Convert.ToString(rngAdvSearchCriteria.Value2);

        //        //XLS.Range rngRSAId = (XLS.Range)sheet.Cells[6, 2];
        //        //lsRSAId = Convert.ToString(rngRSAId.Value2);

        //        //XLS.Range rngPolicyContractOption = (XLS.Range)sheet.Cells[7, 2];
        //        //lsPolicyContractOption = Convert.ToString(rngPolicyContractOption.Value2);

        //        //XLS.Range rngAmount = (XLS.Range)sheet.Cells[8, 2];
        //        //lsAmount = Convert.ToString(rngAmount.Value2);

        //        //XLS.Range rngAgentSiteCode1 = (XLS.Range)sheet.Cells[9, 2];
        //        //lsAgentSiteCode1 = Convert.ToString(rngAgentSiteCode1.Value2);

        //        //XLS.Range rngEmpCode1 = (XLS.Range)sheet.Cells[10, 2];
        //        //lsEmpCode1 = Convert.ToString(rngEmpCode1.Value2);

        //        //XLS.Range rngAgentSiteCode2 = (XLS.Range)sheet.Cells[11, 2];
        //        //lsAgentSiteCode2 = Convert.ToString(rngAgentSiteCode2.Value2);

        //        //XLS.Range rngEmpCode2 = (XLS.Range)sheet.Cells[12, 2];
        //        //lsEmpCode2 = Convert.ToString(rngEmpCode2.Value2);

        //        // // read from EXCEL - END

        //        //Process p = Process.Start(exergyAppPath);
        //        //p.WaitForInputIdle();
        //        //IntPtr h = p.MainWindowHandle;
        //        //SetForegroundWindow(h);
        //        ////return;

        //        //// input Password
        //        //System.Threading.Thread.Sleep(5000);
        //        ////SendKeys.SendWait("+{TAB}");
        //        //SendKeys.SendWait(lsPassword); //"+password1"
        //        ////return;
        //        ////
        //        ////press enter --------------------------------------- ERROR HANDLING
        //        //System.Threading.Thread.Sleep(1000);
        //        //SendKeys.SendWait("{ENTER}");
        //        ////
        //        ////error screen --------------------------------------- ERROR HANDLING
        //        //System.Threading.Thread.Sleep(1000);
        //        //SendKeys.SendWait(" ");
        //        ////
        //        ////error details screen
        //        //System.Threading.Thread.Sleep(2000);
        //        //SendKeys.SendWait("{TAB}");
        //        //System.Threading.Thread.Sleep(500);
        //        //SendKeys.SendWait("{ENTER}");
        //        //System.Threading.Thread.Sleep(2000);
        //        ////
        //        //// wait for application to load & set it to foreground
        //        //p.WaitForInputIdle();
        //        ////
        //        //// Maximize Window
        //        //ShowWindow(p.MainWindowHandle, SW_SHOWMAXIMIZED);
        //        ////
        //        //p.WaitForInputIdle();
        //        //System.Threading.Thread.Sleep(2000);
        //        ////
        //        #endregion


        //        // New Policy: Ctrl+P
        //        //SendKeys.SendWait("^p");
        //        //System.Threading.Thread.Sleep(1000);


        //        CompoundArgument("Ctrl", "p", 1000);

        //        //
        //        // Client Search: Adv Search
        //        goProcess.WaitForInputIdle();
        //        //SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}");
        //        //System.Threading.Thread.Sleep(1000);
        //        TAB(4, 1000);


        //        // click Adv search button
        //        //SendKeys.SendWait(" ");
        //        //System.Threading.Thread.Sleep(1000);
        //        SPACE(1, 1000);

        //        //
        //        goProcess.WaitForInputIdle();
        //        //9 TAB
        //        //SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}");
        //        //System.Threading.Thread.Sleep(500);
        //        TAB(9, 500);

        //        //
        //        // Advanced search criteria - ID: RSA 
        //        SendKeys.SendWait(lsAdvSearchCriteria);
        //        System.Threading.Thread.Sleep(1000);


        //        //
        //        //TAB
        //        //SendKeys.SendWait("{TAB}");
        //        //System.Threading.Thread.Sleep(500);

        //        TAB(1, 500);
        //        // SA ID: 0509235712080
        //        SendKeys.SendWait(lsRSAId);
        //        System.Threading.Thread.Sleep(500);


        //        // ENTER
        //        //SendKeys.SendWait("{ENTER}");
        //        //System.Threading.Thread.Sleep(1000);

        //        ENTER();
        //        // ALT + T
        //        //SendKeys.SendWait("%t");
        //        //System.Threading.Thread.Sleep(500);
        //        CompoundArgument("ALT", "t", 500);

        //        // ALT + N
        //        //SendKeys.SendWait("%n");
        //        //System.Threading.Thread.Sleep(500);

        //        CompoundArgument("ALT", "n", 500);


        //        //
        //        // Reposition Policy Structure Popup
        //        RepositionWindow(GetForegroundWindow());
        //        //
        //        // ALT + P
        //        //SendKeys.SendWait("%p");
        //        //System.Threading.Thread.Sleep(500);
        //        CompoundArgument("ALT", "p", 500);


        //        // 3 DOWN 

        //        //SendKeys.SendWait("{DOWN}{DOWN}{DOWN}");
        //        //System.Threading.Thread.Sleep(500);

        //        DOWN(3, 500);

        //        // ENTER
        //        //SendKeys.SendWait("{ENTER}");
        //        //System.Threading.Thread.Sleep(500);

        //        ENTER(1, 500);

        //        //5 TAB
        //        //SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}{TAB}");
        //        //System.Threading.Thread.Sleep(1000);
        //        //Respostion the Add Contract Window

        //        TAB(5, 1000);
        //        RepositionWindow(GetForegroundWindow());
        //        System.Threading.Thread.Sleep(1000);


        //        //Select Contact Type from Excel Sheet

        //        OneTimePressKeys("F4", 1000);
        //        //SendKeys.SendWait("{F4}");
        //        //System.Threading.Thread.Sleep(1000);


        //        string ContractType = CellBelowData(xlsSheet, "Contract_Type");
        //        SendKeys.SendWait(ContractType);//Contract Type
        //        System.Threading.Thread.Sleep(1000);


        //        #region <===== Old code to handle Menu ======>
        //        //DoMouseClick(510, 325, true, false, 1);
        //        //System.Threading.Thread.Sleep(1000);
        //        //DoMouseClick(510, 400, true, false, 1);
        //        //System.Threading.Thread.Sleep(1000);
        //        #endregion

        //        // TAB
        //        //SendKeys.SendWait("{TAB}");
        //        //System.Threading.Thread.Sleep(1000);

        //        TAB();
        //        //
        //        // O >> Contract Option: Option 1
        //        SendKeys.SendWait(lsPolicyContractOption);
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        // ALT + O >> OK Button click
        //        //SendKeys.SendWait("%o");
        //        //System.Threading.Thread.Sleep(500);

        //        CompoundArgument("ALT", "o", 500);
        //        //SendKeys.SendWait("%o");
        //        //System.Threading.Thread.Sleep(500);

        //        CompoundArgument("ALT", "o", 500);

        //        //
        //        //ERROR >> ALT + E --------------------------------------- ERROR HANDLING
        //        //SendKeys.SendWait("%e");
        //        //System.Threading.Thread.Sleep(1000);
        //        //
        //        CompoundArgument("ALT", "e", 500);

        //        // For Component Tab Cursor                
        //        // SendKeys.SendWait("{TAB}");
        //        // System.Threading.Thread.Sleep(500);
        //        TAB();
        //        //SendKeys.SendWait("{DOWN}");
        //        //System.Threading.Thread.Sleep(500);
        //        DOWN();
        //        //// Applied Contract: Flexi Funeral Click                
        //        RepositionWindow(GetForegroundWindow());
        //        System.Threading.Thread.Sleep(3000);
        //        //
        //        //ERROR >> ALT + E --------------------------------------- ERROR HANDLING
        //        //SendKeys.SendWait("%e");
        //        //System.Threading.Thread.Sleep(1000);
        //        CompoundArgument("ALT", "e", 500);

        //        #region // Component Tab - START
        //        //


        //        // CTRL TAB >> Components tab
        //        TAB(12, 1000);
        //        RIGHT(2, 1000);
        //        return;
        //        //DoMouseClick(270, 100, true, false, 1); //440, 100
        //        //System.Threading.Thread.Sleep(1000);


        //        //
        //        // 3 TAB 
        //        //SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}");
        //        //System.Threading.Thread.Sleep(500);
        //        TAB(4, 500);
        //        //
        //        // 1000 >> Cover field
        //        SendKeys.SendWait(lsAmount); //"1000"
        //        System.Threading.Thread.Sleep(1000);
        //        //


        //        #region // for add new component - START
        //        //// 4 TAB >> New Component
        //        ////SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}");
        //        ////System.Threading.Thread.Sleep(500);
        //        //DoMouseClick(1082, 365, true, false, 1); //980, 460
        //        //p.WaitForInputIdle();
        //        ////
        //        //// 1 DOWN >> Life Assured
        //        //SendKeys.SendWait("{DOWN}");
        //        //System.Threading.Thread.Sleep(500);
        //        ////
        //        //// 2 TAB 
        //        //SendKeys.SendWait("{TAB}{TAB}");
        //        //System.Threading.Thread.Sleep(500);
        //        ////
        //        //// 5 DOWN
        //        //SendKeys.SendWait("{DOWN}{DOWN}{DOWN}{DOWN}{DOWN}{DOWN}{DOWN}");
        //        //System.Threading.Thread.Sleep(500);
        //        ////
        //        //// TAB
        //        //SendKeys.SendWait("{TAB}");
        //        //System.Threading.Thread.Sleep(500);
        //        ////
        //        //// 10000
        //        //SendKeys.SendWait(lsAmount); //"10000"
        //        //System.Threading.Thread.Sleep(500);
        //        ////
        //        //// ALT + O
        //        //SendKeys.SendWait("%o");
        //        //System.Threading.Thread.Sleep(500);
        //        ////
        //        ////ERROR >> ALT + E --------------------------------------- ERROR HANDLING
        //        //SendKeys.SendWait("%e");
        //        //System.Threading.Thread.Sleep(1000);
        //        #endregion // for add new component - END
        //        //
        //        #endregion // Component Tab - END
        //        //
        //        #region // Payments Tab - START
        //        // 570,150 >> Payments Tab
        //        DoMouseClick(340, 100, true, false, 1);
        //        System.Threading.Thread.Sleep(1000);


        //        ////
        //        //// 1050, 300 >> Payment Source - Select
        //        //DoMouseClick(1000, 250, true, false, 1);
        //        //System.Threading.Thread.Sleep(1000);
        //        ////
        //        //// ALT + T
        //        //SendKeys.SendWait("%t");
        //        //System.Threading.Thread.Sleep(500);
        //        ////
        //        // 500, 240 >> Payment Info

        //        DoMouseClick(280, 190, true, false, 1);
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        // 750,265 >> Source of Funds
        //        DoMouseClick(580, 220, true, false, 1);
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        // 1 DOWN
        //        SendKeys.SendWait("{DOWN}{DOWN}");
        //        System.Threading.Thread.Sleep(500);
        //        //
        //        // 850,265 >> Source of Funds >> ADD Button
        //        DoMouseClick(800, 220, true, false, 2);
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        #endregion // Payments Tab - END
        //        //
        //        #region // Commission Tab - START
        //        //
        //        // 620,100 >> Commission Tab


        //        DoMouseClick(520, 100, true, false, 1);
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        // 450,210 >> Select policy in left box
        //        DoMouseClick(450, 210, true, false, 1);
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        // 1135,170 >> Create New Owner
        //        DoMouseClick(1135, 170, true, false, 1);
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        // 1 TAB >> Search Level Code
        //        SendKeys.SendWait("{TAB}");
        //        System.Threading.Thread.Sleep(500);
        //        //
        //        // 1 SPACE >> Click Search Level Code
        //        SendKeys.SendWait(" ");
        //        System.Threading.Thread.Sleep(500);
        //        //
        //        // ALT + S >> Search button
        //        SendKeys.SendWait("%s");
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        // 570,510 >> SEARCH GRID
        //        DoMouseClick(570, 510, true, false, 1);
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        // ALT + T
        //        SendKeys.SendWait("%t");
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        // ALT + A
        //        SendKeys.SendWait("%a");
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        #endregion // Commission Tab - END
        //        //
        //        // 5 Right Clicks >> Tab Arrow
        //        DoMouseClick(990, 100, true, false, 7);
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        #region // CASA Tab - START
        //        //
        //        // 1 Right Click >> CASA Tab
        //        DoMouseClick(900, 100, true, false, 1);
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        goProcess.WaitForInputIdle();
        //        //
        //        // ALT + R >> Request Primary Screening
        //        SendKeys.SendWait("%r");
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        // 9 TAB >> GRID Agent Site Code 1 field
        //        SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}{TAB}");
        //        System.Threading.Thread.Sleep(500);
        //        //
        //        // 7776 >> Agent Site Code 1
        //        SendKeys.SendWait(lsAgentSiteCode1); //"7776"
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        // 3 TAB
        //        SendKeys.SendWait("{TAB}{TAB}");
        //        System.Threading.Thread.Sleep(500);
        //        //
        //        // 4321 >> Employee Code 1
        //        SendKeys.SendWait(lsEmpCode1); //"4321"
        //        System.Threading.Thread.Sleep(1000);
        //        //
        //        #region // old code
        //        //// 5 TAB >> GRID Agent Site Code 2 field
        //        //SendKeys.SendWait("{TAB}{TAB}{TAB}{TAB}{TAB}");
        //        //System.Threading.Thread.Sleep(500);
        //        ////
        //        //// 8392 >> Agent Site Code 2
        //        //SendKeys.SendWait(lsAgentSiteCode2); //"8392"
        //        //System.Threading.Thread.Sleep(500);
        //        ////
        //        //// 3 TAB
        //        //SendKeys.SendWait("{TAB}{TAB}");
        //        //System.Threading.Thread.Sleep(500);
        //        ////
        //        //// 5678 >> Employee Code 2
        //        //SendKeys.SendWait(lsEmpCode2); //"5678"
        //        //System.Threading.Thread.Sleep(500);
        //        #endregion
        //        //
        //        #endregion // CASA Tab - END
        //        //


        //        goProcess.WaitForInputIdle();
        //        //
        //        // ALT CV >> Verify for Accept
        //        SendKeys.SendWait("%cv");
        //        System.Threading.Thread.Sleep(500);
        //        //
        //        //ERROR >> ALT + E --------------------------------------- ERROR HANDLING
        //        SendKeys.SendWait("%e");
        //        System.Threading.Thread.Sleep(500);
        //        //
        //        // SPACE
        //        SendKeys.SendWait(" ");
        //        System.Threading.Thread.Sleep(500);
        //        //
        //        // ALT CN >> Verify for Accept
        //        SendKeys.SendWait("%cn");
        //        System.Threading.Thread.Sleep(1000);

        //        return;
        //        //
        //        //// ALT P >> Process
        //        //SendKeys.SendWait("%p");
        //        //System.Threading.Thread.Sleep(500);
        //        //
        //        // SPACE
        //        SendKeys.SendWait(" ");
        //        System.Threading.Thread.Sleep(500);
        //        //
        //    }
        //    catch (Exception e)
        //    {
        //        throw new Exception(e.Message + " - " + e.InnerException.ToString());
        //    }
        //}



        //Login Details
        //public void LoginDetails(string SheetName)
        //{
        //    try
        //    {
        //        string lblUsername, lblPassword;
        //        xlsSheet = (XLS.Worksheet)xlsWorkbook.Worksheets.get_Item("DoLogin");
        //        lblUsername = CellBelowData(xlsSheet, "Username");
        //        lblPassword = CellBelowData(xlsSheet, "Password");
        //        goProcess = Process.Start(glExergyAppPath);
        //        goProcess.WaitForInputIdle();
        //        gptrHandler = goProcess.MainWindowHandle;
        //        SetForegroundWindow(gptrHandler);
        //        // input Password
        //        System.Threading.Thread.Sleep(3000);
        //        //SendKeys.SendWait("+{TAB}");
        //        SendKeys.SendWait(lblPassword); //"+password1"
        //                                        //return;
        //                                        //
        //                                        //press enter --------------------------------------- ERROR HANDLING
        //                                        //System.Threading.Thread.Sleep(1000);
        //                                        //SendKeys.SendWait("{ENTER}");


        //        ENTER();
        //        //
        //        //error screen --------------------------------------- ERROR HANDLING
        //        //System.Threading.Thread.Sleep(1000);
        //        //SendKeys.SendWait(" ");

        //        SPACE();

        //        //error details screen
        //        //System.Threading.Thread.Sleep(2000);
        //        //SendKeys.SendWait("{TAB}");

        //        TAB(1, 2000);
        //        //System.Threading.Thread.Sleep(500);
        //        //SendKeys.SendWait("{ENTER}");
        //        ENTER(1, 500);
        //        System.Threading.Thread.Sleep(2000);
        //        //
        //        // wait for application to load & set it to foreground
        //        goProcess.WaitForInputIdle();
        //        //
        //        // Maximize Window
        //        ShowWindow(goProcess.MainWindowHandle, SW_SHOWMAXIMIZED);
        //        //
        //        goProcess.WaitForInputIdle();
        //        System.Threading.Thread.Sleep(2000);
        //    }
        //    catch (Exception e)
        //    {
        //        throw new Exception(e.Message + " " + e.InnerException.ToString());
        //    }
        //}
        #endregion

        #region // Manually Checking for Existance of the Sheet
        //public bool SheetExists(string SheetName)
        //{
        //    // Keeping track
        //    bool found = false;
        //    // Loop through all worksheets in the workbook
        //    foreach (XLS.Worksheet sheet in xlsWorkbook.Sheets)
        //    {
        //        // Check the name of the current sheet
        //        if (sheet.Name == SheetName)
        //        {
        //            found = true;
        //            break; // Exit the loop now
        //        }
        //    }

        //    if (found)
        //    {
        //        //XLS.Worksheet mySheet = xlsWorkbook.Sheets["Example"];
        //        xlsSheet = (XLS.Worksheet)xlsWorkbook.Sheets[SheetName];
        //        return (found = true);
        //    }
        //    else
        //    {
        //        return found;
        //    }

        //}

        //public string CellNextData(XLS.Worksheet sheet, string ParamTagName)
        //{
        //    string CellValue = "";
        //    try
        //    {
        //        XLS.Range Range_Number, ReadSheet;
        //        Range_Number = sheet.UsedRange.Find(ParamTagName);
        //        if (Range_Number != null)
        //        {
        //            ReadSheet = sheet.Cells;
        //            int n_c = Range_Number.Column;
        //            int n_r = Range_Number.Row;
        //            var number = ((XLS.Range)ReadSheet[n_r, n_c + 1]).Value;
        //            CellValue = (string)number;
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        throw new Exception(e.Message + " - " + e.InnerException.ToString());
        //    }
        //    return CellValue;
        //}

        //public string CellBelowData(XLS.Worksheet sheet, string ParamTagName)
        //{
        //    string CellValue = "";
        //    try
        //    {
        //        XLS.Range Range_Number, ReadSheet;
        //        Range_Number = sheet.UsedRange.Find(ParamTagName);
        //        ReadSheet = sheet.Cells;
        //        int n_c = Range_Number.Column;
        //        int n_r = Range_Number.Row;
        //        var number = ((XLS.Range)ReadSheet[n_r + 1, n_c]).Value;
        //        CellValue = "" + number;
        //    }
        //    catch (Exception e)
        //    {
        //        throw new Exception(e.Message + " - " + e.InnerException.ToString());
        //    }
        //    return CellValue;
        //}

        #endregion

        #region <=========== Old Logic for Implemenation of Validation ==================>
        /*public void CheckforValidation()
          {
              string[] ValidationMethod = null;
              var listObject = from listobj in clsConnection.xrgds.Tables["dtListObjects"].AsEnumerable()
                               where listobj.Field<object>("Column Mapping from Input File") != null
                               && listobj.Field<object>("Validations") != null
                               && listobj.Field<string>("Data Type").Equals("Data") == false
                               select new
                               {
                                   ProcessID = listobj.Field<string>("Process ID"),
                                   Template = listobj.Field<string>("Template"),
                                   ObjectLabel = listobj.Field<string>("Object Label"),
                                   DataType = listobj.Field<string>("Data Type"),
                                   MandatoryInAppln = listobj.Field<string>("Mandatory in Appln"),
                                   Comments = listobj.Field<string>("Comments"),
                                   ColumnMappingfromInputFile = listobj.Field<string>("Column Mapping from Input File"),
                                   Validations = listobj.Field<string>("Validations")
                               };


              foreach (var lstobj in listObject)
              {
                  ValidationMethod = lstobj.Validations.Split('|');
                  ValidationDetails[] details = new ValidationDetails[ValidationMethod.Length];
                  var Inputdata = from input in clsConnection.xrgds.Tables["dtInputFile"].AsEnumerable()
                                  where lstobj.DataType != null && lstobj.DataType != "Data"
                                  select new { SearchByID = input.Field<object>(lstobj.ColumnMappingfromInputFile) };

                  foreach (var inpdt in Inputdata)
                  {
                      for (int i = 0; i < ValidationMethod.Length; i++)
                      {
                          bool Result = false;
                          if (ValidationMethod[i].Contains("MaxLength"))
                          {
                              Result = IsMaxLength(ValidationMethod[i], inpdt.SearchByID.ToString());
                          }
                          else if (ValidationMethod[i].Contains("MinLength"))
                          {
                              Result = IsMinLength(ValidationMethod[i], inpdt.SearchByID.ToString());
                          }
                          else if (ValidationMethod[i].Contains("AlphaNumeric"))
                          {
                              Result = IsAlphaNumeric(inpdt.SearchByID.ToString());
                          }
                          else if (ValidationMethod[i].Contains("OnlyCharacter"))
                          {
                              Result = IsOnlyCharacter(inpdt.SearchByID.ToString());
                          }
                          details[i] = new ValidationDetails()
                          {
                              FieldName = lstobj.ColumnMappingfromInputFile,
                              FieldValue = inpdt.SearchByID.ToString(),
                              ValidationName = ValidationMethod[i],
                              Status = Result
                          };
                      }
                      clsConnection.UpdateValidationResult(details);
                  }
              }


          }
          */
        #endregion

    }
}
