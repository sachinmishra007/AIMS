﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JOINS_LINQ
{
    public class ProductDetails
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
        public Nullable<decimal> UnitPrice { get; set; }
        public int CatId { get; set; }
        public DateTime EntryDate { get; set; }
        public DateTime ExpiryDate { get; set; }

    }
    public  class Product
    {
        public static List<ProductDetails> _product = null;
        static Product()
        {
            _product = new List<ProductDetails>()
            {
                new ProductDetails()
                {
                    ProductId=1,
                    Name="Dell Computer",
                    UnitPrice=25000,
                    CatId=1,
                    EntryDate=Convert.ToDateTime("2012-10-16 23:05:05.550"),
                    ExpiryDate=Convert.ToDateTime("2012-10-16 23:05:05.550")
                },
                new ProductDetails()
                {
                    ProductId=2,
                    Name="HCL Computer",
                    UnitPrice=20000,
                    CatId=1,
                    EntryDate=Convert.ToDateTime("2012-10-16 23:05:05.550"),
                    ExpiryDate=Convert.ToDateTime("2012-10-16 23:05:05.550")
                },
                new ProductDetails()
                {
                    ProductId=3,
                    Name="Apple Computer",
                    UnitPrice=40000,
                    CatId=3,
                    EntryDate=Convert.ToDateTime("2012-10-16 23:05:05.550"),
                    ExpiryDate=Convert.ToDateTime("2012-10-16 23:05:05.550")
                }
                ,
                new ProductDetails()
                {
                    ProductId=4,
                    Name="Samsung Computer",
                    UnitPrice=25000,
                    CatId=3,
                    EntryDate=Convert.ToDateTime("2012-10-16 23:05:05.550"),
                    ExpiryDate=Convert.ToDateTime("2012-10-16 23:05:05.550")
                }
                ,
                new ProductDetails()
                {
                    ProductId=5,
                    Name="Sony Computer",
                    UnitPrice=35000,
                    CatId=2,
                    EntryDate=Convert.ToDateTime("2012-10-16 23:05:05.550"),
                    ExpiryDate=Convert.ToDateTime("2012-10-16 23:05:05.550")
                }
                 ,
                new ProductDetails()
                {
                    ProductId=6,
                    Name="Dell Computer",
                    UnitPrice=36000,
                    CatId=2,
                    EntryDate=Convert.ToDateTime("2012-10-16 23:05:05.550"),
                    ExpiryDate=Convert.ToDateTime("2012-10-16 23:05:05.550")
                }
                ,
                new ProductDetails()
                {
                    ProductId=7,
                    Name="HP Computer",
                    UnitPrice=12000,
                    CatId=4,
                    EntryDate=Convert.ToDateTime("2012-10-16 23:05:05.550"),
                    ExpiryDate=Convert.ToDateTime("2012-10-16 23:05:05.550")
                }
                ,
                new ProductDetails()
                {
                    ProductId=8,
                    Name="Canon Printer",
                    UnitPrice=10000,
                    CatId=2,
                    EntryDate=Convert.ToDateTime("2012-10-16 23:05:05.550"),
                    ExpiryDate=Convert.ToDateTime("2012-10-16 23:05:05.550")
                }

            };
        }
    }
}
