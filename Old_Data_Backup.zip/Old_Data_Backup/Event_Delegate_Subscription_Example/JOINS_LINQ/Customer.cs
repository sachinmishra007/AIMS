﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JOINS_LINQ
{
    public class CustomerDetails
    {
        public int CustId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string ContactNo { get; set; }
    }
    public  class Customer
    {


        public static List<CustomerDetails> _customer = null;
         static Customer()
        {
            _customer = new List<CustomerDetails>()
            {
                new CustomerDetails()
                {
                    CustId=1,
                    Name="Same",
                    Address="New Delhi",
                    ContactNo="955555555"
                },
                new CustomerDetails()
                {
                    CustId=2,
                    Name="Rahul",
                    Address="Gurgaon",
                    ContactNo="955555555".Replace('5','6')
                }
                ,
                new CustomerDetails()
                {
                    CustId=3,
                    Name="Jeetu",
                    Address="Delhi",
                    ContactNo="955555555".Replace('5','3')
                },                
                new CustomerDetails()
                {
                    CustId=5,
                    Name="Ankit",
                    Address="Noida",
                    ContactNo="955555555".Replace('5','2')
                }
            };
        }
    }
}
