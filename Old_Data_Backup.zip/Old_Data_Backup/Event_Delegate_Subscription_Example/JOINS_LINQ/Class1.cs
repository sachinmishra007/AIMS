﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JOINS_LINQ
{
    public class A
    {
        private int a = 10;
    }
    public class B : A
    {
        public B()
        {
            Console.WriteLine("" + base.a);
        }
    }
    public class Class1
    {
        static void Main(string[] args)
        {

        }
    }
}
