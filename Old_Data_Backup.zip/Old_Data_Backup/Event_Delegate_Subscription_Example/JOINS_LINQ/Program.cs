﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JOINS_LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            // left join

            var leftjoin = from product in Product._product
                           join order in Order._orders on
                           product.ProductId equals order.ProductId into t
                           from rt in t.DefaultIfEmpty()
                           select product;


            var crossJoin = from product in Product._product
                            from orders in Order._orders
                            select new
                            {
                                ProductId = product.ProductId,
                                ProductName = product.Name,
                                OrderId = orders.OrderId,
                                OrderProductId = orders.ProductId

                            };

            // Inner Join
            var inerjoin = from product in Product._product
                           join orders in Order._orders on
                           product.ProductId equals orders.ProductId
                           orderby orders.OrderId
                           select new
                           {
                               orders.OrderId,
                               product.ProductId,
                               product.Name,
                               product.UnitPrice,
                               orders.Quantity,
                               OrderPrice = orders.UnitPrice
                           };


            // Inner Join more than two tables
            var innerjoin5 = from product in Product._product
                             join orders in Order._orders on
                             product.ProductId equals orders.ProductId
                             join customer in Customer._customer on
                             orders.CustomerId equals customer.CustId
                             orderby orders.OrderId
                             select new
                             {
                                 customer.Name,
                                 orders.OrderId,
                                 product.ProductId,
                                 product.UnitPrice,
                                 orders.Quantity,
                                 OrderPrice = orders.UnitPrice
                             };



            Console.Read();
        }
    }
}
