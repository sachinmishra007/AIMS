﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JOINS_LINQ
{
    public class OrderDetails
    {
        public int OrderId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public Nullable<decimal> UnitPrice { get; set; }
        public int CustomerId { get; set; }
        public string ContactNo { get; set; }
    }
    public class Order
    {
        public static List<OrderDetails> _orders = null;
        static Order()
        {
            _orders = new List<OrderDetails>()
            {
                   new OrderDetails()
                   {
                    OrderId=1,
                    ProductId=1,
                    Quantity=6,
                    UnitPrice=150000,
                    CustomerId=1,
                    ContactNo="955555555"
                   } ,
                   new OrderDetails()
                   {
                    OrderId=2,
                    ProductId=2,
                    Quantity=4,
                    UnitPrice=80000,
                    CustomerId=2                    
                   }  ,
                   new OrderDetails()
                   {
                    OrderId=3,
                    ProductId=2,
                    Quantity=2,
                    UnitPrice=40000,
                    CustomerId=3,
                    ContactNo="9444444444"
                   },
                    
                   new OrderDetails()
                   {
                    OrderId=4,
                    ProductId=3,
                    Quantity=5,
                    UnitPrice=20000,
                    CustomerId=4,
                    ContactNo="9333333333"
                   } ,
                   
                   new OrderDetails()
                   {
                    OrderId=5,
                    ProductId=5,
                    Quantity=1,
                    UnitPrice=35000,
                    CustomerId=5,
                    ContactNo="966666666"
                   } 
            };
        }
    }
}
