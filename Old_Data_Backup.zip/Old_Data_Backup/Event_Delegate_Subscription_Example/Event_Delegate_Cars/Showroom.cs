﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Cars
{
    public class Showroom
    {
        public Showroom()
        {

        }

        public void onNewCarAvailableOnShowRoom(object sender, EventArgs args)
        {
            Console.WriteLine("The Car is available in Showrooom");
        }
    }
}
