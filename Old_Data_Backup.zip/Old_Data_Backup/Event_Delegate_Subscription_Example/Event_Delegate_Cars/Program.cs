﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Cars
{
    class Program
    {
        static void Main(string[] args)
        {
            var _cars = new Cars();
            var _showRoom = new Showroom();
            var _readylaunch = new Readylaunch();

            _cars.onCarCreated += _showRoom.onNewCarAvailableOnShowRoom;
            _cars.onCarCreated += _readylaunch.onNewCarReadyToLaunch;


            Console.ReadLine();
        }
    }
}
