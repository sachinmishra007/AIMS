﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Cars
{
    public class Readylaunch
    {
        public Readylaunch()
        {

        }

        public void onNewCarReadyToLaunch(object sender, EventArgs args)
        {
            Console.WriteLine("Car Ready to Launch");
        }
    }
}
