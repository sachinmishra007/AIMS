﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Cars
{
    public class Cars
    {
        public delegate void CarCreationEventHandler(object sender, EventArgs args);
        public event CarCreationEventHandler onCarCreated;
        private IList<CarEntity> _lstCarEntity;
        public Cars()
        {
            _lstCarEntity = new List<CarEntity>() { 
            
                new CarEntity()
                {
                    CarName="Tesla",ChesiNumber="TES25465S0012",Model="TS125",Price=120550000M
                }
            
            };
        }

        public void NewCarModel(CarEntity _carEntity)
        {
            _lstCarEntity.Add(_carEntity);
            onCarCreation();
        }

        protected virtual void onCarCreation()
        {
            if (onCarCreated != null)
                onCarCreated(this, EventArgs.Empty);

        }

    }
}
