﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Subscription_Example
{
    class Program
    {

        static void Main(string[] args)
        {
            var _messageEntity = new MessageEntity() { Title = "Launched on @ " + DateTime.Now.ToShortDateString() };
            var _messageEncoder = new MessageEncoder();
            var _messageBroadcastService = new MessageBroadcastService();
            var _messageEncodingMailService = new MessageMailEncodedService();

            //Register the MessageEncoded service
            _messageEncoder.MessageEncoded += _messageBroadcastService.OnMessageEncoded;
            
            //Registering the Messagemail Service
            _messageEncoder.MessageEncoded += _messageEncodingMailService.onMessageMailEncoded;


            _messageEncoder.Encoder(_messageEntity);
            Console.WriteLine("Press any key to continue...............");
            Console.ReadLine();
        }
    }


}
