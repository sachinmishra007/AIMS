﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Subscription_Example
{
    public class MessageEncoder
    {
        /*         
         *1-Define the delegate to Pointer
         *2-Register Event Delegate
         *3-Invoke the event
        */
        public delegate void MessageEncodedEventhandler(object sender, EventArgs args);
        public event MessageEncodedEventhandler MessageEncoded;
        public void Encoder(MessageEntity entity)
        {
            Console.WriteLine(" The Text Message Encoding in Process : " + entity.Title);
            System.Threading.Thread.Sleep(4000);
            onMessageEncoded();
        }
        protected virtual void onMessageEncoded()
        {
            if (MessageEncoded != null)
                MessageEncoded(this, EventArgs.Empty);
        }

    }
}
