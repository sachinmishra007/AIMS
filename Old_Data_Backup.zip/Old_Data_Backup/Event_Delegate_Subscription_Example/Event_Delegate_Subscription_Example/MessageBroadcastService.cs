﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Subscription_Example
{
    public class MessageBroadcastService
    {
        public MessageBroadcastService()
        {

        }

        public void OnMessageEncoded(object sender, EventArgs args)
        {
            System.Threading.Thread.Sleep(3000);
            Console.WriteLine("Message Broadcasting Process done !!!");
        }
    }
}
