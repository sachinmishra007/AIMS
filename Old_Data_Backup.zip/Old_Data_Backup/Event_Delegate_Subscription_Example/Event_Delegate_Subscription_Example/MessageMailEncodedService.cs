﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Subscription_Example
{
    public class MessageMailEncodedService
    {
        public MessageMailEncodedService()
        {

        }

        public void onMessageMailEncoded(object sender, EventArgs args)
        {
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine("Message Mailing the encoded part of it...");
        }
    }
}
