﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Subscription_Example
{
    public class MessageEntity
    {
        public string Title { get; set; }
    }
}
