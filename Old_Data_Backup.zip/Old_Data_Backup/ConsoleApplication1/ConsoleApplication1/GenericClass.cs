﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class GenericClassExample<T>
    {
        private T[] array;
        public int ArraySize;
        public GenericClassExample(int Size)
        {
            this.ArraySize = Size;
            array = new T[Size];
        }

        public void setItem(int index, T item)
        {
            array[index] = item;
        }

        public T getItem(int index)
        {
            return array[index];
        }
    }
    class GenericClass
    {
        static void Main(string[] args)
        {
            GenericClassExample<int> _intArray = new GenericClassExample<int>(5);
            for (int i = 0; i < _intArray.ArraySize; i++)
            {
                _intArray.setItem(i, i * 10);
            }
            Console.WriteLine("------------------------Integer Array------------------");
            Console.WriteLine("--------------------------------------------------------");
            for (int i = 0; i < _intArray.ArraySize; i++)
            {
                Console.WriteLine("Array element {0} ", _intArray.getItem(i));
            }


            GenericClassExample<object> _object = new GenericClassExample<object>(5);
            _object.setItem(0, "sachin");
            _object.setItem(1, 2);

            Console.WriteLine(_object.getItem(2));

            Console.ReadLine();


        }
    }
}
