﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class AA
    {
        public virtual void data()
        {
            Console.WriteLine("Welcome");
        }
    }

    public class BB : AA
    {
        public new void data()
        {
          
        }


    }
    public class Class3
    {
        static void Main(string[] args)
        {
            AA t = new BB();
            t.data();
            Console.ReadKey();

        }
    }
}
