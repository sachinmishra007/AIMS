﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class event_delegate
    {
        private event_delegate()
        {

        }
 
        public  int a = 10;

        public static event_delegate Demo()
        {
            return new event_delegate();
        }
    }

    class Demo
    {
        public Demo()
        {

        }
        static void Main(string[] args)
        {
            Console.WriteLine(""+event_delegate.Demo().a.ToString());
            Console.ReadLine();
        }
    }
}
