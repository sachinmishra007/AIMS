﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public struct t
    {
       
        public t(int a, int b)
        {

        }

        public string add()
        {
            return "achin";
        }
    }
    public abstract class changes
    {
     
        public changes()
        {

        }
        public changes(int a, int b)
        {

        }
        public abstract int add(int a, int b);

    }

    public class ChangesMade : changes
    {
        public ChangesMade()
            : base(10, 20)
        {

        }
        public override int add(int a, int b)
        {
            return 0;
        }
    }

    class Class2
    {
        public static void Main(string[] args)
        {
            ChangesMade t = new ChangesMade();
            t a;
            a.add();
        
        }
    }
}
