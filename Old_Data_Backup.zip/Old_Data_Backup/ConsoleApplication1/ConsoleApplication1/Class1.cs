﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class A
    {
        public A()
        {
            Console.WriteLine("Inside Constructor A");
        }
        public A(int a, int b)
        {
            Console.WriteLine("Value {0} and {1}", a, b);
        }
        public virtual void details()
        {
            Console.WriteLine("Inside Class A");
        }
    }
    class B : A
    {
        public B()
        {
            Console.WriteLine("Inside Constructor B");
        }
        public override void details()
        {
            Console.WriteLine("Inside Class B");
        }
    }

    class C : A
    {
        public C()
        {
            Console.WriteLine("Inside Constructor C");
        }
        public new void details()
        {
            Console.WriteLine("Inside Class C");
        }
    }


    class Class1
    {
        static void Main(string[] args)
        {
            A t1 = new B();
            A t2 = new C();

            t1.details();
            t2.details();
            Console.Read();

        }
    }
}
