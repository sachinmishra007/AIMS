﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Indexer_implement_Class
    {

        public static int a = 10;
        private string[] namelist = new string[a];
        public Indexer_implement_Class()
        {

        }
        public string this[int index]
        {

            get
            {
                string tmp;
                if (!(index < 0 || index > 10))
                {
                    tmp = namelist[index];
                }
                else
                {
                    tmp = "does not exists";
                }

                return tmp;

            }
            set
            {
                if (!(index < 0 || index > 10))
                {
                    namelist[index] = value;
                }
                else
                {
                    throw new Exception("Invalid input");
                }

            }
        }

    }
    class Indexer_Example
    {
        static void Main(string[] args)
        {
            Indexer_implement_Class t = new Indexer_implement_Class();
            t[0] = "Sachin";
            t[2] = "Demo";
            //t[11] = "Demo";

            ArrayList t1 = new ArrayList();
            t1.Add(1);
            t1.Add(2);
            t1.Add("Sachin");
            t1.Add(null);
            t1.Add("mishra");
            t1.Add("");
            
            var result = from object res in t1

                         where res != null
                         select res;

            string[] myColors = { "Red", "Blue", "", "Green", "", null, "pink" };

            myColors = myColors.Where(a => !string.IsNullOrEmpty(a)).ToArray();


            Console.ReadLine();

        }
    }
}
