﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuidlerDesignPatern
{
    public class Car
    {
        private string _CarName { get; set; }
        private string _Engine { get; set; }
        private string _SatNav { get; set; }
        private int _SideDoor { get; set; }
        private bool _MP3Player { get; set; }
        private bool _AirBag { get; set; }

        public Car(
            string CarName,
            string Engine,
            string SatNav,
            int SideDoor,
            bool MP3Player,
            bool AirBag)
        {
            _CarName = CarName;
            _Engine = Engine;
            _SatNav = SatNav;
            _SideDoor = SideDoor;
            _MP3Player = MP3Player;
            _AirBag = AirBag;

        }

        public string CarName
        {
            get
            {
                return _CarName;
            }
        }
        public string Engine
        {
            get
            {
                return _Engine;
            }
        }
        public string SatNav
        {
            get
            {
                return _SatNav;
            }
        }
        public int SideDoor
        {
            get
            {
                return _SideDoor;
            }
        }
        public bool MP3Player
        {
            get
            {
                return _MP3Player;
            }
        }
        public bool AirBag
        {
            get
            {
                return _AirBag;
            }
        }


    }
}
