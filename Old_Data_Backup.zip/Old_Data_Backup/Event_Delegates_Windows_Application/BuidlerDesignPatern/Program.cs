﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuidlerDesignPatern
{
    class Program
    {
        static void Main(string[] args)
        {
            var fordFeista = new FordFiesta()
                        .AddAirBag(true)
                         .AddCarName("Ford Feista V25")
                         .AddEngine("V8")
                         .Build();

            Console.Write(@"Car has :------------------            
                 Air Bag : {0},
                 Car Name:{1},
                 Engine Name:{2}, 
                 MP3Player:{3},
                 Sat Nav:{4},
                 No. Side Door:{5}",
                fordFeista.AirBag ? "Yes" : "No",
                fordFeista.CarName,
                fordFeista.Engine,
                fordFeista.MP3Player ? "Yes" : "No",
                fordFeista.SatNav == null ? "Not Defined" : fordFeista.SatNav,
                fordFeista.SideDoor);

            Console.Read();
        }
    }
}
