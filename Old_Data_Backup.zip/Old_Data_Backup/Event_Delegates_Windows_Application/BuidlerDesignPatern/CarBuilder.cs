﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuidlerDesignPatern
{
    public abstract class CarBuilder
    {
        protected string _CarName { get; set; }
        protected string _Engine { get; set; }
        protected string _SatNav { get; set; }
        protected int _SideDoor { get; set; }
        protected bool _MP3Player { get; set; }
        protected bool _AirBag { get; set; }

        public CarBuilder AddCarName(string CarName)
        {
            _CarName = CarName;
            return this;
        }

        public CarBuilder AddEngine(string EngineName)
        {
            _Engine = EngineName;
            return this;
        }

        public CarBuilder AddSatNav(string SatNav)
        {
            _SatNav = SatNav;
            return this;
        }

        public CarBuilder AddSideDoor(int DoorNumber)
        {
            _SideDoor = DoorNumber;
            return this;
        }

        public CarBuilder AddMP3Player(bool MP3Player)
        {
            _MP3Player = MP3Player;
            return this;
        }

        public CarBuilder AddAirBag(bool AirBag)
        {
            _AirBag = AirBag;
            return this;
        }

        public Car Build()
        {
            return new Car(_CarName, _Engine, _SatNav, _SideDoor, _MP3Player, _AirBag);
        }
    }
}
