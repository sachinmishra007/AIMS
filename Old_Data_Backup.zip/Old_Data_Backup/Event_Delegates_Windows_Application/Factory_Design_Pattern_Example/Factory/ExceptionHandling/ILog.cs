﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Exception;
namespace Factory_Design_Pattern_Example.Factory.ExceptionHandling
{
    public interface ILog
    {
        void LogException(Exception ex);
    }
}