﻿using Factory_Design_Pattern_Example.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Factory_Design_Pattern_Example.DAL.EmployeeDetails
{
    public interface IEmployee
    {
        List<Employee> GetEmployeeDetails();
        int AddEmployeeDetails(Employee _emp);
    }
}