﻿using Factory_Design_Pattern_Example.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Factory_Design_Pattern_Example.DAL.EmployeeDetails
{
    public class EmployeeImplementation : IEmployee
    {
        private static List<Employee> _employee = new List<Employee>();
        public EmployeeImplementation()
        {           
           
        }

        public List<Employee> GetEmployeeDetails()
        {
            return _employee;
        }

        public int AddEmployeeDetails(Employee _emp)
        {
            _employee.Add(_emp);
            return 0;
        }
    }
}