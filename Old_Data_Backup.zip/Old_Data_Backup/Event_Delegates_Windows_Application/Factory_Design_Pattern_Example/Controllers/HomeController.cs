﻿using Factory_Design_Pattern_Example.DAL.EmployeeDetails;
using Factory_Design_Pattern_Example.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Factory_Design_Pattern_Example.Controllers
{
    public class HomeController : Controller
    {
        IEmployee _emp;
        public HomeController()
        {
            _emp = new EmployeeImplementation();
        }
        public ActionResult Index()
        {
            return View(_emp.GetEmployeeDetails());
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddEmployee([Bind(Include = "Id,EmpDesig,EmpSalary,EmpName", Exclude = "", Prefix = "")] Employee _empObj)
        {
            _emp.AddEmployeeDetails(_empObj);
            return RedirectToAction("Index", _emp.GetEmployeeDetails());
        }
    }
}