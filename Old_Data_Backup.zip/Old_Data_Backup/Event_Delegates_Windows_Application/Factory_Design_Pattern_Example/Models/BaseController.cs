﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Factory_Design_Pattern_Example.Models
{
    public class BaseController : Controller
    {

    }
}