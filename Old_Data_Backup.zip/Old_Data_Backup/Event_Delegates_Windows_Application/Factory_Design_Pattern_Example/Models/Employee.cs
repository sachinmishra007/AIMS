﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Factory_Design_Pattern_Example.Model
{
    public class Employee
    {
        [DisplayAttribute(Name = "Employee Id")]
        public int Id { get; set; }

        [DisplayAttribute(Name = "Employee Name")]
        [Required(ErrorMessage = "Please Enter Employee Name", AllowEmptyStrings = false)]
        
        public string EmpName { get; set; }

        [DisplayAttribute(Name = "Employee Designation")]
        [Required(ErrorMessage = "Please Enter Employee Designation", AllowEmptyStrings = false)]
        public string EmpDesig { get; set; }

        [DisplayAttribute(Name = "Employee Salary")]
        [Required(ErrorMessage = "Please Enter Employee Salary", AllowEmptyStrings = false)]
        public decimal? EmpSalary { get; set; }

    }
}