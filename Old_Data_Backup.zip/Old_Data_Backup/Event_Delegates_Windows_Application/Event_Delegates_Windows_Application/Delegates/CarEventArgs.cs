﻿using Event_Delegates_Windows_Application.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegates_Windows_Application.Delegates
{
    public class CarEventArgs : EventArgs
    {
        public Car CarCreatedDetails { get; set; }
    }
}
