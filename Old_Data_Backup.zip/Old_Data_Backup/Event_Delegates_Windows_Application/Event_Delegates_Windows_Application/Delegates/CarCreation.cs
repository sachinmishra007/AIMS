﻿using Event_Delegates_Windows_Application.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegates_Windows_Application.Delegates
{
    public class CarCreation
    {
        public delegate void CarCreationEventHandler(object sender, CarEventArgs args);

        public event CarCreationEventHandler onCarCreated;
        public CarCreation()
        {

        }

        public void onCarCreation(Car _carCreation)
        {
            if (onCarCreated != null)
                onCarCreated(this, new CarEventArgs() { CarCreatedDetails = _carCreation });
        }
    }
}
