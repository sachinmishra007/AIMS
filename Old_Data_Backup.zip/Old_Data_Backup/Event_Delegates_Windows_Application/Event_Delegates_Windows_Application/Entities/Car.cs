﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegates_Windows_Application.Entities
{
    public class Car
    {
        public string CarName { get; set; }
        public string CarModel { get; set; }
        public Nullable<decimal> Price { get; set; }
    }
}
