﻿using Event_Delegates_Windows_Application.Delegates;
using Event_Delegates_Windows_Application.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Event_Delegates_Windows_Application
{
    public partial class frmCarPublisher : Form
    {

        MainForms.frmCarReadyToLaunch _frmCarReadyToLaunch = new MainForms.frmCarReadyToLaunch();
        MainForms.frmShowRoom _frmShowRoom = new MainForms.frmShowRoom();
        MainForms.frmReadyToExport _frmReadyToExport = new MainForms.frmReadyToExport();
        Delegates.CarCreation _carCreation = new Delegates.CarCreation();
        public frmCarPublisher()
        {
            InitializeComponent();
            _carCreation.onCarCreated += _frmShowRoom.onCarShowRoom;
            _carCreation.onCarCreated += _frmCarReadyToLaunch.onCarReadyoLaunch;
            _carCreation.onCarCreated += _frmReadyToExport.onCarReadyToExport;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            var _cars = new Car()
            {
                CarName = txtCarName.Text,
                CarModel = txtModel.Text,
                Price = Convert.ToDecimal(txtPrice.Text)
            };
            _carCreation.onCarCreation(_cars);
            _frmShowRoom.Show();
            _frmCarReadyToLaunch.Show();
            _frmReadyToExport.Show();
        }
    }
}
