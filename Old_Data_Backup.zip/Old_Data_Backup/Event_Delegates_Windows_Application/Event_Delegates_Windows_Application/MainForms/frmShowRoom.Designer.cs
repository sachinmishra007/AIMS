﻿namespace Event_Delegates_Windows_Application.MainForms
{
    partial class frmShowRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Price = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDisplayCarName = new System.Windows.Forms.Label();
            this.lblDisplayModelName = new System.Windows.Forms.Label();
            this.lblDisplayCarPrice = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Price
            // 
            this.Price.AutoSize = true;
            this.Price.Location = new System.Drawing.Point(23, 73);
            this.Price.Name = "Price";
            this.Price.Size = new System.Drawing.Size(31, 13);
            this.Price.TabIndex = 1;
            this.Price.Text = "Price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Model";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Car Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblDisplayCarName
            // 
            this.lblDisplayCarName.AutoSize = true;
            this.lblDisplayCarName.Location = new System.Drawing.Point(83, 21);
            this.lblDisplayCarName.Name = "lblDisplayCarName";
            this.lblDisplayCarName.Size = new System.Drawing.Size(91, 13);
            this.lblDisplayCarName.TabIndex = 3;
            this.lblDisplayCarName.Text = "Display Car Name";
            this.lblDisplayCarName.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblDisplayModelName
            // 
            this.lblDisplayModelName.AutoSize = true;
            this.lblDisplayModelName.Location = new System.Drawing.Point(83, 47);
            this.lblDisplayModelName.Name = "lblDisplayModelName";
            this.lblDisplayModelName.Size = new System.Drawing.Size(104, 13);
            this.lblDisplayModelName.TabIndex = 2;
            this.lblDisplayModelName.Text = "Display Model Name";
            this.lblDisplayModelName.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblDisplayCarPrice
            // 
            this.lblDisplayCarPrice.AutoSize = true;
            this.lblDisplayCarPrice.Location = new System.Drawing.Point(83, 73);
            this.lblDisplayCarPrice.Name = "lblDisplayCarPrice";
            this.lblDisplayCarPrice.Size = new System.Drawing.Size(87, 13);
            this.lblDisplayCarPrice.TabIndex = 1;
            this.lblDisplayCarPrice.Text = "Display Car Price";
            // 
            // frmShowRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(356, 106);
            this.Controls.Add(this.lblDisplayCarPrice);
            this.Controls.Add(this.Price);
            this.Controls.Add(this.lblDisplayModelName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblDisplayCarName);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmShowRoom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Showroom Flats";
            this.Load += new System.EventHandler(this.frmShowRoom_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Price;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDisplayCarName;
        private System.Windows.Forms.Label lblDisplayModelName;
        private System.Windows.Forms.Label lblDisplayCarPrice;
    }
}