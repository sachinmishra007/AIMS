﻿using Event_Delegates_Windows_Application.Delegates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Event_Delegates_Windows_Application.MainForms
{
    public partial class frmShowRoom : Form
    {
        public frmShowRoom()
        {
            InitializeComponent();
        }

        public void onCarShowRoom(object sender, CarEventArgs args)
        {
            lblDisplayCarName.Text = args.CarCreatedDetails.CarName;
            lblDisplayModelName.Text = args.CarCreatedDetails.CarModel;
            lblDisplayCarPrice.Text = args.CarCreatedDetails.Price.Value.ToString();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void frmShowRoom_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
