﻿using Event_Delegates_Windows_Application.Delegates;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Event_Delegates_Windows_Application.MainForms
{
    public partial class frmReadyToExport : Form
    {
        public frmReadyToExport()
        {
            InitializeComponent();
        }

        public void onCarReadyToExport(object sender, CarEventArgs args)
        {
            lblDisplayCarName.Text = args.CarCreatedDetails.CarName;
            lblDisplayModelName.Text = args.CarCreatedDetails.CarModel;
            lblDisplayCarPrice.Text = args.CarCreatedDetails.Price.Value.ToString();
        }
    }
}
