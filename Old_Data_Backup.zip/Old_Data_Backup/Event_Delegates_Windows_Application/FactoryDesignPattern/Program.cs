﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryDesignPattern
{
    class Program
    {
        static void Main(string[] args)
        {

            var fordFeista = new FordFiestaFactory() as ICreateCars;
            var _obtainedResult = fordFeista.CreateCars("Red");
            Console.Write(@"
                Car Make : {0},
                Car Model:{1},
                Car Engine Size : {2},
                Car Colour : {3},
                Car Price : {4}            
            ", _obtainedResult.Make
             , _obtainedResult.Model
             , _obtainedResult.EngineSize
             , _obtainedResult.Colour
             , _obtainedResult.getCarPrice());

            Console.Read();
        }
    }
    interface ICreateCars
    {
        Car CreateCars(string Colour);
    }

    public class FordFiestaFactory : ICreateCars
    {
        public Car CreateCars(string _colour)
        {
            return new FordFiesta() { Colour = _colour };

        }
    }



    public abstract class Car
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public string EngineSize { get; set; }
        public string Colour { get; set; }
        public abstract double? getCarPrice();
    }

    public class FordFiesta : Car
    {
        public FordFiesta()
        {
            Make = "Ford Fiesta";
            Model = "Fiesta";
            EngineSize = "2.9";
        }
        public override double? getCarPrice()
        {
            return 125000.323d;
        }
    }
}
